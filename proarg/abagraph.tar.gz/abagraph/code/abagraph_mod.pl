
:- module(abagraph, []).

:- ensure_loaded(abagraph).
