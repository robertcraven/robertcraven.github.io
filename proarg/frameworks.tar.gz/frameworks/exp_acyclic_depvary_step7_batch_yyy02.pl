generation_settings([64,24,64,24,32,[2,8],[0,9],[0,9]]).
% number of sentences (input):    64
% number of assumptions (input):  24
% number of sentences:            64
% number of assumptions:          24
% number of rule heads:           32
% number of rules per head:       [2,8]
% number of sentences per body:   [0,9]
% number of assumptions per body: [0,9]

myAsm(a1).
myAsm(b1).
myAsm(c1).
myAsm(d1).
myAsm(e1).
myAsm(f1).
myAsm(a2).
myAsm(b2).
myAsm(c2).
myAsm(d2).
myAsm(e2).
myAsm(f2).
myAsm(a3).
myAsm(b3).
myAsm(c3).
myAsm(d3).
myAsm(e3).
myAsm(f3).
myAsm(a4).
myAsm(b4).
myAsm(c4).
myAsm(d4).
myAsm(e4).
myAsm(f4).

contrary(a1, r1).
contrary(a2, v4).
contrary(a3, f4).
contrary(a4, u1).
contrary(b1, y2).
contrary(b2, t2).
contrary(b3, u1).
contrary(b4, v3).
contrary(c1, z1).
contrary(c2, x1).
contrary(c3, d3).
contrary(c4, w2).
contrary(d1, x2).
contrary(d2, x3).
contrary(d3, w2).
contrary(d4, a1).
contrary(e1, q2).
contrary(e2, a4).
contrary(e3, x2).
contrary(e4, x3).
contrary(f1, t1).
contrary(f2, f4).
contrary(f3, s1).
contrary(f4, u1).

myRule(t3, [b4,p2,r1,t1,w2,z3]).
myRule(t3, [r2,r4,t4,u4,v4,w2,y3]).
myRule(t3, [b4,c4,d3,e3,e4,w3,y2]).
myRule(t3, [r2,s3,t4]).
myRule(t3, [b3,c1,c3,c4,d3,d4,f2,f3]).
myRule(t3, [s1,w1]).
myRule(t3, []).
myRule(x1, [p3]).
myRule(x1, [a2,a4,b4,c2,c3,d1,d3,f2,f3]).
myRule(x1, []).
myRule(x1, [a4,b1,b3,e3,e4,f4]).
myRule(x1, [a3,c3,u2]).
myRule(x1, [p4,r4,s2,t1,w3,y3]).
myRule(x1, [a3,d1,q4,r1,r3,u1,y1,z3]).
myRule(x1, [c2,f1,q4,t2,w3,y2]).
myRule(t4, [q3,u4,x3,y3]).
myRule(t4, [q2]).
myRule(t4, [b1,c3,f2,u1,v3,w1]).
myRule(u3, [q2]).
myRule(u3, [b3,c2,d1,q2]).
myRule(u3, []).
myRule(u3, [b3,c1,p2,y3]).
myRule(t2, [c3,e2,p4,q2,r2,s1,s4,t1,x2]).
myRule(t2, [a2,b2,d3,e4,f1,f3]).
myRule(t2, [d4]).
myRule(t2, [f2,v1,v4]).
myRule(p3, [p1,p4,s1,s4,y2,y3,z1]).
myRule(p3, [a1,s1,u1,v3,y2]).
myRule(p3, [f4,q1,u4,w1,x2,x3,y3,z3]).
myRule(p3, [b1,z3]).
myRule(p4, [a4,c1,c2,d2,e2,e4,f4,q1,r1]).
myRule(p4, [a3,c3,d1,f3,f4]).
myRule(p4, [b3,q1,q4,s3,z3]).
myRule(p4, [w3]).
myRule(p4, [p2,w2,z1]).
myRule(p4, []).
myRule(p4, [a1]).
myRule(p4, [b3,c4,r4]).
myRule(q3, [b2,b3,c3,q4,r2,z3]).
myRule(q3, [r1]).
myRule(q3, [a4,e4,q4,s4,t1,v1,w2]).
myRule(q3, [b3,d4,f1,f3,y3]).
myRule(q3, [b1,d2,d3,t1,u1,v1,w3,x3,z3]).
myRule(q3, [a3,d4]).
myRule(q3, []).
myRule(v1, [p1,r2,x2,z3]).
myRule(v1, [y3]).
myRule(v1, [p2,r4,s4,z3]).
myRule(s1, [a1,a3,b4,c2,d1,d4]).
myRule(s1, [a3,q4,r3,y2]).
myRule(s1, [a2,b3,d2,e4]).
myRule(s1, [d3]).
myRule(s1, [b3,c3,e3]).
myRule(s1, [q4,r3,y2,z1]).
myRule(r2, [c2,c3]).
myRule(r2, [c1,f1,r4,s4,u2,x3,z2]).
myRule(r2, [c2,d1,d2,f4]).
myRule(r2, [d2,q4]).
myRule(r2, [a2,a4,f1,p2,r1,s4,w3]).
myRule(r2, []).
myRule(r2, [d2,d4,f1,s2,s3,u4,v4,w1]).
myRule(p1, [r4]).
myRule(p1, [a1,b1,b2,d3,d4,e3,f4,t1]).
myRule(p1, [e1,q1,q2,q4,s4,t1,u1,w2,y1]).
myRule(p1, [a1,d3,r1,v3,w2,x2]).
myRule(w3, [a1,b1,b3,c3,d1,e4,f3,w2]).
myRule(w3, [a2]).
myRule(w3, [b3,e2,r3,s3,u1,u2,u4]).
myRule(w3, [e2,u4,y3]).
myRule(w3, [q2,r1,y3]).
myRule(w3, [c1,c4,q2]).
myRule(w3, [d1,q2,r3,z1,z2]).
myRule(w3, [f1]).
myRule(z1, [a2,d2,f4]).
myRule(z1, [r1,r4,s2,u4,x3]).
myRule(z1, [a3,d1,f1,f2]).
myRule(s3, [c2,d4,q1,w2,x3,y2,z2,z3]).
myRule(s3, [a4,c1,s4,v4,z2]).
myRule(q2, [a1,v3]).
myRule(q2, [e1,s2,s4,v4,y2]).
myRule(s2, [b1,b4,c3,d2,e3,f3]).
myRule(s2, [f2]).
myRule(s2, [c1,c2,d2,d4,e2,e3,e4,v3]).
myRule(s2, [b1,r4,z3]).
myRule(s2, [a3,c3,e4,f4]).
myRule(r1, [c1,c2,d1,t1,w1,y3,z3]).
myRule(r1, [p2]).
myRule(r1, [f1,f3]).
myRule(r1, []).
myRule(r1, [v2,x2,y1,y3]).
myRule(r1, [b3,d1,w1]).
myRule(r1, [a4,b3,b4,c4,e1,f1,w2]).
myRule(v4, [q1,q4,r4,s4,u2,w1,w2,x3]).
myRule(v4, [f1,r4,t1,v2,x3]).
myRule(v4, [a2,c1,e4,p2,r3,s4,w2,y3]).
myRule(v4, [d3,e4]).
myRule(v4, []).
myRule(v4, [a2]).
myRule(v4, [c2,c4,d1,f3]).
myRule(v4, [q4]).
myRule(r3, []).
myRule(r3, [a3,a4,b3,d1,d2,e2,f1,f3,y2]).
myRule(t1, [u1,u2,v2,x2,z2]).
myRule(t1, []).
myRule(t1, [a3,p2,v3,x2,y2]).
myRule(t1, [c1,d4,e4,f2,u2,v2,w1]).
myRule(t1, [a2,q1,r4,y2,y3]).
myRule(y3, [a3,c1,c3,e2]).
myRule(y3, [a1,a4,c3,s4,z2]).
myRule(y3, []).
myRule(y3, [b4,e2,f4,w2]).
myRule(y1, [a1,a4,c4,d1,e1,e3,e4,v3]).
myRule(y1, [d2,r4]).
myRule(y1, [c1,f1,f4,s4,w2,z3]).
myRule(y1, [a4,d2,w1]).
myRule(y1, []).
myRule(u2, [b4,d1,x3]).
myRule(u2, [c3,f1]).
myRule(u2, []).
myRule(u2, [d4]).
myRule(w1, [b2,p2,q1,q4,u1,w2,x2,y2,z2]).
myRule(w1, []).
myRule(w1, [z2]).
myRule(x3, [b3,b4,e4,u1,u4,z3]).
myRule(x3, []).
myRule(x3, [b4,c3,f3]).
myRule(x3, [b1,b3,e1,r4,s4,z2,z3]).
myRule(x3, [a2,c2]).
myRule(x3, [b1]).
myRule(x3, [q4,x2]).
myRule(q1, [a2,b2,e2,f2,u4,v2,y2]).
myRule(q1, [c2,c3,d4,e2,f4,r4]).
myRule(q1, []).
myRule(x2, [a2,a4,c3,c4,d2,e2,q4,z2]).
myRule(x2, [a3,a4,b4,e3,u4,v2,v3,z2,z3]).
myRule(u4, [a2,a4,c1,u1,z2]).
myRule(u4, [a3,b2,b3,b4,c2,d2,e1,r4,s4]).
myRule(y2, [f4,u1,v3,z3]).
myRule(y2, [e3,f3]).
myRule(y2, [b3]).
myRule(y2, [f1,f2,p2,r4,s4,u1,w2,z3]).
myRule(y2, [a2,b2,b4,c1,c3,c4,d1,e2]).
myRule(y2, [p2,s4,u1,v2,z3]).
myRule(v2, [a2,a4,b1,b3,e1,u1,v3,w2]).
myRule(v2, [b4,f4,w2]).
myRule(v2, [c1,c2]).
myRule(v2, [c3,f1]).
myRule(v2, [b1,b3,c4,d1,f1,f4,w2]).
myRule(v2, [a1,b3,c2,d2,d3,d4,e4,f3]).
myRule(v2, [c2,e1,q4,r4,u1,v3,w2,z2,z3]).
myRule(p2, [a4,c1,c4,e3]).
myRule(p2, [a1,a4,b2,c2,d2,d4,q4,v3,z3]).
myRule(p2, [b1,c4,e2,f1,f3]).
myRule(p2, [b1,c1,c3,e4]).
myRule(p2, [v3]).
myRule(p2, [b4,r4,s4,u1,v3,w2,z2]).
