
myAsm(a).
myAsm(b).
myAsm(c).
myAsm(d).
myAsm(e).
myAsm(f).

contrary(a, q).
contrary(b, f).
contrary(c, u).
contrary(d, v).
contrary(e, v).
contrary(f, v).

myRule(p, [a,u]).
myRule(q, [b,r]).
myRule(q, [c,s]).
myRule(q, [c,t]).
myRule(u, [a]).
myRule(s, []).
myRule(t, [d]).
myRule(t, [e]).
