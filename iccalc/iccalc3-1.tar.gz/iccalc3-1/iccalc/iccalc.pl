
% File:     iccalc.pl
% Version:  3.1
% Author:   Robert Craven, rac101@doc.ic.ac.uk
% Author:   Marek Sergot, mjs@doc.ic.ac.uk
% Language: Prolog
% Date:     25/10/06, 14/06/08, 31/01/09, May 2009, 28/08/10, 3/11/10

/*

Sections of the code:

 1: Initializations, Declarations, Options
 2: loadf and simple subsidiary predicates
 3: statistics
 4: preloading
 5: readf
 6: syntax for source files
 7: process_readf_terms
 8: process_nCplus
 9: processing the signature, making integers
10: simple predicates to get information about constants
11: processing nCplus rules
12: parser - nC+/C+ timed laws to internal representation
13: control of low-level parsing/stamping predicates
14: low-level parsing/stamping predicates
15: rules to clause store
16: mvc to boolean
17: make and store completion clauses
18: cnf and dnf, base and simple cases
19: cnf and dnf, modified CCalc optimized version
20: cnf and dnf utilities
21: displaying features of the action description
22: query processing, top level
23: parse and dispatch query
24: basic query loop iterating over times
25: input for sat-solvers, calling, and call for solution processing
26: processing clasp output
27: clp(b) solver
28: display of models
29: writing transition system to files (graph/prolog)
30: queries to dot
31: causal_network [NOT DONE]
32: mcLUCA interface
33: errors
34: final initialisations

VISIBLE predicates (for module declaration, later):

set_opt/2
options/0
loadf/1
reloadf/0
hidden/1
show/1
action_desc_type/1
info_out/0
info/0
loadf/0
loadf_info/1
agents/0
signature/0
show_causal_laws/0
queries/0
show_grounded_rules/0
query/1
query/2
builtin_query/1
display_models/0
trans2dot/0
trans2prolog/0
q2dot/1
q2dot/2
help/0
help/1

*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 1: Initializations, Declarations, Options
%
% PREDICATES DEFINED:
%  - icc_option/2
%  - set_opt/2
%  - set_directories/0
%  - options/0
%  - set_iccvar/2
%  - remove_iccvar/1
%  - incr_iccvar/3
%  - incr_iccvar/2
%  - notCplus/0
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% initialize for different Prologs: sicstus, sicstus4, yap, swi

:-
 dynamic
  iccvar/2.

:-
 assert(iccvar(iccalc_version, 3.1)),
 (prolog_flag(dialect, BaseDialect) ; prolog_flag(language, BaseDialect)),
 (
  (BaseDialect = sicstus, prolog_flag(version_data, sicstus(4,_,_,_,_)))
  -> Dialect = sicstus4
  ;  Dialect = BaseDialect
 ),  
 atom_concat('iccalc.', Dialect, DialectFile),
 (
  ensure_loaded(DialectFile)
  -> assert(iccvar(prolog_version, Dialect))
  ;  format('Unknown Prolog dialect: ~w. This may not work.~n', [Dialect]),
     assert(iccvar(prolog_version, unknown))
 ).

%%%%% compile the help files

:-
 ensure_loaded('iccalc.help'). 

%%%%% possibly unknown predicates

:- multifile user:unknown_predicate_handler/3.

user:unknown_predicate_handler(aglist_strand(_,_,_),user,fail). % mcLUCA
user:unknown_predicate_handler(mcluca_var(_,_),user,fail).      % mcLUCA

%%%%% dynamic declarations

:-
 dynamic
  icc_option/2,
  
  readf_term/4,
  variable_rule/2,
  user_predicate/2,

  loadf_comments/1,
  
  agentlist/1,
  icc_dom/6,       
   
  atom_integer/4,
  aux_var_integer/2, 
   
  shiftable_rule/3,

  rule_body/2,
  completion_if_clause/2,
  completion_onlyif_clause/2,
  
  sat_model/1,
  
  state/2,
  trans/4,
  trans_event_label/2.

%%%%% operator precedences

:- op(1170, fx,  [loadf,
                  query,
                  q2dot,
                  show,
                  hidden]).
:- op(1175, fx, [count]). % enabling count query(X)
:- op(1110, xfx, [::,
                  notpermitted]).
:- op(1030, fx,  [caused,
                  default,
                  exogenous,
                  inertial,
                  nonexecutable,
                  constraint,
                  always,
                  rigid,
                  notpermitted,
                  oblig,
                  policy,
                  top]).
:- op(1030, xfx, [causes,
                  maycause]).
:- op(1025, xfx, [@]).
:- op(1020, xfx, [if]).
:- op(1010, xfx, [after,
                  unless]).
:- op(760,  xfy, [++,
                  &,
                  meet,
                  join,
                  or,
                  and]).
:- op(710,  xfy, [:]).                  % overrides Prolog precedence 550
:- op(540,  xfx, [..]).
:- op(300,  fy,  [~,
                  not,
                  neg]).
:- op(200,  fy,  [+,
                  -]).
:- op(200,  xfy, [^]).

% Note: For queries and mcLUCA operators we need ':'
% to have precedence looser than = (700) 
% and stronger than & (760) and ++ (770)
% So we go for 710. However. ...
%
% We can't win. 
% We want lam(k):p=v to be read as lam(k):(p=v). So = must bind tighter
% than :. We want -lam(k):p=v to be read as -(lam(k):(p=v)) but 
% we get (-lam(k)):(p=v) instead.
% On the other hand, if we take standard Prolog prcedence 550 for :
% then lam(k):p=v comes out as (lam(k):p)=v. Horrible. And
% -lam(k):p=v comes out as ((-lam(k)):p)=v.
% Even worse, lam(k):lam(m):p=v comes out as (lam(k):(lam(m):p))=v.
% That's no good at all, especially for mcLUCA. We would have to
% write lam(k):lam(m):(p=v).
% 
% So ... we make precedence of : weaker than =. Now we have to ensure
% that in any parsing, (-Op):F gets transformed to -(Op:F) before parsing.% 

%%%%% icc_option/2 :: default options

icc_option(ag_strand_functor, ^).
icc_option(boolean_symbols, [tt,ff]).
icc_option(ccalc_optimize_clause_gen, 1).
icc_option(disp_states_in_trans_only, 1).
icc_option(dot2ps, 1).
icc_option(dot_options, dotA4).
icc_option(model_item_sep, '\n'). % '\n' or ''
icc_option(ncplus_symbols, [status,trans,green,red]).
icc_option(num_models, all).
icc_option(remove_tautologies, 1).
icc_option(show_boolean, 0).
icc_option(show_neg, 0).
icc_option(solver, clasp).
icc_option(stats, 1).
icc_option(view_ps, 1).
icc_option(viewer, evince).
icc_option(dir:domains, '../domains/').
icc_option(dir:domainsbase, '../domains/').
icc_option(dir:solvers, '../solvers/').
icc_option(dir:tmp, '/tmp/').
icc_option(dir:working, './').
icc_option(colour(status, green), '#86d97b').
icc_option(colour(status, red), '#d04233').
icc_option(colour(trans, green), '#86d97b').
icc_option(colour(trans, red), '#d04233').

%%%%% set_opt/2 :: sets an option's value :: VISIBLE

set_opt(Opt, Val) :-
 retractall(icc_option(Opt,_)),
 assert(icc_option(Opt, Val)).

%%%%% set_directories/0

set_directories :- 
 iccvar(iCCalc_dir, SOURCEDIR),
 remove_version_dir(SOURCEDIR, ICCALCDIR), 
 !,
 atom_concat(ICCALCDIR, 'domains/', DOMAINSBASE),
 atom_concat(ICCALCDIR, 'solvers/', SOLVERS),
 set_opt(dir:domains, './'),
 set_opt(dir:domainsbase, DOMAINSBASE),
 set_opt(dir:solvers, SOLVERS),
 set_opt(dir:working, './').

set_directories.

%%%%% remove_version_dir/2

remove_version_dir(SOURCEDIR, ICCALCDIR) :-
 atom_concat(X, '/', SOURCEDIR),
 filename_parts(X, ICCALCDIRNAME, _),
 atom_concat(ICCALCDIRNAME, '/', ICCALCDIR).

%%%%% domains/1 :: sets the domain dir

domains(X) :-
 icc_option(dir:domainsbase, BaseDomDir),
 atom_concat(BaseDomDir, X, NewDomDir),
 set_opt(dir:domains, NewDomDir).

%%%%% options/0 :: displays all options :: VISIBLE

options :-
 (
  findall(t(Opt,Val), icc_option(Opt, Val), List),
  list_to_ord_set(List, O_List),
  member(t(Opt, Val), O_List),
  format('~n  ~w~30|= ~k', [Opt,Val]),
  fail
  ;
  prolog_specific_space
 ).

%%%%% set_iccvar/2 :: set value of an iccvar

set_iccvar(Var, Val) :-
 remove_iccvar(Var),
 assert(iccvar(Var, Val)).

%%%%% remove_iccvar/1 :: remove all values of iccvar 'Var'

remove_iccvar(Var) :-
 retractall(iccvar(Var, _)).

%%%%% incr_iccvar/3 :: increments iccvar 'Var' by K; if not set, sets to K

incr_iccvar(Var, K, New) :-
 (
  iccvar(Var, Val)
  -> New is Val + K
  ;  New = K
 ),
 set_iccvar(Var, New).

%%%%% incr_iccvar/2 :: calls incr_iccvar/3 directly

incr_iccvar(Var, New) :-
 incr_iccvar(Var, 1, New).
  
%%%%% notCplus/0 :: for directive in source files CHECK

notCplus :- set_iccvar(notCplus, 1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 2: loadf and simple subsidiary predicates
%
% PREDICATES DEFINED:
%  - loadf/1
%  - reloadf/0
%  - find_full_filename/2
%  - postloading/2
%  - read_comments_header/2 
%    - read_first_line/2
%    - strip_leading_blanks/2
%    - get_comments_header/3
%  - filename_parts/2
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% loadf/1 :: basic loading :: VISIBLE

loadf('') :- !. % in case no arg passed from command line

% Explanation: Some users launch iCCalc using a command line script
% which executes the goal loadf($1) as soon as iCCalc sources are compiled.
% $1 is the script's first command line argument --
% the file to be loadf'ed.  

loadf(FilePartTuple) :-
 tuple_list(FilePartTuple, FilePartList),
 !,
 set_iccvar(fatal_error, false),
 find_full_filenames(FilePartList, FileList),
 iccvar(fatal_error, false),
 stats(_),
 preloading,
 readflist(FileList),
 !,
 process_readf_terms,
 stats(LoadMs),
 process_nCplus(ParseMs, CompMs),
 postloading(FilePartList, FileList),
 loading_statistics(FilePartList, LoadMs, ParseMs, CompMs),
 loadf,                                       % CHECK - rename later
 flush_output. 

%%%%% reloadf/0 :: reloads current file :: VISIBLE

reloadf :-
 iccvar(loadf_filenames,FilesList),
 !,
 tuple_list(Files, FilesList),
 loadf(Files).
reloadf :-
 format('No file currently loaded~n~n', []).

%%%%% find_full_filenames/2

find_full_filenames([], []).

find_full_filenames([FilePart|RestFileParts], [File|RestFiles]) :-
 find_full_filename(FilePart, File),
 !,
 find_full_filenames(RestFileParts, RestFiles).

%%%%% find_full_filename/2
%
% When a file is loadfed, try these directories in order:
%  - The current working directory in the Unix shell
%  - The value of the user-specified 'dir' option
%  - None (i.e. take File as an absolute filename)
%  - The directory from which CCalc was loaded
% If the file doesn't exist in any of these locations, return an error.

find_full_filename(FilePart, File) :-
 icc_option(dir:working, DirFull),
 atom_concat(Dir, '/', DirFull),
 absolute_file_name(FilePart, File,
                    [access(exist), file_errors(fail), relative_to(Dir)]).

find_full_filename(FilePart, File) :-
 icc_option(dir:domains, Dir),
 absolute_file_name(FilePart, File,
                    [access(exist), file_errors(fail), relative_to(Dir)]).

find_full_filename(FilePart, File) :-
 absolute_file_name(FilePart, File,
                    [access(exist), file_errors(fail)]).

find_full_filename(FilePart, File) :-
 iccvar(iCCalc_dir, Dir),
 absolute_file_name(FilePart, File,
                    [access(exist), file_errors(fail), relative_to(Dir)]).

find_full_filename(FilePart, _File) :-
 fatal_error("File \'~w\' not found.", [FilePart]).

%%%%% postloading/2

postloading([FilePart|RestFileParts], [File|RestFiles]) :-
 (
  iccvar(fatal_error,false)
  -> filenames_parts([FilePart|RestFileParts], [Path|_], [Base|RestBases]),
     set_iccvar(loadf_filenames, [FilePart|RestFileParts]),
     set_iccvar(files, [File|RestFiles]),
     set_iccvar(file_basenames, [Base|RestBases]),
     set_iccvar(mainfile, File),
     set_iccvar(mainfile_basename, Base),
     set_opt(dir:domains, Path),
     read_comments_header_loop([File|RestFiles], [], Comments),
     (
      Comments \= []
      -> assert(loadf_comments(Comments))
      ;  true
     )
  ;  true
 ).

%%%%% read_comments_header_loop

read_comments_header_loop([], Comments, Comments).

read_comments_header_loop([File|RestFiles], CommentsIn, Comments) :-
 open(File, read, Fd),
 (
  read_comments_header(Fd, FileComments),
  FileComments \= []
  -> (
      CommentsIn = []
      -> CommentsInSpace = CommentsIn
      ;  append(CommentsIn, "\n", CommentsInSpace)
     ),
     append(CommentsInSpace, FileComments, CommentsOut)
  ;  CommentsOut = CommentsIn
 ),
 read_comments_header_loop(RestFiles, CommentsOut, Comments).

%%%%%  read_comments_header/2 
%%%%%  read_first_line/2
%%%%%  strip_leading_blanks/2
%%%%%  get_comments_header/3

read_comments_header(Fd, String) :-
  read_first_line(Fd, X),
% [47,42] = "/*" 
% [126,110] = "~n"
  (X = [47,42|Line] ->
           get_comments_header(Line, Fd, String) ;
           close(Fd), String = []).
  
read_first_line(Fd,X) :-
  read_line(Fd,In),
  (In \= [] -> strip_leading_blanks(In,X) ; read_first_line(Fd, X) ).
  
strip_leading_blanks(In, X) :-
  (In = [32|Rest] -> strip_leading_blanks(Rest,X) ; X = In).
  

get_comments_header(end_of_file, Fd, _) :- !,
   close(Fd),
   fail.
get_comments_header(Line, Fd, String) :-
  append(X, [42,47|_], Line), !,
  (X = [] -> String = [126,110]; String = X),
  close(Fd).
get_comments_header(Line, Fd, String) :-
%   (Line = [] -> String = [126,110|RestString]; 
%                 append(Line, RestString,String) ),
  append(Line, [126,110|RestString],String),
  read_line(Fd, In), !,
  get_comments_header(In, Fd, RestString).
   

%%%%% filenames_parts/3

filenames_parts([], [], []).

filenames_parts([FileName|Rest], [Path|RestPaths], [Base|RestBases]) :-
 filename_parts(FileName, Path, Base),
 filenames_parts(Rest, RestPaths, RestBases).

%%%%% filename_parts/2 :: CHECK prologs don't have them - swi has base_name/2

filename_parts(FileName, Path, Base) :-
 atom_codes(FileName, FileNameString),
 reverse(FileNameString, RevFileName),
 append(RevBase, [47|RevPath], RevFileName),
 !,
 reverse(RevBase, BaseString),
 reverse(RevPath, PathString),
 atom_codes(Path, PathString),
 atom_codes(Base, BaseString).

filename_parts(FileName, '', FileName).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 3: statistics
%
% PREDICATES DEFINED:
%  - stats/1
%  - msecs_to_secs/2
%  - loading_statistics/4
%  - solution_statistics/4
%  - solution_statistics/5
%  - clasp_summary_stats/1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% stats/1

stats(Xms) :-
 statistics(runtime, [_,Xms]).

%%%%% msecs_to_secs/2

msecs_to_secs([], []).

msecs_to_secs([MS|RestMS], [S|RestS]) :-
 S is MS / 1000,
 msecs_to_secs(RestMS, RestS).

%%%%% loading_statistics/4 :: print loading times etc.

loading_statistics(FileList, _, _, _) :-
 icc_option(stats, 0),
 !,
 (
  member(File, FileList),
  format('~n\'~w\' loaded.', [File]),
  fail
  ;
  prolog_specific_space
 ).

loading_statistics(FileList, LoadMs, ParseMs, CompMs) :-
 (
  member(File, FileList),
  format('~n\'~w\' loaded.', [File]),
  fail
  ;
  nl,
  TotalMs is LoadMs + ParseMs + CompMs,
  msecs_to_secs([LoadMs,ParseMs,CompMs,TotalMs], [Loads,ParseS,Comps,Totals]),
  format('~nInitial loading:~28|~2f seconds (~w ms)', [Loads,LoadMs]),
  format('~nRule parsing:~28|~2f seconds (~w ms)', [ParseS,ParseMs]),
  format('~nClause completion:~28|~2f seconds (~w ms)', [Comps,CompMs]),
  format('~nTotal time:~28|~2f seconds (~w ms)', [Totals,TotalMs]),
  prolog_specific_space,
  iccvar(parse_errors, Errors),
  iccvar(parse_warnings, Warnings),
  format("Errors: ~w  Warnings: ~w", [Errors, Warnings]),
  prolog_specific_space
 ).

%%%% solution_statistics/4

solution_statistics(_,_,_,_) :-
 icc_option(stats, 0),
 !.

solution_statistics(Fd, ClauMs, SolMs, ReadMs) :-
 Ms is ClauMs + SolMs + ReadMs,
 msecs_to_secs([Ms,ClauMs,SolMs,ReadMs],[S,ClauS,SolS,ReadS]),
 format(Fd,'~nClause writing:~20|~2f seconds (~w ms)', [ClauS,ClauMs]),
 format(Fd,'~nSAT-solver:~20|~2f seconds (~w ms)', [SolS,SolMs]),
 format(Fd,'~nModel processing:~20|~2f seconds (~w ms)', [ReadS,ReadMs]),
 format(Fd,'~nTotal time:~20|~2f seconds (~w ms)', [S,Ms]),
 clasp_summary_stats(Fd),
 prolog_specific_space(Fd).

%%%%% solution_statistics/5

solution_statistics(_,_,_,_,_) :-
 icc_option(stats, 0),
 !.

solution_statistics(Fd, ClauMs, SolMs, ReadMs, ShowMs) :-
 Ms is ClauMs + SolMs + ReadMs + ShowMs,
 msecs_to_secs([Ms,ClauMs,SolMs,ReadMs,ShowMs],[S,ClauS,SolS,ReadS,ShowS]),
 format(Fd,'~nClause writing:~20|~2f seconds (~w ms)', [ClauS,ClauMs]),
 format(Fd,'~nSAT-solver:~20|~2f seconds (~w ms)', [SolS,SolMs]),
 format(Fd,'~nModel processing:~20|~2f seconds (~w ms)', [ReadS,ReadMs]),
 format(Fd,'~nModel printing:~20|~2f seconds (~w ms)', [ShowS,ShowMs]),
 format(Fd,'~nTotal time:~20|~2f seconds (~w ms)', [S,Ms]),
 clasp_summary_stats(Fd),
 prolog_specific_space(Fd).


%%%%% clasp_summary_stats/1

clasp_summary_stats(Fd) :-  
 (iccvar(temp_solver, clasp_quiet) ;
  icc_option(solver, clasp) ;
  icc_option(solver, clasp_quiet) ),
 !,
 format(Fd, '~n------~n', []),
 flush_output,
 icc_option(dir:tmp, TMP),
 atoms_concat(['tail -2 ',TMP,'iccalc.out'], TAILCALL),
 shell(TAILCALL,_),  % for now;  cf. process_clasp_quiet_output/1
 format(Fd, '------', []).
clasp_summary_stats(_Fd).


%%%%% atoms_concat/2

atoms_concat([X], X) :-
 !.

atoms_concat([X|Rest], Atom) :-
 atoms_concat(Rest, RestAtom),
 atom_concat(X, RestAtom, Atom).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 4: preloading
%
% PREDICATES DEFINED:
%  - preloading/0
%  - preloading_retractions/0
%  - quiet_abolish/1
%  - preloading_iccvar_settings/0
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% preloading/0 :: basic control for preloading

preloading :-
 preloading_retractions,
 preloading_iccvar_settings.

%%%%% preloading_retractions/0 

% Retract or abolish all predicates which we expect in a
% standard input file, and all predicates asserted
% subsequently in grounding, completion, etc.

preloading_retractions :-
 user_predicate(Func, Arity),
 common_abolish(Func, Arity),
 fail.

preloading_retractions :-
 retractall(user_predicate(_,_)),
 fail.

preloading_retractions :-
 iCCalc_predicate(Pred),
 quiet_abolish(Pred),
 fail.

preloading_retractions :-
 nCplus_functor(Pred),
 quiet_abolish(Pred),
 fail.

preloading_retractions :-
 retractall(loadf_comments(_)),

 quiet_abolish(nCplus_rule(_)),
 
 retractall(readf_term(_,_,_,_)),
 retractall(variable_rule(_,_)),
 
 retractall(agentlist(_)),
 retractall(icc_dom(_,_,_,_,_,_)),
   
 retractall(atom_integer(_,_,_,_)),
 retractall(aux_var_integer(_,_)),
 
 retractall(shiftable_rule(_,_,_)),
 retractall(rule_body(_,_)),
 retractall(completion_if_clause(_,_)),
 retractall(completion_onlyif_clause(_,_)),

 retractall(state(_,_)),
 retractall(trans(_,_,_,_)),
 retractall(trans_event_label(_,_)).
 
 %retractall(:-(policy_functor(X), pol_abbrev(X))).

%%%%% quiet_abolish/1 :: CHECK
%
% use this eventually. But now screws up if something left undefined  
% quiet_abolish(Pred) :-
%   (predicate_property(Pred,_) ->
%      functor(Pred,Functor,Arity), abolish(Functor,Arity) ; true).

quiet_abolish(Pred) :-
 retractall(Pred).

%%%%% preloading_iccvar_settings/0

preloading_iccvar_settings :-
 set_iccvar(is_cptimed, 0),
 remove_iccvar(is_ncplus),      % iccvar(is_ncplus,0) means something else
 set_iccvar(is_ag_stranded, 0),
 set_iccvar(is_pCplus, 0),
 remove_iccvar(pCplus_hasobl),
 set_iccvar(pdp_transparent, 0),
 set_iccvar(notCplus, 0),
 set_iccvar(parse_errors, 0),
 set_iccvar(parse_warnings, 0),    
 set_iccvar(max_tval, 0),
 set_iccvar(total_rule_count, 0),
 set_iccvar(aux_var_index, 0),  % for giving them a name
                                % these only need to be initialised once
                                % aux var atoms are timestamped during
                                % make completion clauses
 set_iccvar(n_aux_vars, 0),     % for counting which ones used in a query
                                % (and generating aux_var_integer table)
 remove_iccvar(n_clauses),
 remove_iccvar(n_models).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 5: readf
%
% PREDICATES DEFINED:
%  - readf/0
%  - process_fail/2
%  - tuple_list/2
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% readf/1 :: basic read loop for source files

readf(File) :-
 open(File, read, Fd),
 repeat,
  read_term(Fd, Term, [variable_names(VarPairs)]),
  process_fail(Term, VarPairs),
 close(Fd).

%%%%% readflist/1 :: basic read loop for list of source files

readflist([]).

readflist([File|Rest]) :-
 readf(File),
 readflist(Rest).

%%%%% process_fail/2 :: on-loading processing for terms from source files
%
% sorts clauses in the source file into 4 categories:
%  - clauses for variables
%  - clauses for causal laws
%  - clauses for other iCCalc-reserved predicates (signature etc)
%  - clauses for user-defined predicates
% the last three are stored as readf_term/4 facts; user-defined predicates
% have their functors and arities noted

process_fail(end_of_file, _) :-
 !.

process_fail(:-(Body), _) :-
 !,
 call(Body),
 fail.

process_fail((VarDec :: Body), VarPairs) :-
 !,
 tuple_list(VarDec, Vars),
 Vars = [KeyVar|_],
 (
  member(=(_, KeyVarCopy), VarPairs),
  KeyVar == KeyVarCopy
  ->
   member(Var, Vars),
   member(=(VarName, VarCopy), VarPairs),
   Var == VarCopy,
   Var = KeyVar,
   assert(:-(variable_rule(VarName, Var), Body))
 ),
 fail.

process_fail(:-(Head, Body), VarPairs) :-
 !,
 (
  nCplus_functor(Head)
  -> Flag = causal
  ;  (
      iCCalc_predicate(Head)
      -> Flag = iccalc
      ;  Flag = user,
         functor(Head, Func, Arity),
         (
          user_predicate(Func, Arity)
          -> true
          ;  assert(user_predicate(Func, Arity)) 
         )
     )
 ),
 assert(readf_term(Flag, Head, Body, VarPairs)),
 fail.

process_fail(Head, VarPairs) :-
 process_fail(:-(Head,true), VarPairs).


%%%%% tuple_list/2

tuple_list(X, Y) :-
 (
  var(Y)
  -> (
      var(X)
      -> Y = [X]
      ;
      X = (X1,X2)
      -> Y = [X1|Rest],
         tuple_list(X2, Rest)
      ;  Y = [X]
     )
  ;  Y = [Y1|Rest],
     (
      Rest = []
      -> X = Y1
      ;  X = (Y1,X2),
         tuple_list(X2, Rest)
     )
 ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 6: syntax for source files
%
% PREDICATES DEFINED:
%  - nCplus_functor/1
%  - iCCalc_predicate/1
%  - policy_functor/1
%
% use directives :- hidden(C) for hiding constants
% (show(C) later etc. undoes the effect of this)
%  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% nCplus_functor/1

nCplus_functor(caused(_)).
nCplus_functor(default(_)).
nCplus_functor(exogenous(_)).
nCplus_functor(inertial(_)).
nCplus_functor(causes(_,_)).
nCplus_functor(nonexecutable(_)).
nCplus_functor(constraint(_)).
nCplus_functor(always(_)).
nCplus_functor(rigid(_)).
nCplus_functor(maycause(_,_)).
nCplus_functor(notpermitted(_)).
nCplus_functor(notpermitted(_,_)).
nCplus_functor(oblig(_)).
nCplus_functor(<=(_,_)).

%%%%% iCCalc_predicate/1

iCCalc_predicate(fc(_)).
iCCalc_predicate(sdfc(_)).
iCCalc_predicate(ac(_)).
iCCalc_predicate(domain(_,_)).

iCCalc_predicate(agent(_)).
iCCalc_predicate(query(_,_,_)).
iCCalc_predicate(local_global).

iCCalc_predicate(pac(_)).
iCCalc_predicate(oblpac(_)).
iCCalc_predicate(pol_abbrev(_,_)).
iCCalc_predicate(@(_,_)).
iCCalc_predicate(policy(_)).
iCCalc_predicate(top(_)).
iCCalc_predicate(pdp_transparent).

%%%%% policy_functor/1

policy_functor(meet).
policy_functor(join).
policy_functor(neg).
policy_functor(and).
policy_functor(or).
policy_functor(not).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 7: process_readf_terms
%
% PREDICATES DEFINED:
%  - process_readf_terms/0
%  - replace_varnames/3
%  - transform_non_causal_head/3
%  - split_assert_policies/4
%  - process_policy/4
%  - get_policy_head/4
%
% We replace declared variables, if any, by extra conditions
% in the body, then assert (or write to temp file). 
% Causal laws (nC+ laws) will be asserted in nCplus_rule/1
% The body of every such clause will bind the vars when called.
% Non-causal laws (user-predicates, and iCCalc predicates  fc, 
% sdfc, ac, domain, etc) are asserted. 
% Asserting could be replaced by writing everything
% to a temp file and consult/compiling it. That would be better.
% If we do the latter, must remember to include a preamble of directives
% for unknown:predicate (which must be multifile). And remember that
% domain/2 must be declared dynamic.
% And turn discontiguous warning off temporarily before consult.
% Or just do it globally.
%
% Declared variables in user-defined clauses are not replaced if
% icc_option(expand_vars_in_Prolog,0)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% process_readf_terms/1

process_readf_terms :-
 readf_term(Type, Head, Body, VarNames),
 (
  Type = user, icc_option(expand_vars_in_Prolog,0)
  -> (Body = true -> assert(Head) ; assert(:-(Head,Body)) ),
     fail
  ;  true
 ),
 replace_varnames(VarNames, Body, ExpandedBody),
 (
  Type = causal
  -> transform_causal_head(Head, TransHead),
     assert(:-(nCplus_rule(TransHead), ExpandedBody))
  ;  transform_non_causal_head(Head, VarNames, TransHeadList),
     TransHeadList \= [],
     member(H, TransHeadList),
     assert(:-(H,ExpandedBody))
 ),
 fail.

process_readf_terms :-
 retractall(readf_term(_,_,_,_)).

%%%%% replace_varnames/3
%
% First argument is a list of equations of the
% form <VarName>=Var; if a clause in the input file
% had a variable T, then the pair 'T'=T will be in
% the list. Some of these variable names will be governed
% by variable_rule/2 clauses and we take account of this. 

replace_varnames([], ExpBody, ExpBody) :-
 !.

replace_varnames([=(VarName, Var)|RestVarNames], InBody, ExpBody) :- !,
 (
  clause(variable_rule(VarName, _), _) 
  -> OutBody = (variable_rule(VarName, Var), InBody)
  ;  OutBody = InBody
 ),
 !,
 replace_varnames(RestVarNames, OutBody, ExpBody).

%%%%% transform_non_causal_head/4

transform_non_causal_head(Head, VarNames, TransHeadList) :-
 Head =.. [Func|Args],
 (
  Func = (@)
  -> Args = [PolName,Policies],
     Policies =.. [{},PolicyTerm],
     split_assert_policies(PolicyTerm, PolName, VarNames, PosNeg),
     assert(policy(is(PolName, PosNeg))),
     TransHeadList = []
  ;
  Func = top
  -> (
      Args = [TopDf],
      TopDf =.. [is,PolName,PolDef]
      -> TransHeadList = [(top PolName),(policy PolName is PolDef)]

      ;  TransHeadList = [Head]
     )
  ;
  Func = pdp_transparent
  -> make_pdp_transparent,
     TransHeadList = []
  ;
     TransHeadList = [Head]
 ).

%%%%% split_assert_policies/4

split_assert_policies((PrePol, RestPrePol), PolName, VarNames, PosNeg) :-
 !,
 process_policy(PrePol, PolName, VarNames, _),
 split_assert_policies(RestPrePol, PolName, VarNames, PosNeg).

split_assert_policies(PrePol, PolName, VarNames, PosNeg) :-
 process_policy(PrePol, PolName, VarNames, PosNeg).

%%%%% process_policy/4

process_policy(:-(Head, Body), PolName, VarNames, PosNeg) :-
 !,
 get_policy_head(Head, PolName, PosNeg, PolicyHead),
 replace_varnames(VarNames, Body, ExpandedBody),
 assert(:-(nCplus_rule(PolicyHead), ExpandedBody)).

process_policy(Head, PolName, VarNames, PosNeg) :-
 !,
 get_policy_head(Head, PolName, PosNeg, PolicyHead),
 replace_varnames(VarNames, true, ExpandedBody),
 assert(:-(nCplus_rule(PolicyHead), ExpandedBody)).

%%%%% get_policy_head/4

get_policy_head(perm(X), PolName, pos, (caused perm(PolName,X))).
get_policy_head(denied(X), PolName, neg, (caused denied(PolName,X))).
get_policy_head((perm(X) if Conds), PolName, pos, (caused perm(PolName,X) if Conds)).
get_policy_head((denied(X) if Conds), PolName, neg, (caused denied(PolName,X) if Conds)).

%%%%% transform_causal_head/2

transform_causal_head(notpermitted(Ag, (Actions if Conditions)),
                      (caused red(Ag) if (Actions & Conditions))) :-
 !.

transform_causal_head(notpermitted(Ag, X), (caused red(Ag) if X)) :-
 !.

transform_causal_head(Head, Head).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 8: process_nCplus
%
% PREDICATES DEFINED:
%  - process_nCplus/2
%  - assert_policy_constants/0
%  - nCplus_dialect_checks/0
%  - ncplus_detected/1
%  - ag_stranded_detected/0
%  - add_policy_laws/0
%  - add_policy_defaults/0
%  - add_policy_allowed_laws/0
%  - policy_exp_eval/3
%  - policy_exp_eval/4
%  - policy_val/1
%  - basic_policy_val/2
%  - doPolEval/2
%  - ordPolEval/2
%  - make_policy_allowed_conditions/3
%  - make_policy_allowed_condition/3
%  - make_pdp_transparent/0
%  - check_desc_type/0
%  - check_stranded_mcluca/0
%
% Raw source clauses have already been processed to
% replace declared variables by grounding conditions
% in the body of nCplus_rule/1. 
% 
% Now we process nCplus_rule/1. First we add various 
% additional rules and domains necessary.
% Then we call nCplus_rule. Calling it grounds the vars
% and instantiates it.  We process each instantiation
% asserting rule and rule_schema rules.
% 
% Finally, we ground the rules produced during the previous phase,
% and make completion steps.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% process_nCplus/2

process_nCplus(ParseMs, CompMs) :-
 assert_policy_constants,
 nCplus_dialect_checks,
 process_signature,
 iccvar(fatal_error, false),
 make_atom_integer_map,
 add_policy_laws,
 process_nCplus_rules(Errors),
 check_desc_type,
 Errors = 0,
 !,
 stats(ParseMs),
 make_store_ncplus_rules,
 make_completion_clauses,
 stats(CompMs),
 check_stranded_mcluca.

process_nCplus(ParseMs, 0) :-
 stats(ParseMs),
 set_iccvar(fatal_error, true).

%%%%% assert_policy_constants/0
%
% need to do this here because ncplus_detected/1 needs
% to know exactly what constants exist

assert_policy_constants :-
 (
  iccvar(pdp_transparent, 1)
  -> assert(:-(ac(pdp(P, PAC)), (pac(PAC), policy(is(P,_))))),
     assert(:-(domain(pdp(P,PAC), V), (pac(PAC),
                                       policy(is(P,PosNeg)),
                                       \=(PosNeg, pos),
                                       \=(PosNeg, neg),
                                       !,
                                       policy_val(V)))),
     assert(:-(domain(pdp(P,PAC), V), (pac(PAC),
                                       policy(is(P,PosNeg)),
                                       basic_policy_val(PosNeg, V))))
  ;  true
 ),
 (
  predicate_property(oblpac(_), _),
  oblpac(_)
  -> set_iccvar(is_pCplus, 1),
     set_iccvar(pCplus_hasobl, 1),
     assert(:-(ac(AC), oblpac(AC))),
     assert(:-(ac(AC), (pac(AC), \+ oblpac(AC)))),
     assert(:-(pac(AC), oblpac(AC))),
     assert(:-(ac(obl(PAC)), oblpac(PAC))),
     assert(:-(ac(fulf(PAC)), oblpac(PAC))),
     assert(:-(ac(viol(PAC)), oblpac(PAC))),
     assert(:-(ac(perm(P, PAC)), (policy(is(P, pos)), pac(PAC)))),
     assert(:-(ac(denied(P, PAC)), (policy(is(P, neg)), pac(PAC)))),
     assert(:-(ac(S^req(Act)), pac(S^Act))),
     assert(:-(ac(allowed(PAC)), pac(PAC)))
  ;
  predicate_property(pac(_), _),
  pac(_)
  -> set_iccvar(is_pCplus, 1),
     set_iccvar(pCplus_hasobl, 0),
     assert(:-(ac(AC), pac(AC))),
     assert(:-(ac(perm(P, PAC)), (policy(is(P,pos)), pac(PAC)))),
     assert(:-(ac(denied(P, PAC)), (policy(is(P, neg)), pac(PAC)))),
     assert(:-(ac(S^req(Act)), pac(S^Act))),
     assert(:-(ac(allowed(PAC)), pac(PAC)))
  ;  true
 ).

%%%%% nCplus_dialect_checks/0
%
% (we already checked for pCplus above)

nCplus_dialect_checks :-
 (
  ncplus_detected(YesNo)
  -> set_iccvar(is_ncplus, YesNo)
  ;  true
 ),
 (
  ag_stranded_detected
  -> set_iccvar(is_ag_stranded, 1)
  ;  true
 ).

%%%%% ncplus_detected/1

ncplus_detected(0) :-
 icc_option(ncplus_symbols, [Status, Trans, _,_]),
 (
  aug_constant(Status)
  ;
  aug_constant(Trans)
 ),
 !.

ncplus_detected(1) :- 
 nCplus_rule(notpermitted(_)),

 !.

ncplus_detected(1) :-
 nCplus_rule(oblig(_)),
 !.

ncplus_detected(1) :-
 nCplus_rule((caused red(_) if _)).

%%%%% ag_stranded_detected/0

ag_stranded_detected :-
 agent(_),
% ag_stranded_ac(Ag,_,AgC),
% ac(AgC),
 !.

%%%%% add_policy_laws/0
%
% we need to add:
%  - the various defaults, depending on the signature
%  - the laws for allowed, using eval
% they are stored in nCplus_rule/1

add_policy_laws :-
 (
  iccvar(is_pCplus, 1)
  -> add_policy_defaults,
     add_policy_eval_laws
  ;  true
 ).

%%%%% add_policy_defaults/0

add_policy_defaults :-
 assert(:-(nCplus_rule(exogenous(S^req(Act))), pac(S^Act))),
 assert(:-(nCplus_rule(default(-PAC)), pac(PAC))),
 assert(:-(nCplus_rule(default(-perm(P, PAC))), (policy(is(P, pos)),
                                                 pac(PAC)))),


 assert(:-(nCplus_rule(default(-denied(P, PAC))), (policy(is(P, neg)),
                                                   pac(PAC)))),
 assert(:-(nCplus_rule(default(-allowed(PAC))), pac(PAC))),
 assert(:-(nCplus_rule(caused(if(S^Act, allowed(S^Act) & S^req(Act)))),pac(S^Act))),
 (
  iccvar(pCplus_hasobl, 1)
  -> assert(:-(nCplus_rule(default(-obl(PAC))), oblpac(PAC))),
     assert(:-(nCplus_rule(default(-fulf(PAC))), oblpac(PAC))),
     assert(:-(nCplus_rule(default(-viol(PAC))), oblpac(PAC))),
     assert(:-(nCplus_rule(caused(if(fulf(PAC),obl(PAC) & PAC))),oblpac(PAC))),
     assert(:-(nCplus_rule(caused(if(viol(PAC),obl(PAC)&(PAC)=ff))),oblpac(PAC))),
     assert(:-(nCplus_rule(caused(if(S^req(Act), obl(S^Act)))), oblpac(S^Act)))
  ;  true
 ).

%%%%% add_policy_allowed_laws/0
%
% get TopPol, then fiddle

add_policy_eval_laws :-
 top(TopPol),
 policy_exp_eval(TopPol, p, BasicPolicyValues),
 make_policy_allowed_conditions(BasicPolicyValues, PAC, AllowedConds),
 assert(:-(nCplus_rule(caused(if(allowed(PAC), AllowedConds))), pac(PAC))),
 fail.

add_policy_eval_laws :-
 iccvar(pdp_transparent, 1),
 policy(is(Pol,_)),
 policy_exp_eval(Pol, Val, BasicPolicyValues),
 make_policy_allowed_conditions(BasicPolicyValues, PAC, AllowedConds),
 assert(:-(nCplus_rule(caused(if(pdp(Pol,PAC)=Val, AllowedConds))), pac(PAC))),
 fail.

add_policy_eval_laws.

%%%%% policy_exp_eval/3

policy_exp_eval(Exp, V, BaseList) :-
 policy_exp_eval(Exp, V, [], List),
 findall(v(Pol,Val), (member(v(Pol,Val), List),
                    (policy(Pol is pos) ; policy(Pol is neg))),
              BaseList).

%%%%% policy_exp_eval/4

policy_exp_eval(Pol, V, InPolNames, OutPolNames) :-
 policy(is(Pol, Def)),
 Def \= pos,
 Def \= neg,
 !,
 (
  member(v(Pol, V), InPolNames)
  -> InPolNames = OutPolNames
  ;  policy_exp_eval(Def, V, InPolNames, MidPolNames),
     append(MidPolNames, [v(Pol,V)], OutPolNames)
 ).

policy_exp_eval(Exp, V, InPolNames, OutPolNames) :-
 once(predicate_property(pol_abbrev(_,_), _)),
 pol_abbrev(Exp, Def),
 !,
 policy_exp_eval(Def, V, InPolNames, OutPolNames).

policy_exp_eval(Exp, V, InPolNames, OutPolNames) :-
 Exp =.. [Func|[Arg1|PossArg2]],
 policy_functor(Func),
 !,
 policy_exp_eval(Arg1, V1, InPolNames, MidPolNames),
 (
  PossArg2 = [Arg2]
  -> policy_exp_eval(Arg2, V2, MidPolNames, OutPolNames),
     EvalTerm =.. [Func,V1,V2],
     doPolEval(EvalTerm, V)
  ;  OutPolNames = MidPolNames,
     EvalTerm =.. [Func,V1],
     ordPolEval(EvalTerm, V)
 ).

policy_exp_eval(BasicPol, V, InPolNames, OutPolNames) :-
 policy(is(BasicPol, PosNeg)),
 (PosNeg = pos ; PosNeg = neg),
 !,
 (
  member(v(BasicPol, V), InPolNames)
  -> InPolNames = OutPolNames
  ;  basic_policy_val(PosNeg, V),
     append(InPolNames, [v(BasicPol,V)], OutPolNames)
 ).

%%%%% policy_val/1

policy_val(p).
policy_val(d).
policy_val(na).
policy_val(in).

%%%%% basic_policy_val/2

basic_policy_val(pos, p).
basic_policy_val(neg, d).
basic_policy_val(_, na).

%%%%% doPolEval/2

doPolEval(Exp, V) :-
 Exp =.. [Func,X,Y],
 (
  X @=< Y
  -> ordPolEval(Exp, V)
  ;  ExpRev =.. [Func,Y,X],
     ordPolEval(ExpRev, V)
 ).

%%%%% ordPolEval/2

ordPolEval(d meet in, d).
ordPolEval(d meet na, na).
ordPolEval(d meet p, na).
ordPolEval(in meet na, na).
ordPolEval(in meet p, p).
ordPolEval(na meet p, na).
ordPolEval(X meet X, X).

ordPolEval(d join in, in).
ordPolEval(d join na, d).
ordPolEval(d join p, in).
ordPolEval(in join na, in).
ordPolEval(in join p, in).
ordPolEval(na join p, p).
ordPolEval(X join X, X).

ordPolEval(neg d, d).
ordPolEval(neg in, na).
ordPolEval(neg na, in).
ordPolEval(neg p, p).

ordPolEval(d and in, d).
ordPolEval(d and na, d).
ordPolEval(d and p, d).
ordPolEval(in and na, d).
ordPolEval(in and p, in).
ordPolEval(na and p, na).
ordPolEval(X and X, X).

ordPolEval(d or in, in).
ordPolEval(d or na, na).
ordPolEval(d or p, p).
ordPolEval(in or na, p).
ordPolEval(in or p, p).
ordPolEval(na or p, p).
ordPolEval(X or X, X).

ordPolEval(not d, p).
ordPolEval(not in, in).
ordPolEval(not na, na).
ordPolEval(not p, d).

%%%%% make_policy_allowed_conditions/3

make_policy_allowed_conditions([], _, true) :-
 !.

make_policy_allowed_conditions([Val], PAC, Cond) :-
 !,
 make_policy_allowed_condition(Val, PAC, Cond).

make_policy_allowed_conditions([Val|Rest], PAC, Cond & RestConds) :-
 !,
 make_policy_allowed_condition(Val, PAC, Cond),
 make_policy_allowed_conditions(Rest, PAC, RestConds).

%%%%% make_policy_allowed_condition/3

make_policy_allowed_condition(v(Pol,p), PAC, perm(Pol, PAC)) :-
 !.


make_policy_allowed_condition(v(Pol,d), PAC, denied(Pol, PAC)) :-
 !.

make_policy_allowed_condition(v(Pol,na), PAC, Cond) :-
 !,
 (
  policy Pol is pos
  -> Cond = -(perm(Pol, PAC))
  ;  Cond = -(denied(Pol, PAC))
 ).

%%%%% make_pdp_transparent/0

make_pdp_transparent :-
 set_iccvar(pdp_transparent, 1).

%%%%% check_desc_type/0

check_desc_type :-
 (
  iccvar(notCplus, 1),
  action_desc_type(Ctype)
  -> format("~nSORRY. This is ~w. Not supported in this version~n~n",[Ctype]),
     fail
  ;  true
 ).

%%%%% check_stranded_mcluca/0

check_stranded_mcluca :- 
 (
%  iccvar(is_ag_stranded,1),
  mcluca_var(mcluca,on)
  -> mcluca_compilations
  ;  true
 ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 9: processing the signature, making integers
%
% PREDICATES DEFINED:
%  - process_signature/0
%  - assert_agents/0
%  - assert_boolean_domains/0
%  - assert_icc_dom/0
%  - assert_ncplus_domains/0
%  - make_atom_integer_map/0
%
% The basic fact for constants is icc_dom(C, Sig, Type, Dom, DomLen, Nbits)
% where:
%  - Sig is 'state' or 'trans'
%  - Type is 'fc', 'sdfc' or 'ncplus' if Sig is 'state'
%  - Type is 'ac' or 'ncplus if Sig is 'trans'
%  - Dom is a list of the values in the domain
%  - DomLen is the size of the domain
%  - Nbits is the number of bits needed to represent the value ?? CHECK
%
% NOTE: (LEFT TO DO), MJS
% we need to check here or elsewhere that there is
% no mismatch between use of status/trans and ncplus. 
% Check that status/trans are not user declared constants
% while notpermitted/oblig somewhere in the source.
% Most of this is done already but we need to generate a (fatal)
% error message.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% process_signature/0

process_signature :-
 assert_agents,
 assert_stranded_ncp_acs,
 assert_boolean_domains,
 assert_icc_dom,
 assert_ncplus_domains.

%%%%% assert_agents/0

assert_agents :-
 (
  iccvar(is_ag_stranded, 1)
  -> findall(Ag, agent(Ag), AgListX),
     remove_duplicates(AgListX, AgList),
     assert(agentlist(AgList))
  ;  true
 ).

%%%%% assert_stranded_ncp_acs/0

assert_stranded_ncp_acs :-
 (
  iccvar(is_ncplus, 1),
  iccvar(is_ag_stranded, 1),
  nCplus_rule((caused red(_) if _)),
  agent(X),
  \+ ac(red(X))
  -> assert(:-(ac(red(Ag)), agent(Ag)) )
  ;  true
 ).

%%%%% assert_boolean_domains/0
%
% for each Boolean constant C, where Tval and Fval are the desiganted
% Boolean values, assert:
%  domain(C, Tval)
%  domain(C, Fval)
%  icc_dom(C, Sig, Type, [Tval,Fval], 2, 1)

assert_boolean_domains :-
 icc_option(boolean_symbols, [Tval, Fval]), 
 aug_constant(C, Sig, Type),
 (
  ground(C)
  -> true
  ;  format("ERROR: ~w constant ~q is not ground~n", [Sig, C]),
     set_iccvar(fatal_error, true),
     fail
 ),
 Type \= ncplus,
 \+ domain(C, _),
 assert(domain(C, Tval)),
 assert(domain(C, Fval)),
 (
  icc_dom(C, _,_,_,_,_) 
  -> true
  ;  assert(icc_dom(C, Sig, Type, [Tval,Fval], 2, 1)) 
 ),
 fail.

assert_boolean_domains.

%%%%% assert_icc_dom/0
%
% for each non-Boolean, non-ncplus constant, assert an icc_dom/6 fact

assert_icc_dom :-
 aug_constant(C, Sig, Type),
 (
  ground(C)
  -> true
  ;  format("ERROR: ~w constant ~q is not ground~n", [Sig, C]),
     set_iccvar(fatal_error, true),

     fail
 ),
 \+ icc_dom(C, _, _, _, _, _),
 Type \= ncplus,
 findall(V, domain(C,V), Values),
 Values \= [],
 (
  ground(Values)
  -> true
  ;  format("ERROR: domain of ~w constant ~q is non-ground~n", [Sig, C]),
     set_iccvar(fatal_error, true),
     fail
 ),
 remove_duplicates(Values, Dom),
 length(Dom, N),
 logEval(2,N,Result),
 NBits is integer(ceiling(Result)),
 (icc_dom(C,_,_,_,_,_) 
  -> true
  ;  assert(icc_dom(C,Sig,Type,Dom,N,NBits))
 ),
 fail.

assert_icc_dom.  

%%%%% assert_ncplus_domains/0
%
% for each ncplus constant, assert an icc_dom/6 fact

assert_ncplus_domains :-
 (
  iccvar(is_ncplus, 1)
  -> (
      icc_option(ncplus_symbols, [Status, Trans, Green, Red]),
      ground([Status, Trans, Green, Red]), !,
      assert(domain(Trans, Red)),
      assert(domain(Trans, Green)),
      assert(domain(Status, Red)),
      assert(domain(Status, Green)),
      assert(icc_dom(Status, state, ncplus, [Green,Red], 2, 1) ),
      assert(icc_dom(Trans, trans, ncplus, [Green,Red], 2, 1) )
      ;
      format("ERROR: ncplus symbols not set correctly in options.std~n", []),
      set_iccvar(fatal_error, true)
     )
  ;  true
 ).

%%%%% make_atom_integer_map/0
%
% The order of atoms does not matter for converting atoms to dimacs (integers)
% but it does matter when processing models, since they are represented as a
% list of bits (0, 1). We maintain a standard order for export to other
% applications.
% 
%       simple fc's
%       sdfc's
%       ncplus (status)   <-    n_state_vars
%       ac's  agent 1
%        :
%       ac's  agent n
%       other ac's
%       ncplus  (trans)  <-    n_trans_vars
%       
% So action (trans) constant/atoms numbered from 
% n_state_vars+1 to n_state_vars+n_trans_vars
%
% The number of bool vars in the theory depends on the query.
% If query time is T it is 
%     n_state_vars + T*(n_state_vars+n_trans_vars)
% and the total number of bool vars given in input to clasp will be
% that number + number of extra aux vars (if any) introduced by cnf/dnf.
%
% The corresponding table aux_var_integer for auxiliary vars introduced
% by cnf/dnf during generation of completion clauses will be set up
% when clauses are written to dimacs (integer) during query processing.
% We don't need the indices for processing models but we DO need to know
% which bits in the model represent which mvc atoms. For that purpose
% we record at the very end list (sorted, no dups) of indices for the
% two categories of mvc atom.

% state constants

make_atom_integer_map :-
 set_iccvar(n_state_vars, 0),
 member(Type, [fc,sdfc,ncplus]),
 icc_dom(C, state, Type, _, _, Nbits),
 iccvar(n_state_vars, PrevN),
 N is PrevN + 1,
 assert(atom_integer(C, state, N, Nbits)),
 incr_iccvar(n_state_vars, Nbits, _),
 fail.

% agent-stranded action constants

make_atom_integer_map :-
 iccvar(n_state_vars, Nstate),
 set_iccvar(n_trans_vars,0),
 agentlist(Agents),
 member(Ag, Agents),
 ag_stranded_ac(Ag,_C,AgC),
 icc_dom(AgC, trans, ac, _, _, Nbits),
 iccvar(n_trans_vars, PrevN),
 N is Nstate + PrevN + 1,
 assert(atom_integer(AgC, trans, N, Nbits)),
 incr_iccvar(n_trans_vars, Nbits, _),
 fail.

% non-agent-stranded action constants

make_atom_integer_map :-
 iccvar(n_state_vars,Nstate),
 icc_dom(C,trans, ac, _, _, Nbits),
 (
  ag_stranded_ac(Ag,_,C), agent(Ag)
  -> fail
  ;  true
 ),
 iccvar(n_trans_vars, PrevN),
 N is Nstate + PrevN + 1,
 assert(atom_integer(C, trans, N, Nbits)),
 incr_iccvar(n_trans_vars, Nbits, _),
 fail.

% ncplus trans constants
 
make_atom_integer_map :-
 iccvar(n_state_vars,Nstate),
 icc_dom(C,trans, ncplus, _, _, Nbits),
 iccvar(n_trans_vars, PrevN),
 N is Nstate + PrevN + 1,
 assert(atom_integer(C, trans, N, Nbits)),
 incr_iccvar(n_trans_vars, Nbits, _),
 fail.

% collect state and trans integers together
 
make_atom_integer_map :-
 setof(Ns, A^B^atom_integer(A, state, Ns, B), StateNs), 
 (
  setof(NNs, AA^BB^atom_integer(AA, trans, NNs, BB), TransNs)
  -> true
  ;  TransNs = []
 ),
 set_iccvar(state_integers, StateNs),
 set_iccvar(trans_integers, TransNs).
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 10: simple predicates to get information about constants
%
% PREDICATES DEFINED:
%  - aug_constant/3
%  - ag_stranded_ac/3
%  - boolean_domain/1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% aug_constant/3

aug_constant(C, state, fc) :-
 fc(C).

aug_constant(C, state, sdfc) :-
 sdfc(C).

aug_constant(C, state, ncplus) :-
 iccvar(is_ncplus, 1),
 icc_option(ncplus_symbols, [C,_,_,_]).
 
aug_constant(C, trans, ac) :-
 ac(C).

aug_constant(C, trans, ncplus) :-
 iccvar(is_ncplus, 1),
 icc_option(ncplus_symbols,[_,C,_,_]).

aug_constant(C) :-
 aug_constant(C, _, _).

%%%%% ag_stranded_ac/3

ag_stranded_ac(Ag, C, Ag^C).

%%%%% boolean_domain/1

boolean_domain(C) :-
 icc_dom(C, _, _, Booleans, 2, 1),
 !,
 (
  icc_option(boolean_symbols, Booleans)
  -> true
  ;  fail
 ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 11: processing nCplus rules
%
% PREDICATES DEFINED:
%  - process_nCplus_rules/1
%  - process_causal_law/1
%  - law_family/5
%  - law_family/4
%  - process_law_family/2
%  - process_law_family_instances/3

%  - print_parse_errors/5
%
% This section has the main control for processing nCplus
% rules, process_causal_law/1. The members of law families
% are generated, and dealt with by calling process_causal_law/1
% again for them. The main dependent calls are to the parser,
% using parse_stamp_law/5, and to the store, rule_to_clause_store/4.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

process_nCplus_rules(_Errors) :-
 set_iccvar(parse_errors, 0),
 set_iccvar(parse_warnings, 0),    
 nCplus_rule(CausalLaw),        % should ground it but need to check no vars
 check_exogenous_nonred(CausalLaw),
 (
  ground(CausalLaw)
  -> process_causal_law(CausalLaw)
  ;  format("~nCausal law:~n  ~q~n", [CausalLaw]),
     format('** ERROR:~nCausal law is not ground.~n',[]),
     incr_iccvar(parse_errors,_)
 ),
 fail.

process_nCplus_rules(Errors) :-
 iccvar(parse_errors, Errors).

%%%%% check_exogenous_nonred/1

check_exogenous_nonred((exogenous AC if _)) :-
 !,
 AC \= red(_).

check_exogenous_nonred((exogenous AC)) :-
 !,
 AC \= red(_).

check_exogenous_nonred(_).

%%%%% process_causal_law/1
%
% This takes input ground law as stored in nCplus_rule, and processes

% families of causal laws: inertial, exogenous, rigid

process_causal_law(LawFamily) :-
 law_family(LawFamily, Law, _C=V1, Dom, ErrorsLawFamily),
 !,
 (
  ErrorsLawFamily = []
  -> Dom = [V1|_],      % Family now grounded; let the parser check the body
     parse_stamp_law(Law,_,_,_,Errors)
  ;  Errors = ErrorsLawFamily
 ),
 (
  member(error(_,_),Errors)
  -> format("~nCausal law:~n  ~q~n", [LawFamily]),
     format("ERRORS!~n",[]),
     print_parse_errors(Errors,0,0,W,_E),
     incr_iccvar(parse_errors,_),
     (
      W > 0
      -> incr_iccvar(parse_warnings,_)
      ;  true
     ),
     nl
  ;  process_law_family(LawFamily, Dom)
 ).

% causal laws

process_causal_law(Law) :- 
 parse_stamp_law(Law,Head,Body,T,Errors),
 !,
 (
  member(error(_,_),Errors)
  -> format("~nCausal law:~n  ~q~n", [Law]),
     format("ERRORS!~n",[]),
     print_parse_errors(Errors,0,0,W,_E1),
     incr_iccvar(parse_errors,_),
     (
      W > 0
      -> incr_iccvar(parse_warnings,_)
      ;  true
     ),
     nl
   ; (
      Errors = []
      -> true
      ;  format("~nCausal law:~n  ~q~n", [Law]),
         print_parse_errors(Errors, 0,0,W,_E2), % warnings
         (
          W > 0
          -> incr_iccvar(parse_warnings,_)
          ;  true
         )
     ),
     % we pass the original Law in case there are errors/warnings
     rule_to_clause_store(Head, Body, T, Law)  
 ).

%%%%% law_family/5
%
% given a law 'Law' that refers to a family of causal laws, return a
% generic member 'Family' parameterized (by 'V') prototype


law_family(Law, Family, C=V, Dom, ErrorsLaw) :-
 law_family(Law, Family, C=V, SigReqd), !,
 (
  icc_dom(C,Sig,_Type,Dom,_NDom,_Nbits)
  -> (
      SigReqd = state,
      Sig \= state
      -> ErrorsLaw = [error("~q must be a state (fluent) constant", [C])]
      ;  ErrorsLaw = []
     )
  ;  Dom = [],
     (
      (functor(C, if, _) ; functor(C, after, _)) 
      -> ErrorsLaw = [error("Not a valid form of law (~w)", [C])]
      ;  ErrorsLaw = [error("~q is not recognised (not a constant)", [C])]
     )
 ).

%%%%% law_family/4
%
% define the law families there are

law_family((rigid C), (caused false if C \= V after C=V), C=V, state).

law_family((exogenous C if G), (caused C=V if C=V & G), C=V, any).

law_family((exogenous C), (caused C=V if C=V), C=V, any).

law_family((inertial C if G), (caused C=V if C=V after C=V & G), C=V, state).

law_family((inertial C), (caused C=V if C=V after C=V), C=V, state).

%%%%% process_law_family/2

process_law_family(Law, Dom) :-
 law_family(Law, Instance, _C=V, _),
 !,
 process_law_family_instances(Instance,V,Dom).

%%%%% process_law_family_instances/3

process_law_family_instances(Instance,V,Dom)  :-
 member(V, Dom),  
 process_causal_law(Instance),
 fail.

process_law_family_instances(_,_,_).

%%%%% print_parse_errors/5

print_parse_errors([],W,E,W,E) :-
 !.
print_parse_errors([Error|Rest],W0,E0,W,E) :-
 (
  Error = error(Msg,Args)
  -> W1 = W0,
     E1 is E0 + 1,
     format(Msg, Args),
     nl
  ;
  Error = warning(Msg,Args)
  -> W1 is W0 + 1, E1 = E0,
     format("**Warning: ",[]),
     format(Msg, Args),
     nl
  ;  W1 = W0, E1 is E0 + 1,
     format("Strange error ~q",[Error]),
     nl
 ),
 !,
 print_parse_errors(Rest,W1,E1,W,E).
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 12: parser - nC+/C+ timed laws to internal representation
%
% PREDICATES DEFINED:
%  - append_together/2
%  - parse_stamp_law/5
%  - parse_stamp_abbrev
%
% parse_stamp_law/5 is the basic control predicate for transforming
% laws to the mvc(_,_,_,_,_,_) internal representation, and
% adding 0/1 time-stamps, and breaking apart heads and bodies.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% append_together/2

append_together([List], List) :-
 !.

append_together([List|Lists], Result) :-
 append(List, Remainder, Result),
 !,
 append_together(Lists, Remainder).

%%%%% parse_stamp_law/5

/**************
*************** OFFICIAL C+ syntax

Fluent formula: only fluent atoms (includes true and false).
Action formula: only action atoms, and at least one.
                (So true and false are not action formulas.)

Static law    
 caused F if G  (F and G are fluent formulas)
  
Action dynamic law
 caused A if H (A is an action formula, H is a formula)
   
   Note: 'caused false if H' where H is not fluent formula
   is neither a static law nor an action dynamic law.
   (So cannot say e.g caused false if alpha where alpha is an action atom.
   But note that is equivalently expressed caused false after alpha, 
   which is a fluent dynamic law.)
   
   caused F if H (F fluent, H mixed) is not a valid form of C+ law
   
Fluent dynamic law
 caused F if G after H (F and G are fluent formulas, H is a formula;
                        F must not contain sdfc's.)

***************
*************** C+ and C+timed abbreviations

 caused F
 = caused F if true (static or action dynamic law)

 caused F after H (fluent dynamic law)
 = caused F if true after H
     
 constraint F (static law)
 = caused false if -(F).
     
 constraint F after G (fluent dynamic law)
 = caused false if -(F) after G
     
 always F (fluent dynamic law)
 = caused false if true after -(F)
     
 nonexecutable F if G (F must be action formula)
 = F causes false if G
 = caused false if true after F & G
 
 nonexecutable F (F must be action formula)
 = nonexecutable F if true
 = F causes false

 F causes G if H (F must be an action (trans) formula)
 = [if G is a fluent formula]
   caused G if true after F & H (fluent dynamic law)
 = [if G is an action formula]
   caused G if F & H (action dynamic law)

 F causes G
 = F causes G if true
          
 default F if G
 = caused F if F & G

 default F
 = default F if true
 = caused F if F

 default F if G after H
 = caused F if F & G after H (fluent dynamic law)

 default F after H
 = default F if true after H
 = caused F if F after H
    
 F maycause G if H (F must be an action formula)
 = [if G is a fluent formula]
   default G after F & H
   caused G if G after F & H
 = [if G is an action formula]
   default G if F & H    
   caused G if G & F & H     
 
 F maycause G (F must be an action formula)
 = F maycause G if true
 = [if G is a fluent formula]
   default G after F
   caused G if G after F
 = [if G is an action formula]
   default G if F
   caused G if G & F

***************
*************** nC+    

 notpermitted F if G
 = [if F is state, G is state]
   caused status=red if F & G (static law)
 = [all other combinations]
   caused trans=red if F & G (action dynamic)

 NOTE: 
 If necessary the user can write directly e.g. caused status=red if G after H.

 notpermitted F
 = notpermitted F if true
     
 oblig F if G
 = notpermitted -F if G

*/

% caused

parse_stamp_law((caused F if G after H), Head, Body, T, Errors) :-
 !,   
 parse_stamp_fluent_dynamic(F, G, H, Head, Body, T, Errors). 
   
parse_stamp_law((caused _ if _ unless _), unsupp, unsupp, 0, Errors) :-
 !,  
 Errors = [error("'unless' not supported in this version", [])].
   
parse_stamp_law((caused F after G if H), Head, Body, T, Errors) :-
 !,   
 unrecognised_causal_term((caused F after G if H), Head, Body, T, Errors). 
   
parse_stamp_law((caused F after H), Head, Body, T, Errors) :-
 !,   
 parse_stamp_fluent_dynamic(F, true, H, Head, Body, T, Errors). 
   
parse_stamp_law((caused F if G), Head, Body, T, Errors) :-
 !,
 parse_stamp_causal_general(F, G, Head, Body, T, Errors).
   
parse_stamp_law((caused F), Head, Body, T, Errors) :-

 !,
 parse_stamp_causal_general(F, true, Head, Body, T, Errors).
   
% constraint

parse_stamp_law((constraint F after G), Head, Body, T, Errors) :-
 !,   
 parse_stamp_abbrev( (caused false if -(F) after G), Head, Body, T, Errors). 

parse_stamp_law((constraint F), Head, Body, T, Errors) :-
 !,   
 parse_stamp_abbrev( (caused false if -(F)), Head, Body, T, Errors). 
   
% always

parse_stamp_law((always F), Head, Body, T, Errors) :-
 !,   
 parse_stamp_abbrev( (caused false after -(F)), Head, Body, T, Errors). 
   
% nonexecutable

parse_stamp_law((nonexecutable F if G), Head, Body, T, Errors) :-
 !,   
 parse_stamp_abbrev( (F causes false if G), Head, Body, T, Errors). 

parse_stamp_law((nonexecutable F), Head, Body, T, Errors) :-
 !,   
 parse_stamp_abbrev( (F causes false), Head, Body, T, Errors). 

% causes

parse_stamp_law((F causes G if H), Head, Body, T, Errors) :-
 !,  
 parse_formula_sig(F, SigF, ErrorsF),
 parse_formula_sig(G, SigG, ErrorsG),
 (
  SigG = trans
  -> parse_stamp_abbrev( (caused G if F & H), Head, Body, T, ErrorsFull)
  ;  (SigG = state ; SigG = any)
     -> parse_stamp_abbrev( (caused G after F & H), Head, Body, T, ErrorsFull) 
     ;  parse_formula_sig(H, _SigH, ErrorsH),
        append_together([
         [error("~q must be a fluent formula ~nor an action formula", [G])],
         ErrorsF,
         ErrorsG,
         ErrorsH], ErrorsFull)
 ),
 (
  SigF = trans
  -> Errors = ErrorsFull 
  ;  Errors = [error("~q must be an action (trans) formula", [F])|ErrorsFull]
 ).

parse_stamp_law((F causes G), Head, Body, T, Errors) :-
 !,  
 parse_formula_sig(F, SigF, ErrorsF),
 parse_formula_sig(G, SigG, ErrorsG),
 (
  SigG = trans
  -> parse_stamp_abbrev( (caused G if F), Head, Body, T, ErrorsFull)
  ;  (SigG = state ; SigG = any)
     -> parse_stamp_abbrev( (caused G after F), Head, Body, T, ErrorsFull) 
     ;  append_together([
         [error("~q must be a fluent formula ~nor an action formula", [G])],
         ErrorsF,
         ErrorsG], ErrorsFull)
 ),
 (
  SigF = trans
  -> Errors = ErrorsFull 
  ;  Errors = [error("~q must be an action (trans) formula", [F])|ErrorsFull]
 ).
      
% default


parse_stamp_law((default F if G after H), Head, Body, T, Errors) :-
 !,   
 parse_stamp_abbrev( (caused F if F & G after H), Head, Body, T, Errors). 
   
parse_stamp_law((default F after G if H), Head, Body, T, Errors) :-
 !,   
 unrecognised_causal_term((default F after G if H), Head, Body, T, Errors). 
   
parse_stamp_law((default F after H), Head, Body, T, Errors) :-
 !,   
 parse_stamp_abbrev( (caused F if F after H), Head, Body, T, Errors). 
   
parse_stamp_law((default F if G), Head, Body, T, Errors) :-
 !,
 parse_stamp_abbrev( (caused F if F & G), Head, Body, T, Errors). 
   
parse_stamp_law((default F), Head, Body, T, Errors) :-
 !,
 parse_stamp_abbrev( (caused F if F), Head, Body, T, Errors). 

% may cause

parse_stamp_law((F maycause G if H), Head, Body, T, Errors) :-
 !,  
 parse_formula_sig(F, SigF, ErrorsF),
 parse_formula_sig(G, SigG, ErrorsG),
 (
  SigG = trans
  -> parse_stamp_abbrev( (caused G if G & F & H), Head, Body, T, ErrorsFull)
  ;  (SigG = state ; SigG = any)
     -> parse_stamp_abbrev((caused G if G after F & H),Head,Body,T,ErrorsFull) 
     ;  parse_formula_sig(H, _SigH, ErrorsH),
        append_together([
         [error("~q must be a fluent formula ~nor an action formula", [G])],
         ErrorsF,
         ErrorsG,
         ErrorsH], ErrorsFull)
 ),
 (
  SigF = trans
  -> Errors = ErrorsFull 
  ;  Errors = [error("~q must be an action formula", [F])|ErrorsFull]
 ).

parse_stamp_law((F maycause G), Head, Body, T, Errors) :-
 !,  
 parse_formula_sig(F, SigF, ErrorsF),
 parse_formula_sig(G, SigG, ErrorsG),
 (
  SigG = trans
  -> parse_stamp_abbrev( (caused G if G & F), Head, Body, T, ErrorsFull)
  ;  (SigG = state ; SigG = any)
     -> parse_stamp_abbrev( (caused G if G after F), Head, Body, T,ErrorsFull) 
     ;  append_together([
         [error("~q must be a fluent formula ~nor an action formula", [G])],
         ErrorsF,
         ErrorsG
         ], ErrorsFull)
 ),
 (
  SigF = trans
  -> Errors = ErrorsFull 
  ;  Errors = [error("~q must be an action formula", [F])|ErrorsFull]
 ).

% notpermitted

parse_stamp_law((notpermitted F if G), Head, Body, T, Errors) :-
 !,
 (
  icc_option(ncplus_symbols, [Status,Trans,_Green,Red]),
  iccvar(is_ncplus,1) 
  -> parse_formula_sig(F, SigF, _ErrorsF),
     parse_formula_sig(G, SigG, _ErrorsG),
     (
      (SigF = state ; SigF = any),
      (SigG = state ; SigG = any)
      -> parse_stamp_abbrev((caused Status=Red if F & G), Head, Body,T,Errors)
      ;  parse_stamp_abbrev( (caused Trans=Red if F & G), Head, Body,T,Errors)
     )
  ;  unrecognised_causal_term((notpermitted F if G), Head, Body, T, Errors)
 ).

parse_stamp_law((notpermitted F), Head, Body, T, Errors) :-
 !,
 (
  icc_option(ncplus_symbols, [Status,Trans,_Green,Red]),
  iccvar(is_ncplus,1) 
  -> parse_formula_sig(F, SigF, _ErrorsF),
     (
      (SigF = state ; SigF = any)
      -> parse_stamp_abbrev( (caused Status=Red if F), Head, Body, T, Errors)
      ;  parse_stamp_abbrev( (caused Trans=Red if F), Head, Body, T, Errors)
     )
  ;  unrecognised_causal_term((notpermitted F), Head, Body, T, Errors)
 ).   

% oblig

parse_stamp_law((oblig F if G), Head, Body, T, Errors) :-
 !,
 parse_stamp_abbrev((notpermitted -(F) if G), Head, Body, T, Errors).

parse_stamp_law((oblig F), Head, Body, T, Errors) :-
 !,
 parse_stamp_abbrev((notpermitted -(F)), Head, Body, T, Errors).

% catch all

parse_stamp_law(CausalTerm, Head, Body, T, Errors) :- 
 unrecognised_causal_term(CausalTerm, Head, Body, T, Errors).
  
unrecognised_causal_term(CausalTerm, unrececognised,unrecognised,0, Errors) :- 
 Errors = [error("Unrecognised law:~n~q",[CausalTerm])].

%%%%% parse_stamp_abbrev

parse_stamp_abbrev(Full, Head, Body, T, Errors) :-
 parse_stamp_law(Full, Head, Body, T, ErrorsFull),
 !,
 (
  ErrorsFull = []
  -> Errors = ErrorsFull
  ;  Errors = [error("~q",[Full])|ErrorsFull]
 ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 13: control of low-level parsing/stamping predicates
%
% PREDICATES DEFINED:
%  - parse_stamp_fluent_dynamic
%  - parse_stamp_causal_general
%
% The basic stamping/parsing predicate is parse_stamp_fmla/10,
% in the next section. But formulas go to form causal laws,
% and we need predicates to achieve the bridge; they are the
% two above.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% parse_stamp_fluent_dynamic/7 :: for C+ and C+ timed

% caused F if G & H 
% = [in C+ timed] caused F if G & lam(1):H
%   (Both F and G must be fluent formulas, and F must not contain sdfc's.)
% 
% We allow lam(_) expressions in H as a C+ timed abbreviation. If lam(_)
% expressions are encountered we set the is_cptimed flag (unless notCplus).
% 
% We treat this form (with key word 'after') as a special case in order
% to make error messages more specific, and to avoid setting is_cptimed
% unnecessarily when there are no lam(_) expressions in H.

parse_stamp_fluent_dynamic(F, G, H, StampF, StampG & StampH, T, Errors) :-
 
 % parse-stamp subformulas
 parse_stamp_fmla(F, TF0, StampF, SigF, HasSdfcF, TbindsF, LambdaF, _MaxAcFX, DomEqF, ErrorsF),
 parse_stamp_fmla(G, TG0, StampG, SigG, _HasSdfcG, TbindsG, LambdaG, _MaxAcGX, _DomEqG, ErrorsG),
 parse_stamp_fmla(H, TH0, StampH, _SigH, _HasSdfcH, TbindsH, LambdaH, _MaxAcHX, _DomEqH, ErrorsH),
   
 % bind the time stamps; values here can be obtained by unfolding
 % the special case for body G & lam(1):H
 Lambda is LambdaH + 1,
 TF0 = Lambda,
 TG0 = Lambda,
 TH0 = LambdaH,                 % = Lambda - 1
 eval_timestamps(TbindsF),
 eval_timestamps(TbindsG),
 eval_timestamps(TbindsH),
   
 T = Lambda,
      
 % perhaps detected C+timed (OR maybe not if this is notCplus)
 (
  LambdaF = 0,
  LambdaG = 0,
  LambdaH > 0,
  iccvar(notCplus,0)  
  -> set_iccvar(is_cptimed,1)
  ;  true
 ),

 % deal with all the errors
 (
  DomEqF = []
  -> append_together([ErrorsF,ErrorsG,ErrorsH],ErrorsFGH)
  ;  remove_duplicates(DomEqF,DomEqHead),
     (
      DomEqHead = [_] 
      -> DomEqErr = error("Expression ~q not allowed in head of a rule",DomEqHead)
      ;  DomEqErr = error("Expressions ~q not allowed in head of a rule",[DomEqHead])
     ),
     append_together([[DomEqErr|ErrorsF],ErrorsG,ErrorsH],ErrorsFGH)
 ),
 (
  (LambdaF > 0 ; LambdaG > 0) 
  -> Errors = [error("lam(_) expressions can only appear after 'after'",[])
               |ErrorsFGH]                  
  ;  % the main case: LambdaF = 0 and LambdaG = 0;
     % perhaps detected C+timed (OR not if this is notCplus)
     (
      LambdaH > 0,
      iccvar(notCplus,0)
      -> set_iccvar(is_cptimed,1)
      ; true
     ),
     (
      (SigF = state ; SigF = any)
      -> ErrorsSigF = []
      ;  ErrorsSigF = [error("Head (~q) must be a state (fluent) formula",[F])]
     ),
     (
      HasSdfcF = 1
      -> ErrorsSdfcF = [error("Head (~q) must not contain sdfc constants",[F])]
      ;  ErrorsSdfcF = []
     ),
     (
      (SigG = state ; SigG = any)
      -> ErrorsSigG = []
      ;  ErrorsSigG = [error("~q must be a state (fluent) formula",[G])]
     ),
     (
      ErrorsSigF = [],
      ErrorsSdfcF = [],
      ErrorsSigG = []
      -> Errors = ErrorsFGH
      ;  append_together([ErrorsSigF,ErrorsSdfcF,ErrorsSigG,ErrorsFGH],Errors)
     )
 ).
   
%%%%% parse_stamp_causal_general/6 :: general; covers C+, C+timed, notCplus

parse_stamp_causal_general(F, G, StampF, StampG, T, Errors) :-

 % parse-stamp subformulas
 parse_stamp_fmla(F, TF0, StampF, SigF, HasSdfcF, TbindsF, LambdaF, MaxAcFX, DomEqF, ErrorsF),
 parse_stamp_fmla(G, TG0, StampG, SigG, _HasSdfcG, TbindsG, LambdaG, MaxAcGX, _DomEqG, ErrorsG),
   
 % bind the time stamps; the usual C+, C+timed case has LambdaF=0 and we set
 % TG0 and TF0 to LambdaG. For nonCplus it might be the other way round.
 Lambda is max(LambdaF, LambdaG),
 TF0 = Lambda,
 TG0 = Lambda,
 eval_timestamps(TbindsF),
 eval_timestamps(TbindsG),
 MaxAcF is MaxAcFX,
 MaxAcG is MaxAcGX,
      
 % perhaps detected C+timed (OR maybe not if this is notCplus)
 (
  LambdaF = 0,
  LambdaG > 0,
  iccvar(notCplus,0)
  -> set_iccvar(is_cptimed,1)
  ;  true
 ),
 
 % deal with all the errors



 (
  DomEqF = []
  -> append(ErrorsF,ErrorsG,ErrorsFG)
  ;  remove_duplicates(DomEqF,DomEqHead),
     (
      DomEqHead = [_] 
      -> DomEqErr = error("Expression ~q not allowed in head of a rule",DomEqHead)
      ;  DomEqErr = error("Expressions ~q not allowed in head of a rule",[DomEqHead])
     ),
     append([DomEqErr|ErrorsF],ErrorsG,ErrorsFG)
 ),
 (
  LambdaF > 0
  -> (
      iccvar(notCplus,1) 
      -> Errors = ErrorsFG % anything allowed, except DomEqErr already checked
      ;  Errors = [error("lam(_) expressions not allowed in the head of a rule",[])
                   |ErrorsFG]
     )
  ;             % So LambdaF = 0; check C+ and C+timed constraints
                % unless iccvar(notCplus,1) 
     (
      iccvar(notCplus,1) 
      -> Errors = ErrorsFG
      ;  action_desc_type(Ctype),       % check C+ and C+timed
       
      % The rule  caused false if G  is allowed in C+timed even if G has
      % 'bare' action constants (action constant not inside scope of lam).
      % This is because false does not contain fluent constants. Strictly,
      % caused false if G  is not valid C+ law if G has action constants
      % because false is not an action formula: the rule is neither
      % action dynamic nor fluent dynamic. However, it behaves correctly if we
      % read it as a C+timed rule. So just a warning.

      % (SigG = trans ; SigG = mixed) could also be expressed MaxAcG > -1,
      % i.e. MaxAcG = 0 since we are considering the case LambdaG = 0
         (
          ErrorsFG =[],
          SigF = any,
          LambdaG = 0, 
          (SigG = trans ; SigG = mixed),
          iccvar(is_cptimed,0)
          -> Warning1 = [warning("This is a valid C+timed rule, ~nbut not valid C+ (behaves correctly)",[])]
          ; Warning1 = []
         ),
        
       % If F has fluent constants (it is state or mixed) G must have no
       % 'bare' ac's. This also covers C+ distinction between static/fluent
       % dynamic and action dynamic. G has bare ac's when MaxAcG = LambdaG
         (
          MaxAcG = LambdaG,
          (SigF=state ; SigF=mixed)
          -> ErrorSigF =
              [error("Not a valid ~w rule: Head has fluent constants~nand Body has 'bare' action constants",[Ctype])]
          ;  ErrorSigF = []
         ),
        
       % If F has sdfc's then the rule must be 'static'
       % In C+ timed this means no 'bare' ac in G
       % That also covers C+ requirement that G cannot be trans or mixed
         (
          HasSdfcF=1,
          MaxAcG = LambdaG
          -> WarningSdfc = [error("Not a valid ~w rule: Head has sdfc's ~nbut the rule is not 'static'",[Ctype])]
          ;  WarningSdfc = []
         ),
         append_together([Warning1,ErrorSigF,WarningSdfc,ErrorsFG], Errors)
     )
 ),
   
   % Now we calculate the time step T of the rule
   % For the C+ and C+timed case, Lambda=LambdaG.
   % For C+, Lambda=0 (static, action dynamic), 
   % Lambda=1 (fluent dynamic). max(MaxAcF,MaxAcG)=-1 if
   % rule has no action constants, and =0 otherwise.
   % So for C+, we get T=0 if rule is static with no action constants,
   % and T=1 otherwise. 
   
 T is max(Lambda, max(MaxAcF,MaxAcG)+1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 14: low-level parsing/stamping predicates
%
% PREDICATES DEFINED:
%  - parse_stamp_fmla/10
%  - eval_timestamps/1
%  - parse_formula_sig/3
%  - signature_of_formula/3
%  - parse_stamp_eq_fmla/8
%  - equivnot/2
%
% This parser does a number of things in one pass:
% 
% It converts atoms to their (time-stamped) internal representation,
% including C and -C for boolean constants C. 
% (-C for mvc constant with ff in its domain now deprecated.)
% 
% It puts the formula into negation normal form.
% 
% It puts the formula into lam(K) prenex form:
% it eliminates (possibly nested) lam(K) expressions and calculates
% LambdaMax.
% 
% It returns MaxAc, the max time stamp of an action atom (-1 if there
% are no action constants in the formula. This is useful for calculating
% the 'time step' of shiftable rules, and for checking various
% syntactic constraints on C+ and C+timed laws.
% 
% It determines the signature of the formula: state, trans, mixed, any.
% For checking C+, C+timed laws it is convenient to record whether the
% formula contains any sdfc constants. We also need to know whether there
% are any action constants outside the scope of a lam(K) (or the equivalent)
% but that can be determined from MaxAc.
% 
% It reports errors found (e.g., undeclared constant/value).
% Errors is a list of terms of the form
%        error(MsgFormat,Args) or warning(MsgFormat,Args)
% where the error message will be printed by a call to
%        format(MsgFormat,Args)
% 
% It detects special features e.g. trans=red, lam(K) and records
% them if necessary.
% 
% Some expressions are only allowed in the body of a C+ rule. 
% These are
%    C1=C2 C1\=C2(constants C1, C2)
%    lam: and lam(K) expressions.
% The latter are detected because then LambdaMax>0.
% For the former, parser returns list of C=V, C\=V expressions
% encountered, if any. It's the job of the rule parser to 
% determine whether these things are allowed or not in head of
% a rule.
% 
%%%%%% 
%
% C+ timed rules
% 
% The complication here is that we don't know the max value of the time stamps
% until we have parsed the rule. One way would be to go through first to
% calculate this value, then give that to the parser to work out time-stamps
% for lam(K) expressions. But instead we do it in one pass like this: the
% time-stamps will be expressions containing variables. Once the max lambda
% value is determined these variables bindings are calculated. MaxAc is the
% max time stamp of any action atom. It is an arithmetic expression to be
% evaluated at the end. (MaxAc is -1 if there are no action constants in the
% formula.)
% 
% Here is the basic idea with other features
% eliminated for clarity:
% 
%  parse_formula(F, N, StampF, MaxAcEx, LambdaMax) :-
%   parse_f(F, T0, StampF, Tbinds, MaxAcExpn, LambdaMax),
%   T0 is N + LambdaMax,
%   eval_timestamps(Tbinds),
%   MaxAc is MaxAcExpn.
%   
%  eval_timestamps(T=V) :- T is V.
%  eval_timestamps(B1 & B2) :- % choice of '&' arbitrary
%   eval_timestamps(B1), !,
%   eval_timestamps(B2).
% 
%  parse_f(true, T0, true, _T=T0, -1, 0) :- !.
% 
%  parse_f(lam(K):F, T0, StampF, Tf, MaxAc, LambdaMax) :- !,
%   parse_f(F, T0-K, StampF, Tf, MaxAc, LambdaF),
%   LambdaMax is LambdaF+K.
%     
%  parse_f(F & G, T0, StampF & StampG, BindsF & BindsG, max(MaxAcF,MaxAcG), LambdaMax) :- !,
%   parse_f(F, T0, StampF, BindsF,  MaxAcF, LambdaF),
%   parse_f(G, T0, StampG, BindsG, MaxAcG, LambdaG),
%   LambdaMax is max(LambdaF,LambdaG).
%   
%  parse_f(C, T0, T:C, T=T0, MaxAc, 0) :-  % C is an atom
%   (action_atom(C) -> MaxAc = T ; MaxAc = -1).
%
%%%%%
%
% the basic form is:
%  parse_stamp_fmla(F, N, StampF, Sig, HasSdfc, LambdaMax, MaxAc, DomEq, Errors)
%
%  - Sig is the signature of the parsed formula F.
%  - HasSdfc=1 means F contains sdfc constants, 
%  - MaxAc is maximum time stamp of any action atoms (-1 if none).
%  - DomEq is a list of any C1=C2 or C1\=C2 expressions encountered
%    possibly containing repetitions.
%  - Errors is the list of error(_) messages returned
%
% Some assumptions:
%  - domain(C, ...) icc_dom(C, ...) has been added for boolean constants C
%  - domain(C, ...) icc_dom(C, ...) has been added for ncplus constants C
%
% this is the general idea:
%
% parse_stamp_fmla(F, N, StampF, Sig, HasSdfc, LambdaMax, MaxAc, DomEq, Errors) :-
%  parse_stamp_fmla(F, T0, StampF, Sig, HasSdfc, Tbinds, LambdaMax, MaxAcX, DomEq, Errors), !,
%  T0 is N + LambdaMax,
%  eval_timestamps(Tbinds),
%  MaxAc is MaxAcX.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% parse_stamp_fmla/10
% the main procedure for the parser

parse_stamp_fmla(true, T0, true, any, 0, _T=T0, 0, -1, [], []) :-
 !.

parse_stamp_fmla(false, T0, false, any, 0, _T=T0, 0, -1, [], []) :-

 !.

% the next set of clauses  are to make parser independent of operator precedences
  
parse_stamp_fmla(-lam:C=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(lam(1):(C\=V), T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).
  
parse_stamp_fmla(-lam(K):C=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(lam(K):(C\=V), T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).
  
parse_stamp_fmla(-lam:C\=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(lam(1):(C=V), T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).
  
parse_stamp_fmla(-lam(K):C\=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(lam(K):C=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).

parse_stamp_fmla(-lam:F, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(-(lam(1):F), T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).
  
parse_stamp_fmla(-lam(K):F, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(-(lam(K):F), T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).
  
parse_stamp_fmla(-C=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(C\=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).

parse_stamp_fmla(-C\=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(C=V, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).
   
% end of the special cases  
   
parse_stamp_fmla(-(C), T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 aug_constant(C),
 !,
 (
  boolean_domain(C)
  -> icc_option(boolean_symbols,[_,FF]),
     parse_stamp_fmla(C=FF, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors)
  ;  StampF = -(C),
     Sig = any,
     Sdfc = 0,
     Tf = (_T=T0),
     LambdaMax = 0,
     MaxAc = -1,
     DomEq = [],
     Errors=[error("~q is not an atom", [C])]
 ).

parse_stamp_fmla(-(F), T0, StampNegF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 equivnot(F, NegF),
 !,
 parse_stamp_fmla(NegF, T0, StampNegF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).

parse_stamp_fmla(lam:F, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_fmla(lam(1):F, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).

parse_stamp_fmla(lam(K):F, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 !,
 (
  integer(K),
  K > 0
  -> parse_stamp_fmla(F, T0-K, StampF, Sig, Sdfc, Tf, LambdaF, MaxAc, DomEq, ErrorsF),
     LambdaMax is LambdaF + K,
     Errors = ErrorsF
  ;  parse_stamp_fmla(F, T0, StampF, Sig, Sdfc, Tf, LambdaF, MaxAc, DomEq, ErrorsF),
     LambdaMax = LambdaF,
     Errors = [error("~q is not a valid expression",[lam(K)])|ErrorsF]
 ).
  
% note the operator & in BindsF & BindsG below has no special meaning 

parse_stamp_fmla(F & G, T0, StampF & StampG, Sig, Sdfc, 
         BindsF & BindsG, LambdaMax, max(MaxAcF,MaxAcG), DomEq, Errors) :-
 !,
 parse_stamp_fmla(F, T0, StampF, SigF, SdfcF, BindsF, LambdaF, MaxAcF, DomEqF, ErrorsF),
 parse_stamp_fmla(G, T0, StampG, SigG, SdfcG, BindsG, LambdaG, MaxAcG, DomEqG, ErrorsG),
 signature_of_formula(SigF,SigG,Sig),
 Sdfc is max(SdfcF,SdfcG),              % logical or
 append(DomEqF,DomEqG,DomEq),
 append(ErrorsF,ErrorsG,Errors),
 LambdaMax is max(LambdaF,LambdaG).

% note the operator & in BindsF & BindsG below has no special meaning 

parse_stamp_fmla(F ++ G, T0, StampF ++ StampG, Sig, Sdfc, 
         BindsF & BindsG, LambdaMax, max(MaxAcF,MaxAcG), DomEq, Errors) :-
 !,
 parse_stamp_fmla(F, T0, StampF, SigF, SdfcF, BindsF, LambdaF, MaxAcF, DomEqF, ErrorsF),
 parse_stamp_fmla(G, T0, StampG, SigG, SdfcG, BindsG, LambdaG, MaxAcG, DomEqG, ErrorsG),
 signature_of_formula(SigF,SigG,Sig),
 Sdfc is max(SdfcF,SdfcG),   % logical or
 append(DomEqF,DomEqG,DomEq),
 append(ErrorsF,ErrorsG,Errors),
 LambdaMax is max(LambdaF,LambdaG).
  
% C=X could be an atom or an expression C1=C2 

parse_stamp_fmla(C=X, T0, (T:Atom)=1, Sig, Sdfc, T=T0, 0, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_eq_fmla(C, X, Atom, Sig, Sdfc, HasAc, DomEq, Errors),
 (
  HasAc=1
  -> MaxAc = T
  ;  MaxAc = -1
 ).

% C \= X could be negation of an atom or C1\=C2 

parse_stamp_fmla(C\=X, T0, (T:Atom)=0, Sig, Sdfc, T=T0, 0, MaxAc, DomEq, Errors) :-
 !,
 parse_stamp_eq_fmla(C, X, Atom, Sig, Sdfc, HasAc, DomEqX, Errors),
 (
  DomEqX = [C=X]
  -> DomEq = [C\=X]
  ;  DomEq = DomEqX
 ),
 (
  HasAc=1
  -> MaxAc = T
  ;  MaxAc = -1
 ).

% boolean atoms

parse_stamp_fmla(C, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors) :-
 aug_constant(C), 
 boolean_domain(C),  % domain(C,tt) might hold for non-boolean C
 icc_option(boolean_symbols,[TT,_]), 
 !,
 parse_stamp_fmla(C=TT, T0, StampF, Sig, Sdfc, Tf, LambdaMax, MaxAc, DomEq, Errors).

% catch all CHECK condition is correct

parse_stamp_fmla(F, T0, F, any, 0, _T=T0, 0, -1, [], Errors) :-
 (
  aug_constant(F)
  -> Errors = [error("~q is not an atom", [F])]
  ;  Errors = [error("~q is not recognised", [F])]
 ).
        
%%%%% eval_timestamps/1

eval_timestamps(T=V) :-
 T is V.

eval_timestamps(B1 & B2) :- % choice of '&' arbitrary
 eval_timestamps(B1),
 !,
 eval_timestamps(B2).
  
%%%%% parse_formula_sig/3

parse_formula_sig(F, Sig, Errors) :-
 parse_stamp_fmla(F, _N, _StampF, Sig, _HasSdfc, _Tf, _LambdaMax, _MaxAc, _DomEq, Errors).

parse_formula_sig(F, Sig, HasSdfc, LambdaMax, Errors) :-
  parse_stamp_fmla(F, _N, _StampF, Sig, HasSdfc, _Tf, LambdaMax, _MaxAc, _DomEq, Errors).
   
%%%%% signature_of_formula/3


signature_of_formula(Sig1,Sig2,Sig) :-
 (
  Sig1 = any
  -> Sig = Sig2 ;

  Sig2 = any
  -> Sig = Sig1 ;
  Sig1 = mixed
  -> Sig = mixed ;
  Sig2 = mixed
  -> Sig = mixed ;
  Sig1 = Sig2
  -> Sig = Sig1
  ;  Sig = mixed
 ).

%%%%% parse_stamp_eq_fmla/8
%
% for C=V, C\=V, C1=C2 or  C1\=C2
%
% parse_stamp_eq_fmla(C, X, Atom, Sig, HasSdfc, HasAc, DomEq, Errors)

parse_stamp_eq_fmla(C, V, Atom, Sig, HasSdfc, HasAc, [], []) :-
 domain(C,V), 
 icc_dom(C, Sig, Type, Dom, NDom, Nbits), 
 atom_integer(C, Sig, J, Nbits),
 !,
 (
  Type = sdfc
  -> HasSdfc = 1
  ;  HasSdfc = 0
 ),
 (
  Sig = trans
  -> HasAc = 1
  ;  HasAc = 0
 ),
 nth(Nth,Dom,V),
 Atom = mvc(J, Nth, Sig, Type, NDom, Nbits).
  
parse_stamp_eq_fmla(C1, C2, Atom, Sig, HasSdfc, HasAc, [C1=C2], []) :-
 icc_dom(C1, Sig1, Type1,_,_,_),
 icc_dom(C2, Sig2, Type2,_,_,_), 
 (
  (Type1 = sdfc ; Type2 = sdfc)
  -> HasSdfc = 1
  ;  HasSdfc = 0
 ),
 (
  (Sig1 = trans ; Sig2 = trans)
  -> HasAc = 1
  ;  HasAc = 0
 ),
 signature_of_formula(Sig1,Sig2,Sig),
 !,
 Atom = eq_dom(C1,C2).

% the case where status=green/red, trans=green/red have not been
% recognised yet. This won't happen very often. 

parse_stamp_eq_fmla(C, V, Atom, Sig, HasSdfc, HasAc, DomEq, Errors) :-
 \+ iccvar(is_ncplus, _), % we don't know iccvar 0 was recognised at
                          % process_signature in loadf
 icc_option(ncplus_symbols, [Status,Trans,Green,Red]),
 (C = Status ; C = Trans), 
 (V = Green ; V = Red), 
 set_iccvar(is_ncplus,1),
 assert_ncplus_domains,
 !,
 parse_stamp_eq_fmla(C, V, Atom, Sig, HasSdfc, HasAc, DomEq, Errors).

% the case C=X where C is recognised, X is not (assume wrong value X)

parse_stamp_eq_fmla(C, X, bad_atom(C,X), Sig, HasSdfc, HasAc, [], Errors) :-
 aug_constant(C, Sig, Type),
 !,
 (
  Type = sdfc
  -> HasSdfc = 1
  ;  HasSdfc = 0
 ),
 (
  Sig = trans
  -> HasAc = 1
  ;  HasAc = 0
 ),
 Errors = [error("~q is not an atom", [C=X])].

% the case X=C where C is recognised; assume wrong constant X

parse_stamp_eq_fmla(X, C, bad_eq_dom(X,C), Sig, HasSdfc, HasAc, [X=C], Errors) :-
 aug_constant(C, Sig, Type),
 !,
 (
  Type = sdfc
  -> HasSdfc = 1
  ;  HasSdfc = 0
 ), % doesn't matter, but might as well
 (
  Sig = trans
  -> HasAc = 1
  ;  HasAc = 0
 ),
 Errors = [error("Bad expression ~q: ~q is not a constant", [X=C,X])].

% catchall

parse_stamp_eq_fmla(C, X, bad(C,X), any, 0, 0, [C=X], Errors) :-
 Errors = [error("Bad expression ~q: ~q and ~q are not constants", [C=X,C,X])].

%%%%% equivnot/2

equivnot(true, false).
equivnot(false, true).
equivnot((A & B), (-A ++ -B)).
equivnot((A ++ B), (-A & -B)).
equivnot((C=X), C \= X).
equivnot((C \= X), C = X).
equivnot(lam(K):F, lam(K):(-F)).
equivnot(lam:F, lam(1):(-F)).
equivnot(-(A), A).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%
% SECTION 15: rules to clause store
%
% PREDICATES DEFINED:
%  - rule_to_clause_store/4
%  - rule_error_msg/5
%  - store_rule_schemas/3
%  - store_aux_schemas/2
%  - make_store_ncplus_rules/0
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% rule_to_clause_store/4
%
% Checks on rule forms (non-definite, trivial) are done on the mvc
% representation. We would have more precision checking the boolean transforms
% but the point here is to detect non-definite rules and do some basic checks
% on the form that can be reported. Rules which turn out to be trivial after
% conversion to boolean will  not be added to the completion. There is no need
% to report all such details to the user. Law is passed in case there are
% error/warning messages

rule_to_clause_store(Head, Body, T, Law) :-
  nnf_to_cnf(Head, HCNF, 0, AuxH, T),           % we don't want aux vars here
  nnf_to_dnf(Body, BDNF, 0, AuxB, T),           % or here
  !,
  (
   HCNF = []
   -> rule_error_msg(Head, Body, Law, 
         "** Trivial instances of the rule (head true) will be ignored",[]),
      incr_iccvar(parse_warnings,_)
   ;
   \+ (member(B, BDNF), \+ has_complementary_lits(B))
   -> rule_error_msg(Head, Body, Law, "** Trivial rule (body false) ignored",[]), 
      incr_iccvar(parse_warnings,_)
   ;
   % The head HCNF should be a list (conjunction) of atoms.
   % If it is not, the rule is not definite (but it might be trivial).
   % If any of the atoms are C\=V for C other than 2 valued, not definite.
   member(H, HCNF),
   not_definite(H)
   -> format("~nCausal law: ~q~n", [Law]), 
      format("ERROR: The causal law is not definite~n",[]), 
      incr_iccvar(parse_errors,_)
   ;  
   % No need for error messages past this point
      store_rule_schemas(HCNF, BDNF, T), 
      store_aux_schemas(AuxH, T),       % won't be any but leave it
      store_aux_schemas(AuxB, T)        % won't be any but leave it
 ).

%%%%% rule_error_msg/5

rule_error_msg(_Head, _Body, Law, _Msg, _MsgArgs) :-
 format("~nCausal law: ~q~n", [Law]),
 fail.

rule_error_msg(Head, Body, _Law, _Msg, _MsgArgs) :-
 Head = ((_:Atom) = _),
 functor(Atom, mvc, _),
 current_output(Fd),
 pretty_print_literal(Head, Fd),
 format(Fd, ' <= ', []),
 pretty_print_rule_body(Body, Fd),      % might fail (OK)
 nl,
 fail.

rule_error_msg(_Head, _Body, _Law, Msg, MsgArgs) :-
 format(Msg,MsgArgs),
 nl.
  
%%%%% not_definite/1

not_definite([Atom1,Atom2|Rest]) :- 
 \+ has_complementary_lits([Atom1,Atom2|Rest]).

not_definite([(_:mvc(_, _, _, _, NDom, _))=0]) :-
 NDom \= 2.

%%%%% store_rule_schemas/3

store_rule_schemas(HCNF, BDNF, T) :-
 member(H, HCNF),
 (
  H = [_,_|_]  % we know H must have complementary literals; non-def checked
  ->  fail
  ;   true
 ),
 (
  H = []
  -> D = false
  ;  H = [D]
 ),
 member(B, BDNF),
 (
  has_complementary_lits(B) 
  -> true  % or fail (it makes no difference)
  ;  incr_iccvar(total_rule_count, RN),
     assert(rule_body(RN, B)),
     assert(shiftable_rule(D, T, RN)),
     iccvar(max_tval, Current),
     (
      Current < T
      -> set_iccvar(max_tval, T)
      ;  true
     )
 ),
 fail.

store_rule_schemas(_,_,_).

%%%%% store_aux_schemas/2

store_aux_schemas(Aux, T) :-
 member(C, Aux),
 negate_lits(C, NC),
 store_rule_schemas([[]], [NC], T),
 fail.

store_aux_schemas(_, _).

%%%%% make_store_ncplus_rules/0

make_store_ncplus_rules :-
 iccvar(is_ncplus,1),
 !,
 icc_option(ncplus_symbols, [Status, Trans, Green, Red]),
 parse_stamp_law((default Status=Green),HeadDefStat,BodyDefStat,_,_),
 parse_stamp_law((default Trans=Green),HeadDefTrans,BodyDefTrans,_,_),

 rule_to_clause_store(HeadDefStat, BodyDefStat, 0, ncplus),
 rule_to_clause_store(HeadDefTrans, BodyDefTrans, 1, ncplus),
   
 % ggg constraint: we have to avoid error messages, so ...
 parse_stamp_law((caused Trans=Red if Status=Red & Status=Green),Headggg,BodygggX,_,_),
 !,
 % and now adjust the time stamp
 BodygggX = ((0:StatusRed)=Val & StatusGreen),
 Bodyggg = ((1:StatusRed)=Val & StatusGreen),
 rule_to_clause_store(Headggg, Bodyggg, 1, ggg),
 !,
 % now for agent-stranded...
 (
  iccvar(is_ag_stranded, 1),
  nCplus_rule((caused red(_) if _))
  -> (
      agent(Ag),
      parse_stamp_law((default -red(Ag)), HeadAgDef, BodyAgDef, _, _),
      rule_to_clause_store(HeadAgDef, BodyAgDef, 1, ncplus),
      (
       local_global
        -> parse_stamp_law((caused Trans=Red if red(Ag)), HeadLG, BodyLG, _, _),
           rule_to_clause_store(HeadLG, BodyLG, 1, ncplus)
        ;  true
      ),
      fail
      ;
      true
     )
  ;  true
 ).

make_store_ncplus_rules.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 16: mvc to boolean
%
% PREDICATES DEFINED:
%  - mvc_to_boolean/2
%  - mvc_atom_to_boolean/2
%  - mvc_atom_to_atom_list/2
%  - nth_to_bool_formula/9
%  - nth_to_atom_list/9
%  - mvc_constraint_clause/2
%  - generate_integer/3
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
%%%%% mvc_to_boolean/2
%
% This converts a formula of mvc atoms to a formula of boolean atoms.
% Each (+ve) mvc atom is replaced by a conjunction of boolean atoms.
% All internal occurrences of true/false are also removed

mvc_to_boolean(true, true) :-
 !.

mvc_to_boolean(false, false) :-
 !.

mvc_to_boolean((A & B), F) :-
 !,
 mvc_to_boolean(A, Ax),
 (
  Ax = false
  -> F = false ;
  Ax = true
  -> mvc_to_boolean(B, F)
  ;  mvc_to_boolean(B, Bx),
     (
      Bx = false
      -> F = false ;
      Bx = true
      -> F = Ax
      ;  F = (Ax & Bx)
     )
 ).

mvc_to_boolean((A ++ B), F) :-
 !,
 mvc_to_boolean(A, Ax),
 (
  Ax = true
  -> F = true ;
  Ax = false
  -> mvc_to_boolean(B, F)
  ;  mvc_to_boolean(B, Bx),
     (
      Bx = false
      -> F = Ax ;
      Bx = true
      -> F = true
      ;  F = (Ax ++ Bx)
     )
 ). 

mvc_to_boolean(F,Fx) :-
 mvc_atom_to_boolean(F, Fx).

%%%%% mvc_atom_to_boolean/2
%
% We need to convert to boolean conjunction here, 
% and process special atoms eq_dom(C1,C2), in due course (todo)

mvc_atom_to_boolean((T:eq_dom(C1,C2))=Val, (T:eq_dom(C1,C2))=Val) :-
 !.

mvc_atom_to_boolean((T:mvc(J, Nth, Sig, _Type, NDom, Nbits))=Val, Formula) :- 
 nth_to_bool_formula(Nbits, Nth, NDom, 1, Nbits, constant(J,Sig), Val, T, Formula).

%%%%% mvc_atom_to_atom_list/2

mvc_atom_to_atom_list((T:mvc(J, Nth, Sig, _Type, NDom, Nbits))=Val, AtomList) :- 
 nth_to_atom_list(Nbits, Nth, NDom, 1, Nbits, constant(J,Sig), Val, T, AtomList).

%%%%% nth_to_bool_formula/9
%
% conversion of Nth arg of a mvc constant to boolean
  
nth_to_bool_formula(Nbits, Nth, NDom, Index, MaxBits, constant(Var,Sig), Val, T, Formula) :-
 Bit is Nth rem 2,
 (
  Val = 1
  -> BitVal = Bit
  ;  BitVal is 1-Bit
 ),
 Term = ((T:bool(Var,Index)) = BitVal), 
 (
  Nbits = 1 
  -> Formula = Term
  ;  (
      Val = 1
      -> Formula = (Term & Rest)
      ;  Formula = (Term ++ Rest)
     ),
     Next is Index + 1,
     NNbits is Nbits - 1,
     NNth is Nth >> 1,
     nth_to_bool_formula(NNbits,NNth, NDom, Next, MaxBits, constant(Var,Sig), Val, T, Rest)
 ).

%%%%% nth_to_atom_list/9
%
% This is the same thing but for converting mvc atoms to
% lists of boolean atoms. It just avoids calling nnf_to_cnf.

nth_to_atom_list(Nbits, Nth, NDom, Index, MaxBits, constant(Var,Sig), Val, T, AtomList) :-
 Bit is Nth rem 2,
 (
  Val = 1
  -> BitVal = Bit
  ;  BitVal is 1-Bit
 ),
 Term = ((T:bool(Var,Index)) = BitVal),
 (

  Nbits = 1 
  -> AtomList = [Term]
  ;  AtomList = [Term|Rest],
     Next is Index + 1,
     NNbits is Nbits - 1,
     NNth is Nth >> 1,
     nth_to_atom_list(NNbits,NNth, NDom, Next, MaxBits, constant(Var,Sig), Val, T, Rest)
 ).

%%%%% mvc_constraint_clause/2
%
% clauses for mvc constraints; clause is list of negated boolean atoms so we
% want to call nth_to_atom_list with Val=0; works whether T is bound or not

mvc_constraint_clause(T, Clause) :-
 icc_dom(C, Sig, _, _, NDom, Nbits),
 atom_integer(C, Sig, J, Nbits),
 (Sig = state -> T = 0 ; T = 1),
 MaxNth is 2 << (Nbits - 1),            % MaxNth = 2^Nbits
 MaxNth > NDom,
 FirstNoVal is NDom + 1,
 generate_integer(FirstNoVal, MaxNth, Nth),
 nth_to_atom_list(Nbits, Nth, NDom, 1, Nbits, constant(J,Sig), 0, 0, Clause).

%%%%% generate_integer/3

generate_integer(Min,Max,_J) :-
 Min > Max,
 !,
 fail.

generate_integer(Min,_Max,Min).

generate_integer(Min,Max,J) :-
 NewMin is Min + 1,
 generate_integer(NewMin,Max,J).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 17: make and store completion clauses
%
% PREDICATES DEFINED:
%  - make_completion_clauses/0
%  - make_completion_clauses_if/0
%  - negate_mvc_lits_to_boolean/2
%  - make_mvc_constraints/0
%  - make_completion_clauses_only_if/0  
%  - aug_atom_mvc/3
%  - mvc_lits_to_boolean/2
%  - rule_applicable_at/3
%  - shift_atoms/3
%  - shift_cnf/3
%  - completion_clause/2
%  - completion_clause/3
%
% CHECK: don't understand this section very well, RAC
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

make_completion_clauses :-
 make_completion_clauses_if,            % shiftable rules
 iccvar(max_tval, MaxTval),
 make_completion_clauses_only_if(0, MaxTval),
 make_mvc_constraints.

%%%%% make_completion_clauses_if/0  
%
% A shiftable rule has the form
%     Head <= BodyList
% where Head is either a +ve mvc atom or false, and
% BodyList is a list (possibly empty) of mvc atoms,
% representing their conjunction.
% We might have eq_dom(C1,C2) atoms in here.
% And possibly aux variables.
% 
% To convert that into clausal form
%     Head => list of boolean atoms representing a conjunction
% To get the body, we
%     negate every atom in BodyList, then
%     convert every element to its boolean equivalent formula;
%     we convert the disjunction of that list of formulas to cnf;
%     for every element in the boolean head, and every element
%     (conjunct) in the cnf of the negated body, we form a clause, 
%     throwing out any tautologies.
%
% We might as well negate body and convert mvc to boolean in one pass.

make_completion_clauses_if :-
 shiftable_rule(HeadMVC, T, RN),
 rule_body(RN, Body),
 negate_mvc_lits_to_boolean(Body, NegBodyBool),
 nnf_to_cnf(NegBodyBool, BodyCNF, 0, _Aux, T),          % no aux !!
 member(BodyAtoms, BodyCNF),
 (
  HeadMVC = false
  -> % there are no tautologies in a rule body
     Clause = BodyAtoms
  ;  mvc_atom_to_atom_list(HeadMVC, HeadAtomList),
     member(Head, HeadAtomList),
      % We insert the Head into the BodyAtoms ord set and
      % then check if the result is a tautology -- it is
      % if it contains complementary literals.
      % Or equivalently:
      % see if negation of Head is already in BodyAtoms; if so we will 
      % have a tautology.
      % Easiest to do it the first way. That also deals with duplications
      % of atoms, if any.
     ord_add_element(BodyAtoms, Head, Clause),
     (
      icc_option(remove_tautologies,1)  
      -> \+ has_complementary_lits(Clause)
      ;  true
     )
 ),
 assert(completion_if_clause(T, Clause)),
 fail.

make_completion_clauses_if.

%%%%% negate_mvc_lits_to_boolean/2

negate_mvc_lits_to_boolean([],false).

negate_mvc_lits_to_boolean([Atom=Val|Ns],(F ++ Cs)) :-
 OppVal is 1 - Val,
 (
  mvc_atom_to_boolean(Atom=OppVal, BoolF)
  -> F = BoolF
  ;  F = (Atom=OppVal)  % in case of Atom is not mvc (eg. aux)
 ), 
 !,
 negate_mvc_lits_to_boolean(Ns,Cs).

%%%%% make_mvc_constraints/0

make_mvc_constraints :-
 mvc_constraint_clause(T, Clause),
 assert(completion_if_clause(T, Clause)),
 fail.

make_mvc_constraints.

%%%%% make_completion_clauses_only_if/2

make_completion_clauses_only_if(T, MaxTval) :- 
 T > MaxTval,
 !.

make_completion_clauses_only_if(T, MaxTval) :-
 Tnext is T + 1,
 make_completion_clauses_only_if(T),
 !,
 make_completion_clauses_only_if(Tnext, MaxTval).
   
% this generates and stores what I call Sigma_T in my notes
   
make_completion_clauses_only_if(T) :-
 aug_atom_mvc(Atom, Sig, Type),
 (
  T = 0,
  Type = fc
  -> fail
  ;  true
 ), % exogeneity simple fc at 0
 (
  Sig = state
  -> J = T
  ;  T > 0,
     J is T - 1
 ),
 HeadMVC = ((J:Atom)=1),   % ASSUME Val is ALWAYS 1 HERE
 findall(BodyAtoms,
         (rule_applicable_at(T, HeadMVC, Body), 
          mvc_lits_to_boolean(Body,BodyAtoms)),
         Bodies),
 NegHeadMVC = ((J:Atom)=0),  % OppVal here
 (
  disjunction_of_list_to_cnf(Bodies, BodiesCnf, 1, Aux, T)
  -> true
 ),
 mvc_atom_to_atom_list(NegHeadMVC, NegHeadAtoms),
 (
  member(RB, BodiesCnf),
  ord_union(NegHeadAtoms, RB, Clause),
  (
   icc_option(remove_tautologies, 1),
   has_complementary_lits(Clause)
   -> true
   ;  assert(completion_onlyif_clause(T, Clause))
  )
  ;
  member(AuxClause, Aux),
  (
   icc_option(remove_tautologies, 1),
   has_complementary_lits(AuxClause)
   -> true
   ;  assert(completion_onlyif_clause(T, AuxClause))
  )
 ),
 fail.   

make_completion_clauses_only_if(_T).

%%%%% aug_atom_mvc/3

aug_atom_mvc(Atom, Sig, Type) :-
 icc_dom(C, Sig, Type, _Dom, NDom, Nbits),
 atom_integer(C, Sig, J, Nbits),
 generate_integer(1, NDom, Nth),
 Atom = mvc(J, Nth, Sig, Type, NDom, Nbits).  

%%%%% aug_atom_mvc/3

aug_atom_mvc(Atom, Sig, Type) :-
 aug_atom_mvc(Atom, Sig, Type, _, _).

aug_atom_mvc(Atom, Sig, Type, NDom, Nbits) :-
 icc_dom(C, Sig, Type, _Dom, NDom, Nbits),
 atom_integer(C, Sig, J, Nbits),
 generate_integer(1, NDom, Nth),
 Atom = mvc(J, Nth, Sig, Type, NDom, Nbits).  

%%%%% mvc_lits_to_boolean/2

mvc_lits_to_boolean([],[]).

mvc_lits_to_boolean([Atom|Ns],[F|Cs]) :-
 (
  mvc_atom_to_boolean(Atom, BoolF)
  -> F = BoolF
  ;  F = Atom           % in case of aux vars
 ),
 !,
 mvc_lits_to_boolean(Ns,Cs).

%%%%% rule_applicable_at/3

rule_applicable_at(T, Head, Body) :-
 shiftable_rule(Head, T, RN),
 rule_body(RN, Body).
  
rule_applicable_at(T, false, Body) :-
 shiftable_rule(false, TX, RN),
 TX < T,
 Tshift is T - TX,
 rule_body(RN, BodyX),
 shift_atoms(BodyX, Tshift, Body).
  
rule_applicable_at(T, (N:Atom)=Val, Body) :-
 shiftable_rule((M:Atom)=Val, TX, RN),
 TX < T,
 Tshift is T - TX,
 N is M + Tshift,
 rule_body(RN, BodyX),
 shift_atoms(BodyX, Tshift, Body).

%%%%% shift_atoms/3
  
shift_atoms([], _, []) :-
 !.

shift_atoms([Atom|Rest], Tshift, [AtomX|RestX]) :-
 (
  Atom = ((N:Core)=Val)
  -> NN is N + Tshift,
     AtomX = ((NN:Core)=Val)
  ;  AtomX = Atom
 ),
 !,
 shift_atoms(Rest, Tshift, RestX).

%%%%% shift_cnf/3

shift_cnf([], _, []) :-
 !.

shift_cnf([C|Rest], Shift, [Cx|RestX]) :-
 shift_atoms(C, Shift, Cx), !,
 shift_cnf(Rest, Shift, RestX).
   
%%%%% completion_clause/2
%
% completion_clause(T, Clause)
% = Clause is a clause in comp(Gamma_T).
% (NOT Clause is a clause in completion 'step' T)

completion_clause(T, Clause) :-
 iccvar(max_tval, MaxTval),
 !,
 completion_clause(T, MaxTval, Clause).

%%%%% completion_clause/3
%
% completion clauses from stored 'if' part

completion_clause(T, _MaxTval, Clause) :-
 generate_integer(0, T, N),
 generate_integer(0, N, J),
 Tshift is N - J,
 completion_if_clause(J, ClauseJ),
 shift_atoms(ClauseJ, Tshift, Clause).

% completion clauses from stored 'only if' part

completion_clause(T, MaxTval, Clause) :-
 Tm is min(T, MaxTval),
 generate_integer(0, Tm, J),
 completion_onlyif_clause(J, Clause).

completion_clause(T, MaxTval, Clause) :-
 T > MaxTval,
 MaxTshift is T - MaxTval,
 generate_integer(1, MaxTshift, Tshift),
 completion_onlyif_clause(MaxTval, ClauseM),
 shift_atoms(ClauseM, Tshift, Clause).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 18: cnf and dnf, base and simple cases
%             (CCalc's optimized versions are in the next section)
%
% PREDICATES DEFINED:
%  - nnf_to_cnf/5
%  - disjunction_of_list_to_cnf/5
%  - nnf_to_dnf/5
%  - nnf_to_cnf_simple/2
%  - nnf_to_dnf_simple/2
%
% nnf_to_cnf/5 and disjunction_of_list_to_cnf/5 do essentially the same thing.
% The difference is that when nnf_to_cnf is called, the input is always a wff
% (not a list). When disjunction_of_list_to_cnf is called, the input is a list
% of lists, to be read as the disjunction of the list members, and each list
% member is a list of literals, to be read as their conjunction.
% 
% nnf_to_cnf is called when converting rule to clause,
% and by the query parser.
% 
% disjunction_of_list_to_cnf is  called by 
% generate_completion_step/1. 
%
% AuxFlag is 1 if we want to use ccalc's clause gen optimiser
% (assuming the option is set) otherwise 0.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% nnf_to_cnf/5

nnf_to_cnf(false, [[]], _AuxFlag, [], _) :-
 !.

nnf_to_cnf(true, [], _AuxFlag, [], _) :-
 !.

nnf_to_cnf(Wff, CNF, AuxFlag, Aux, T) :-
 icc_option(ccalc_optimize_clause_gen, Opt),
 % we want the optimisation on if Opt is 1 and AuxFlag is 1
 % otherwise not
 (
  AuxFlag=1,
  Opt=1 
  -> set_iccvar(ccalc_aux_opt, 1),      % need this for the time being
     nnf_to_cnf_ccalc(Wff, CNF, Aux, _, _, _, _, T)
  ;  Aux = [],
     nnf_to_cnf_simple(Wff, CNF)
 ).   

%%%%% disjunction_of_list_to_cnf/5

disjunction_of_list_to_cnf(List, CNF, AuxFlag, Aux, T) :-
  icc_option(ccalc_optimize_clause_gen, Opt),
  (AuxFlag=1, Opt=1 
   -> set_iccvar(ccalc_aux_opt, 1),  % need this for the time being
      nnf_to_cnf_ccalc(List, CNF, Aux, _, _, _, _, T)
   ;  Aux = [],
      nnf_to_cnf_simple(List, CNF)
  ).
  
%%%%% nnf_to_dnf/5
%
% only called in one place: rule_to_clause_store/3, to convert rule_body to
% disjunction. Input is always a wff (rather than a list).
%
% Just as for nnf_to_cnf we need the time stamp parameter T for 
% time stamping any new auxiliary atoms. T=-1 will be ignored.
%
% AuxFlag is 1 if we want to use ccalc's clause gen optimiser 
% (assuming the option is set) otherwise 0.

nnf_to_dnf(false, [], _AuxFlag, [], _T) :-
 !.

nnf_to_dnf(true, [[]], _AuxFlag, [], _T) :-
 !.

nnf_to_dnf(Formula, DNF, AuxFlag, Aux, T) :-
 icc_option(ccalc_optimize_clause_gen, Opt),
 % we want the optimisation on if Opt is 1 and AuxFlag is 1
 % otherwise not
 (
  AuxFlag=1,
  Opt=1 
  -> set_iccvar(ccalc_aux_opt, 1),      % need this for the time being
     nnf_to_dnf_ccalc(Formula, DNF, Aux, _, _, _, _, T)
  ;  Aux = [],
     nnf_to_dnf_simple(Formula, DNF)
 ).   

%%%%% nnf_to_cnf_simple/2
%
% non-optimized version, without aux vars. We don't need the time stamp here.

% It is only used to produce time-stamped auxiliary vars, and we are not
% introducing any such here.

% for lists

nnf_to_cnf_simple([[]],[]) :-
 !.
nnf_to_cnf_simple([],[[]]) :-
 !.

nnf_to_cnf_simple([[A]],Cnf) :-
 !,
 nnf_to_cnf_simple(A,Cnf).

nnf_to_cnf_simple([[A|B]],Cnf) :-
 !,
 nnf_to_cnf_simple(([[A]]&[B]),Cnf).

nnf_to_cnf_simple([A|B],Cnf) :-
 !,
 nnf_to_cnf_simple(([A]++B),Cnf).

% for formulas

nnf_to_cnf_simple(true, []) :-
 !.

nnf_to_cnf_simple(false, [[]]) :-
 !.

nnf_to_cnf_simple((A ++ B), Cnf) :-
 !,
 nnf_to_cnf_simple(A, CnfA),
 (
  CnfA = []                             % true
  -> nnf_to_cnf_simple(true, Cnf)
  ;
  CnfA = [[]]                           % false
  -> nnf_to_cnf_simple(B, Cnf)
  ;  nnf_to_cnf_simple(B, CnfB),        % otherwise
     (
      CnfB = []                         % true
      -> nnf_to_cnf_simple(true, Cnf)
      ;
      CnfB = [[]]                        % false
      -> Cnf = CnfA
      ;  pairwise_combinations(CnfA, CnfB, Cnf) % otherwise
     )
 ).

nnf_to_cnf_simple((A & B), Cnf) :-
 !,
 nnf_to_cnf_simple(A, CnfA),
 (
  CnfA = [[]]           % false
  -> nnf_to_cnf_simple(false, Cnf)
  ;
  CnfA = []             % true
  -> nnf_to_cnf_simple(B, Cnf)
  ;  nnf_to_cnf_simple(B, CnfB),% otherwise
     (
      CnfB = [[]]       % false
      -> nnf_to_cnf_simple(false, Cnf)
      ;
      CnfB = []         % true
      -> Cnf = CnfA
      ;                 % otherwise
        % transform (A && B) -- this is easy since A and B are already
        % in CNF after recursion
        append(CnfA, CnfB, Cnf)
     )
 ).

% atoms

nnf_to_cnf_simple(Atom, [[Atom]]).

%%%%% nnf_to_dnf_simple/2

nnf_to_dnf_simple(true, [[]]) :-
 !.
nnf_to_dnf_simple(false, []) :-
 !.

nnf_to_dnf_simple((A & B), Dnf) :-
 !,
 nnf_to_dnf_simple(A, DnfA),
 (
  DnfA = []     % false
  -> nnf_to_dnf_simple(false, Dnf)
  ;
  DnfA = [[]]   % true
  -> nnf_to_dnf_simple(B, Dnf)
  ;             % otherwise
     nnf_to_dnf_simple(B, DnfB),
     (
      DnfB = [] % false
      -> nnf_to_dnf_simple(false, Dnf)
      ;
      DnfB = [[]]  % true
      -> Dnf = DnfA
      ;         % otherwise
         pairwise_combinations(DnfA, DnfB, Dnf)
     )
  ).

nnf_to_dnf_simple((A ++ B), Dnf) :-
 !,
 nnf_to_dnf_simple(A, DnfA),
 (
  DnfA = [[]]           % true
  -> nnf_to_dnf_simple(true, Dnf)
  ;
  DnfA = []             % false
  -> nnf_to_dnf_simple(B, Dnf)
  ;                     % otherwise
     nnf_to_dnf_simple(B, DnfB),
     (
      DnfB = [[]]       % true
      -> nnf_to_dnf_simple(true, Dnf)
      ;
      DnfB = []         % false
      -> Dnf = DnfA
      ;                 % otherwise
         append(DnfA, DnfB, Dnf)
    )
 ).

nnf_to_dnf_simple(Atom, [[Atom]]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 19: cnf and dnf, modified CCalc optimized version
%
% PREDICATES DEFINED:
%  - nnf_to_cnf_ccalc/8
%  - nnf_to_dnf_ccalc/8
%
% We need the time stamp here to get new auxiliary atoms time-stamped
% correctly. If set to -1 it is ignored.

% This is (a modified form of) CCalc's distribute_or_over_and.
% It converts formula F to CNF, representing
% it in list notation using the integers assigned to the atoms (by the
% atom_integer predicate).  In this list notation, every formula is a list of
% lists of integers, where each sublist represents a disjuction of literals
% and the whole list represents a conjunction of these disjunctions. 'true' is
% represented by [] (since empty conjuction is vacuously true), and 'false'
% is represented by [[]] (since the empty disjunction is false).
%
% If the option 'optimize' is set to true, auxiliary atoms will be
% introduced to shorten the result; Aux will then contain the additional
% clauses which define the auxiliary atoms in terms of other atoms.  If 
% 'optimize' is false, no auxiliary atoms will be introduced and Aux will be
% the empty list.
%
% The three-argument procedure is a wrapper for the version with 8 parameters.
% In this version, Pos is the conversion of the formula to CNF; PosAux is the
% set of clauses defining auxiliary atoms used in Pos; PosN is the number of
% clauses in Pos; Neg is the conversion of the formula's negation to CNF;
% NegVar is a list of uninstantiated variables that appear in NegAux; and
% NegAux and NegN are analagous to PosAux and PosN.  The negation of each
% subformula is computed simultanously with the subformula itself, and is
% used when (and only when) an auxiliary atom is defined using that subformula
% (since if aux. atom K is equivalent to formula F, clauses for -K ++ F and
% K ++ -F are added).  It's easier to convert F and -F simultaneously than
% do it with separate calls to distribute_or_over_and since we *always* want
% both versions so that we can compare the number of clauses generated when
% we replace F with an auxiliary atom and when we don't, to decide which is
% smaller.
%
% WE DON'T DO THIS. NOT NECESSARY. 
%
% The uninstantiated variables in NegAux are auxiliary atoms which appear
% in Neg, the optimization of -F.  Neg will only be used if F is replaced with
% an auxiliary variable, and we don't want to add "real" auxiliary atoms for
% that formula unles it's used, since otherwise we will have "orphaned"
% auxiliary atoms which aren't contained in any clauses and can therefore
% have arbitrary values.  Thus, we leave these atoms uninstantiated until
% Neg is actually used, at which point the procedure bind_all_vars/1 is used
% to add the new atoms.  NegVar is a list of pairs [K,NegK], where K is a
% new atom to be introduced and NegK is its negation.  (We can't just use
% -K in the formula when K is uninstantiated; it won't be evaluated, so if
% for example K is assigned the new atom integer 1000, -K will be -(1000)
% instead of -1000.  This causes problems, so instead we treat K and NegK as
% separate variables and let bind_all_vars/1 establish the relationship
% between them.)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% nnf_to_cnf_ccalc/8

% The bits for handling lists.




nnf_to_cnf_ccalc([[]],[],[],0,[[]],[],1, _T) :-
 !.

nnf_to_cnf_ccalc([],[[]],[],1,[],[],0, _T) :-
 !.

nnf_to_cnf_ccalc([[A]],Pos,PosAux,NPos,Neg,NegAux,NNeg, T) :-
 !,
 nnf_to_cnf_ccalc(A,Pos,PosAux,NPos,Neg,NegAux,NNeg, T).

nnf_to_cnf_ccalc([[A|B]],Pos,PosAux,NPos,Neg,NegAux,NNeg, T) :-
 !,
 nnf_to_cnf_ccalc(([[A]]&[B]),Pos,PosAux,NPos,Neg,NegAux,NNeg, T).

nnf_to_cnf_ccalc([A|B],Pos,PosAux,NPos,Neg,NegAux,NNeg, T) :-
 !,
 nnf_to_cnf_ccalc(([A]++B),Pos,PosAux,NPos,Neg,NegAux,NNeg, T).  

% formulas

nnf_to_cnf_ccalc(true, [], [], 0, [[]], [], 1, _T) :-
 !.

nnf_to_cnf_ccalc(false, [[]], [], 1, [], [], 0, _T) :-
 !.

nnf_to_cnf_ccalc((A ++ B), Pos, PosAux, NPos, Neg, NegAux, NNeg, T) :-
 !,
 nnf_to_cnf_ccalc(A, PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA, T),
 (
  PosA = []             % true
  -> nnf_to_cnf_ccalc(true, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;
  PosA = [[]]           % false
  -> nnf_to_cnf_ccalc(B, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;                     % otherwise
     nnf_to_cnf_ccalc(B, PosB, PosAuxB, NPosB, NegB, NegAuxB, NNegB, T),
     (
      PosB = []         % true
      -> nnf_to_cnf_ccalc(true, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
      ;
      PosB = [[]]       % false
      -> [Pos, PosAux, NPos, Neg, NegAux, NNeg] 
         = [PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA]
      ;                 % otherwise

   % main case  
   % calculate the number of clauses generated if neither A nor B, only A,
   % or only B (respectively) is replaced with an auxiliary atom.  (It's
   % never valuable to replace both, because the number of clauses saved by
   % avoiding distribution is always outweighed by the number of clauses
   % generated by auxiliary clauses.)
    
         N00 is NPosA * NPosB,
         N10 is NPosB + NPosA + NNegA,
         N01 is NPosA + NPosB + NNegB,
         (
          (iccvar(ccalc_aux_opt, 0) ; N00 =< N10, N00 =< N01)
          ->
    
    % It's not worth introducing auxiliary atoms. So just perform the
    % distribution, by disjoining each disjunct from A with each disjunct
    % of B in turn and then conjoining all of these resulting disjunctions

             pairwise_combinations(PosA, NPosA, PosB, NPosB, Pos),
             NPos = N00,
      
    % No new auxiliary clauses were added, so simply append the clauses
    % generated for A and for B
             append(PosAuxA, PosAuxB, PosAux)
      
          ;
          N10 =< N01
          ->
    % replace A with an auxiliary atom.  Thus the formula itself will
    % become K ++ B, which will then be distributed, and we'll also add
    % clauses to define K <-> A.  The latter is of course -K ++ A and
    % K ++ -A, so this is where we use the optimized negation of A we
    % calculated in the recursive call. 
    
             new_aux_atom(K,NegK,T),

    % distribute K ++ B, by simply adding K to each conjunct of B
             insert_in_each(PosB,K,Pos),

    % distribute K ++ B, by simply adding K to each conjunct of B
    % similarly generate clauses for K ++ -A      
             insert_in_each(PosA,NegK,PosAux1),
             insert_in_each(NegA,K,PosAux2),
      
    % collect the newly defined auxiliary clauses with those defined
    % for all the subformulae used, and return      
             append_together([PosAuxA, PosAuxB,PosAux1, PosAux2, NegAuxA], 
                             PosAux),
             NPos = NPosB
          ;
    
    % replace B with an auxiliary atom -- analogous to the previous case
             new_aux_atom(K,NegK,T),
             insert_in_each(PosA,K,Pos),
             insert_in_each(PosB,NegK,PosAux1),
             insert_in_each(NegB,K,PosAux2),
             append_together([PosAuxA, PosAuxB,PosAux1, PosAux2, NegAuxB], 
                             PosAux),
             NPos = NPosA
         ),
  
   % optimize formula's negation (-A && -B).  This is easy since -A and -B
   % are both in CNF after recursion-- no distribution is necessary.
         append(NegA, NegB, Neg),
         append(NegAuxA, NegAuxB, NegAux),
         NNeg is NNegA + NNegB
     ) % end of main case
 ).

nnf_to_cnf_ccalc((A & B), Pos, PosAux, NPos, Neg, NegAux, NNeg, T) :-
 !,
 nnf_to_cnf_ccalc(A, PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA, T),
 (
  PosA = [[]]           % false
  -> nnf_to_cnf_ccalc(false, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;
  PosA = []             % true
  -> nnf_to_cnf_ccalc(B, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;                     % otherwise
     nnf_to_cnf_ccalc(B, PosB, PosAuxB, NPosB, NegB, NegAuxB, NNegB, T),
     (
      PosB = [[]]       % false
      -> nnf_to_cnf_ccalc(false, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
      ;
      PosB = []         % true
      -> [Pos, PosAux, NPos, Neg, NegAux, NNeg] 
         = [PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA]
      ;                 % otherwise

        % main case  
        % optimize formula (A && B) -- this is easy since A and B are already
        % in CNF after recursion  
         append(PosA, PosB, Pos),
         append(PosAuxA, PosAuxB, PosAux),
  
   % optimize formula's negation (-A ++ -B).  This requires distributing
   % disjunction over conjunction and possibly introducing auxiliary atoms;
   % it's analagous to the converting the positive form of a disjunction,
   % above.
         NPos is NPosA + NPosB,
         N00 is NNegA * NNegB,
         N10 is NNegB + NPosA + NNegA,
         N01 is NNegA + NPosB + NNegB,
         (
          (iccvar(ccalc_aux_opt, 0) ; N00 =< N10, N00 =< N01)
          ->
    % it's not worth introducing auxiliary vars
             pairwise_combinations(NegA, NNegA, NegB, NNegB, Neg),
             append(NegAuxA, NegAuxB, NegAux),
             NNeg = N00
          ;
          N10 =< N01
          ->
    % replace A.  
             new_aux_atom(K,NegK,T),
             insert_in_each(NegB, K, Neg),
             insert_in_each(NegA, NegK, NegAux1),
             insert_in_each(PosA, K, NegAux2),
             append_together([NegAuxA, NegAuxB,NegAux1, NegAux2, PosAuxA],
                             NegAux),
             NNeg = NNegB
          ;
    % replace B.  
             new_aux_atom(K,NegK,T),
             insert_in_each(NegA, K, Neg),
             insert_in_each(NegB, NegK, NegAux1),
             insert_in_each(PosB, K, NegAux2),
             append_together([NegAuxA, NegAuxB,NegAux1, NegAux2, PosAuxB],
                             NegAux),
             NNeg = NNegA
         )
     ) % main case
 ). 

% Here are the atoms

nnf_to_cnf_ccalc(Atom=Val, [[Atom=Val]], [], 1, [[Atom=OppVal]], [], 1, _T) :-
 OppVal is 1-Val.

%%%%% nnf_to_dnf_ccalc/8
%
% distribute_and_over_or converts a formula to DNF.  It works in the same
% manner as distribute_or_over_and, above. The result is returned in DNF list
% notation, which is a list of lists of atoms in which each sublist is a
% conjunction of atoms and the whole list is a disjunction of these
% conjunctions.  'false' is [] (the empty disjunction) and 'true' is
% [[]] (the empty conjunction).  Aux is still returned in CNF (since the
% auxiliary clauses are always added directly to the propositional theory,
% which is in CNF, rather than going through completion).
%
% As for nnf_to_cnf we need the time stamp parameter T for 
% time stamping any new auxiliary atoms. T=-1 will be ignored.
%
% This procedure is mostly uncommented since it parallels distribute_or_over_
% and, except where noted below.  See that procedure for details.  

nnf_to_dnf_ccalc(true, [[]], [], 1, [], [], 0, _T) :-
 !.
nnf_to_dnf_ccalc(false, [], [], 0, [[]], [], 1, _T) :-
 !.

nnf_to_dnf_ccalc((A & B), Pos, PosAux, NPos, Neg, NegAux, NNeg, T) :-
 !,
 nnf_to_dnf_ccalc(A, PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA, T),
 (
  PosA = []             % false
  -> nnf_to_dnf_ccalc(false, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;
  PosA = [[]]           % true
  -> nnf_to_dnf_ccalc(B, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;                     % otherwise





     nnf_to_dnf_ccalc(B, PosB, PosAuxB, NPosB, NegB, NegAuxB, NNegB, T),
     (
      PosB = []         % false
      -> nnf_to_dnf_ccalc(false, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
      ;
      PosB = [[]]       % true
      -> [Pos, PosAux, NPos, Neg, NegAux, NNeg] 
         = [PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA]

      ;                 % otherwise
         % main case   
         N00 is NPosA * NPosB,
         N10 is NPosB + NPosA + NNegA,
         N01 is NPosA + NPosB + NNegB,
         (
          (iccvar(ccalc_aux_opt, 0) ; N00 =< N10, N00 =< N01)
          -> pairwise_combinations(PosA, NPosA, PosB, NPosB, Pos),
             NPos is N00,
             append(PosAuxA, PosAuxB, PosAux)
          ;
          N10 =< N01
          -> new_aux_atom(K,NegK,T),
             insert_in_each(PosB, K, Pos),
             negate_lits(NegA, NegatedNegA),
             insert_in_each(NegatedNegA, NegK, PosAux1),
             negate_lits(PosA, NegatedPosA),
             insert_in_each(NegatedPosA, K, PosAux2),
             append_together([PosAuxA, PosAuxB,PosAux1, PosAux2, NegAuxA],
                             PosAux),
             NPos = NPosB
          ;
             new_aux_atom(K,NegK,T),
             insert_in_each(PosA, K, Pos),
             negate_lits(NegB, NegatedNegB),
             insert_in_each(NegatedNegB, NegK, PosAux1),
             negate_lits(PosB, NegatedPosB),
             insert_in_each(NegatedPosB, K, PosAux2),
             append_together([PosAuxA, PosAuxB,PosAux1, PosAux2, NegAuxB],
                             PosAux),
             NPos = NPosA
         ),
         append(NegA, NegB, Neg),
         append(NegAuxA, NegAuxB, NegAux),

         NNeg is NNegA + NNegB
     ) % end main case
 ).
  
nnf_to_dnf_ccalc((A ++ B), Pos, PosAux, NPos, Neg, NegAux, NNeg, T) :-
 !,
 nnf_to_dnf_ccalc(A, PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA, T),
 (
  PosA = [[]]           % true
  -> nnf_to_dnf_ccalc(true, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;
  PosA = []             % false
  -> nnf_to_dnf_ccalc(B, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
  ;                     % otherwise
     nnf_to_dnf_ccalc(B, PosB, PosAuxB, NPosB, NegB, NegAuxB, NNegB, T),
     (
      PosB = [[]]       % true
      -> nnf_to_dnf_ccalc(true, Pos, PosAux, NPos, Neg, NegAux, NNeg, T)
      ;
      PosB = []         % false
      -> [Pos, PosAux, NPos, Neg, NegAux, NNeg] 
         = [PosA, PosAuxA, NPosA, NegA, NegAuxA, NNegA]
      ;                 % otherwise
         % main case
         append(PosA, PosB, Pos),
         append(PosAuxA, PosAuxB, PosAux),
         NPos is NPosA + NPosB,
         N00 is NNegA * NNegB,
         N10 is NNegB + NPosA + NNegA,
         N01 is NNegA + NPosB + NNegB,
         (
          (iccvar(ccalc_aux_opt, 0) ; N00 =< N10, N00 =< N01)
          -> pairwise_combinations(NegA, NNegA, NegB, NNegB, Neg),
             append(NegAuxA, NegAuxB, NegAux),
             NNeg is N00
          ;
          N10 =< N01
          -> new_aux_atom(K,NegK,T),
             insert_in_each(NegB, K, Neg),
             negate_lits(PosA, NegatedPosA),
             insert_in_each(NegatedPosA, NegK, NegAux1),
             negate_lits(NegA, NegatedNegA),
             insert_in_each(NegatedNegA, K, NegAux2),
             append_together([NegAuxA, NegAuxB, NegAux1, NegAux2, PosAuxA],
                             NegAux),
             NNeg = NNegB
          ;
             new_aux_atom(K,NegK,T),
             insert_in_each(NegA, K, Neg),
             negate_lits(PosB, NegatedPosB),
             insert_in_each(NegatedPosB, NegK, NegAux1),

             negate_lits(NegB, NegatedNegB),
             insert_in_each(NegatedNegB, K, NegAux2),
             append_together([NegAuxA, NegAuxB,NegAux1, NegAux2, PosAuxB],
                             NegAux),
             NNeg is NNegB
         )
     ) % main case
 ).

nnf_to_dnf_ccalc(Atom=Val, [[Atom=Val]], [], 1, [[Atom=OppVal]], [], 1, _T) :-
 OppVal is 1-Val.
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 20: cnf and dnf utilities
%
% PREDICATES DEFINED:
%  - new_aux_atom/3
%  - insert_in_each/3
%  - pairwise_combinations/3
%  - pairwise_combinations/5
%  - pairwise_comb/4
%  - union_all/4
%  - union_all_x/4
%  - insert_new_list/4
%  - negate_lits/2
%  - has_complementary_lits/1
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% new_aux_atom/3

new_aux_atom(Atom=1,Atom=0,T) :-
 incr_iccvar(aux_var_index, J),
 (
  T < 0
  -> Atom = xaux(J) 
  ;  Atom = (T:xaux(J))
 ).

%%%%% insert_in_each/3

insert_in_each([],_,[]).

insert_in_each([List|Lists],X,[NewList|Rest]) :-
 ord_add_element(List, X, NewList), !,
 insert_in_each(Lists, X, Rest).

%%%%% pairwise_combinations/3

pairwise_combinations(ListA, ListB, Combs) :-
 length(ListA, NA),
 length(ListB, NB),
 pairwise_combinations(ListA, NA, ListB, NB, Combs).

%%%%% pairwise_combinations/5

pairwise_combinations(ListA, NA, ListB, NB, Combs) :-
 (
  NA > NB
  -> pairwise_comb(ListB, ListA, [], Combs)
  ;  pairwise_comb(ListA, ListB, [], Combs)
 ).

%%%%% pairwise_comb/4


pairwise_comb([], _ListB, Sofar, Sofar) :-
 !.

pairwise_comb([DA|RestA], ListB, Sofar, Combs) :-
 union_all_x(ListB, DA, Sofar, SofarX),
 !,
 pairwise_comb(RestA, ListB, SofarX, Combs).

%%%%% union_all/4

union_all([], _DA, Tail, Tail) :-
 !.

union_all([DB|ListB], DA, [DAB|Rest], Tail) :-
 ord_union(DA, DB, DAB), 
 !,
 union_all(ListB, DA, Rest, Tail).

%%%%% union_all_x/4

union_all_x([], _DA, Sofar, Sofar) :-
 !.

union_all_x([DB|ListB], DA, Sofar, Result) :-
 ord_union(DA, DB, DAB), 
 insert_new_list(Sofar, DAB, SofarX),
 !,
 union_all_x(ListB, DA, SofarX, Result).

%%%%% insert_new_list/4

insert_new_list([], New, [New]) :-
 !.

insert_new_list([X|Rest], New, [X|Rest]) :- 
 ord_subset(X, New), !.
insert_new_list([X|Rest], New, Result) :- 
 (
  ord_subset(New, X)
  -> Result = NewInRest
  ;  Result = [X|NewInRest]
 ),
 !,
 insert_new_list(Rest, New, NewInRest).

%%%%% negate_lits/2

negate_lits([],[]).

negate_lits([[Atom=Val|Ns]|Nss],[[Atom=OppVal|Cs]|Css]) :-
 OppVal is 1 - Val,
 negate_lits(Ns,Cs),
 negate_lits(Nss,Css).

negate_lits([Atom=Val|Ns],[Atom=OppVal|Cs]) :-
 OppVal is 1 - Val,
 negate_lits(Ns,Cs).

%%%%% has_complementary_lits/1
%
% lists are sorted

has_complementary_lits([Atom=0,Atom=1|_]) :-
 !.

has_complementary_lits(
  [(T:mvc(V, N1, Sig, Type, NDom, Nbits))=1,(T:mvc(V, N2, Sig, Type, NDom, Nbits))=1|_]) :- 
 N1 \= N2,
 !.

has_complementary_lits([_|OrdList]) :-
 has_complementary_lits(OrdList).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 21: displaying features of the action description
%
% PREDICATES DEFINED:
%  - hidden/1
%  - show/1
%  - action_desc_type/1
%  - info_out/0
%  - info/0
%  - info/1
%  - loadf/0
%  - loadf_info/1
%  - print_comments/1
%  - agents/0
%  - agents_out/1
%  - signature/0
%  - signature/1
%  - write_list_sep/3
%  - show_causal_laws/0
%  - show_causal_laws/1
%  - queries/0
%  - show_grounded_rules/0
%  - show_grounded_rules/1
%  - pretty_print_rule_body/2
%  - pretty_print_literal/2
%  - pretty_print_mvc_literal/2
%  - prolog_specific_space/0
%  - prolog_specific_space/1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% hidden/1 :: VISIBLE
%
% hides the display of atoms and constants when printing models

hidden(C) :-
 C == (ac=ff),
 !,
 set_opt(hidden_atom(ac=ff), 1).

hidden(C=V) :-
 ground(C), !,
 set_opt(hidden_atom(C=V), 1).

hidden(C) :-
 (
  ground(C)
  ->  retractall( icc_option(hidden_atom(C=_), _) ),
      set_opt(hidden_atom(C=_), 1) 
  ; true
 ).

%%%%% show/1 :: VISIBLE
%
% shows atoms and constants when displaying models
% undoes the effect of hidden/1

show(C) :-
 C == (ac=ff),
 !,
 retractall( icc_option(hidden_atom(ac=ff), _) ).

show(C=V) :-
 ground(C),
 !,
 retractall( icc_option(hidden_atom(C=V), _) ).

show(C) :-
 (
  ground(C)
  -> retractall( icc_option(hidden_atom(C=_), _) )
  ;  true
 ).

%%%%% action_desc_type/1 :: VISIBLE
%
% the possible types are: C+, C+timed, nC+timed, nC+, NOT C+

action_desc_type(Ctype) :-
 (
  iccvar(notCplus,1)
  -> Ctype = 'NOT C+'
  ;  T1 = 'C+',
     (
      iccvar(is_pCplus, 1)
      -> atom_concat(p, T1, T2)
      ;  T2 = T1
     ),
     (
      iccvar(is_cptimed,1)
      -> atom_concat(T2, 'timed', T3)
      ;  T3 = T2
     ),
     (
      iccvar(is_ncplus, 1)
      -> atom_concat(n, T3, T4)
      ;  T4 = T3
     ),
     (
      iccvar(is_ag_stranded, 1)
      -> atom_concat('stranded ', T4, Ctype)
      ;  Ctype = T4
     )
 ).

%%%%% info_out/0 :: VISIBLE

info_out :-
 iccvar(mainfile, File),
 atom_concat(File, '.info', FileName),
 open(FileName, 'write', Fd),
 info(Fd),
 close(Fd).

%%%%% info/0 :: VISIBLE

info :-
 current_output(Fd),
 info(Fd).

%%%%% info/1

info(Fd) :-
 loadf_info(Fd),
 iccvar(mainfile, _),
 !,
 agents_out(Fd),
 signature(Fd),
 show_causal_laws(Fd),
 show_grounded_rules(Fd).

info(_).

%%%%% loadf/0 :: VISIBLE

(loadf) :-  
 current_output(Fd),
 loadf_info(Fd).

%%%%% loadf_info/1 :: VISIBLE

loadf_info(Fd) :-
 action_desc_type(Ctype),
 format(Fd, 'ACTION LANGUAGE:   ~w~n', [Ctype]),
 fail.

loadf_info(Fd) :-
 iccvar(files, AbsFiles), 
 iccvar(file_basenames, [File|RestFiles]),
 !,
 (
  format(Fd, 'DOMAIN FILE(S):    ', []),
  member(FileName, [File|RestFiles]),
  (
   RestFiles \= [],
   FileName \= File
   -> format(Fd, ', ~w', [FileName])
   ;  format(Fd, '~w', [FileName])
  ),
  fail
  ;
  format(Fd, '~nABSOLUTE PATH(S):~n', []),
  member(Abs, AbsFiles),
  format(Fd, '  ~w~n', [Abs]),
  fail
  ;
  nl,
  print_comments(Fd)
 ).

loadf_info(Fd) :-
 format(Fd, 'DOMAIN FILE:     (NONE)', []),
 prolog_specific_space(Fd).


%%%%% print_comments/1

print_comments(_) :-
  \+ loadf_comments(_), 
  !.
print_comments(Fd) :-
  format(Fd, 'COMMENTS:~n', []),
  fail. 
print_comments(Fd) :-
  loadf_comments(String),
  format(Fd, String, []),
  fail.
print_comments(Fd) :- 
  prolog_specific_space(Fd).

%%%%% agents/0 :: VISIBLE

agents :-
 current_output(Fd),
 agents_out(Fd).

%%%%% agents_out/1
%
% Displays the agents, if iccvar(is_ag_stranded,1)

agents_out(Fd) :-
 \+ iccvar(loadf_filenames,_),
 !,
 info(Fd),
 fail.

agents_out(Fd) :-
 iccvar(is_ag_stranded,1),
 format(Fd, '~nAGENTS~n', []),
 agentlist(Agents),
 member(Ag, Agents),
 format(Fd, '~n~w', [Ag]),
 fail.

agents_out(_).

%%%%% signature/0 :: VISIBLE
%
% Displays the signature of the action description.

signature :-
 current_output(Fd),
 signature(Fd).

%%%%% signature/1

signature(Fd) :-
 \+ iccvar(loadf_filenames,_),
 !,
 info(Fd),
 fail.

signature(Fd) :-
 format(Fd, '~n~nSIMPLE FLUENT CONSTANTS~n', []),
 fc(C),
 format(Fd, '~n~w', [C]),
 fail.

signature(Fd) :-
 \+ (\+ sdfc(_)),
 format(Fd, '~n~nSTATICALLY DETERMINED FLUENT CONSTANTS~n', []),
 sdfc(C),
 format(Fd, '~n~w', [C]),
 fail.

signature(Fd) :-
 \+ (\+ ac(_)),
 format(Fd, '~n~nACTION CONSTANTS~n', []),
 ac(C),
 format(Fd, '~n~w', [C]),
 fail.

signature(Fd) :-
 format(Fd, '~n~nDOMAINS~n', []),
 (fc(C) ; sdfc(C) ; ac(C)),  % leaves out status/trans
 icc_dom(C, _, _, Dom, _, _),
 format(Fd, '~ndomain(~w)~40| = ', [C]),
 format(Fd, '{', []),
 write_list_sep(Dom, ', ', Fd),
 format(Fd, '}', []),
 (
  boolean_domain(C)
  -> format(Fd, '  (boolean)', [])
  ;  true
 ),
 fail.

signature(Fd) :-
 iccvar(is_pCplus, 1),
 (
  format(Fd, '~n~nPOLICIES~n', []),
  policy(is(Pol, Def)),
  (
   Def = pos
   -> format(Fd, '~n~w~20| (basic positive)', [Pol])
   ;
   Def = neg
   -> format(Fd, '~n~w~20| (basic negative)', [Pol])
   ;  format(Fd, '~n~w~20| = ~w', [Pol,Def])
  ),
  fail
  ;
  top(Pol),
  format(Fd, '~n~n~w is TOP', [Pol]),
  fail
 ).

signature(Fd) :-
 prolog_specific_space(Fd).

%%%%% write_list_sep/3

write_list_sep([], _, _) :-
 !.

write_list_sep([X], _, Fd) :-
 !,
 format(Fd, '~w', [X]).

write_list_sep([X|Rest], Sep, Fd) :-
 format(Fd, '~w~w', [X,Sep]),
 write_list_sep(Rest, Sep, Fd).

%%%%% show_causal_laws/0 :: VISIBLE

show_causal_laws :-
 current_output(Fd),
 show_causal_laws(Fd).

%%%%% show_causal_laws/1

show_causal_laws(Fd) :-
 \+ iccvar(loadf_filenames,_),
 !,
 info(Fd),
 fail.

show_causal_laws(Fd) :-
 format(Fd, '~nCAUSAL LAWS:~n', []),
 nCplus_rule(Rule),
 format(Fd, '~n~q', [Rule]),
 fail.

show_causal_laws(Fd) :-
 prolog_specific_space(Fd).
    
%%%%% queries/0 :: VISIBLE
 
queries :-
 format("~nBUILT-IN QUERIES:~n~n", []),
 builtin_query(Label, MaxTerm, Query), 
 format("   ~q:  ~q~n", [query(Label),query(MaxTerm, Query)]),
 fail.

queries :-  
 \+ iccvar(loadf_filenames,_),
 !,
 info,
 fail.

queries :-
 (
  query(_, _, _)
  -> format("~nPRE-DEFINED QUERIES:~n~n", []) 
  ;  true
 ),
 listing(/(query,3)),
 fail.

queries :-
 prolog_specific_space.

%%%%% show_grounded_rules/0 :: VISIBLE

show_grounded_rules :-
 current_output(Fd),
 show_grounded_rules(Fd).

%%%%% show_grounded_rules/1

show_grounded_rules(Fd) :-
 \+ iccvar(loadf_filenames,_), !,
 info(Fd),
 fail.

show_grounded_rules(Fd) :-
 (
  format(Fd, '~nSHIFTABLE RULES:~n', []),
  iccvar(max_tval,MaxTval),
  generate_integer(0, MaxTval, T),
  shiftable_rule(Head, T, BodyRN),
  rule_body(BodyRN, BodyAtoms)
  ;
  format(Fd, '~n~nNON-SHIFTABLE RULES:~n', []),
  icc_dom(C,state,fc,_Dom,NDom,Nbits),
  atom_integer(C, state, J, Nbits),
  generate_integer(1, NDom, Nth),
  Head = ((0:mvc(J, Nth, state, fc, NDom, Nbits))=1),
  BodyAtoms = [Head],
  T = 0
 ),
 format(Fd, '~n[~w]  ', [T]),
 pretty_print_literal(Head, Fd),
 format(Fd, ' <= ', []),

 pretty_print_rule_body(BodyAtoms, Fd),
 fail.

show_grounded_rules(Fd) :-
 prolog_specific_space(Fd).

%%%%% pretty_print_rule_body/2
%
% Prints the body of a causal rule.

pretty_print_rule_body([], Fd) :-
 !,
 format(Fd, 'true', []).

pretty_print_rule_body([Lit], Fd) :-
 !,
 pretty_print_literal(Lit, Fd).

pretty_print_rule_body([Lit|Rest], Fd) :-
 pretty_print_literal(Lit, Fd),
 format(Fd, ' & ', []), !,
 pretty_print_rule_body(Rest, Fd).

%%%%% pretty_print_literal/2

pretty_print_literal((T:mvc(V, Nth, Sig, Type, NDom, Nbits)) = BitVal, Fd) :-
 !,
 format(Fd, '~w:', [T]),
 pretty_print_mvc_literal(mvc(V, Nth, Sig, Type, NDom, Nbits) = BitVal, Fd).
  
pretty_print_literal(Lit, Fd) :-
 format(Fd, '~w', [Lit]).
  
%%%%% pretty_print_mvc_literal/2

pretty_print_mvc_literal(mvc(J, Nth, Sig, Type, 2, 1) = BitVal, Fd) :- 
 atom_integer(C, Sig, J, 1),
 icc_dom(C, Sig, Type, [A,B], 2, 1),
 !,
 (
  BitVal = 1 
  -> (
      Nth = 1
      -> V = A
      ;  V = B
     )
  ;  (
      Nth = 1
      -> V = B
      ;  V = A
     )
 ),
 (
  boolean_domain(C),
  icc_option(show_boolean,0)
  -> (
      V = A
      -> format(Fd, '~q', [C])
      ;  format(Fd, '-~q', [C])
     )
  ;  format(Fd, '~q=~q', [C,V])
 ).
   
pretty_print_mvc_literal(mvc(J, Nth, Sig, Type, NDom, Nbits) = BitVal, Fd) :- 
 atom_integer(C, Sig, J, Nbits),
 icc_dom(C, Sig, Type, Dom, NDom, Nbits), 
 nth(Nth, Dom, V), 
 !,
 (
  BitVal = 1
  -> Op = '='
  ;  Op = '\\='
 ),
 format(Fd, '~q~w~q', [C,Op,V]).

%%%%% prolog_specific_space/0

prolog_specific_space :-
 current_output(Fd),
 prolog_specific_space(Fd).

%%%%% prolog_specific_space/1

prolog_specific_space(Fd) :-
 (
  iccvar(prolog_version, swi)
  -> format(Fd, '~n', [])
  ;  format(Fd, '~n~n', [])
 ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 22: query processing, top level
%
% PREDICATES DEFINED:
%  - query/1
%  - is_mcluca_query/1
%  - query/2
%  - count/1
%  - count/2
%  - builtin_query/1
%  - get_query_min_max/3
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%% query/1 :: VISIBLE

query(_) :-
 \+ iccvar(loadf_filenames,_),
 !,
 format("~nNo domain file loadf'ed!!~n~n", []),
 fail.

query(Label) :-
 builtin_query(Label, MaxTerm, Query),
 !,
 query(MaxTerm, Query).
  
query(Label) :-
 query(Label, _, Query), 
 is_mcluca_query(Query),
 !,
 (
  mcluca_var(mcluca,on) 
  -> true
  ;  format("~nmcLUCA is not loaded (compile it).~n~n", []),
     fail
 ),
 mcluca_query(Query).

query(Label) :-
 query(Label, MaxTerm, Query),
% !,                            % cut removed, allowing parameterized queries
 query(MaxTerm, Query).
  
query(Query) :-  
 is_mcluca_query(Query),
 !,
 (
  mcluca_var(mcluca,on) 
  -> true
  ;  format("~nmcLUCA is not loaded (compile it).~n~n", []),
     fail
 ),
 mcluca_query(Query).
  
%%%%% is_mcluca_query/1

is_mcluca_query(Query) :-
 memberchk(Query, [trans(_), states(_), satisfiable(_), valid(_)]).

%%%%% query/2 :: VISIBLE
%
% for queries entered at runtime

query(_MaxTerm, _Query) :-
 \+ iccvar(loadf_filenames,_),
 !,
 format("~nNo domain file loadf'ed!!~n~n", []),
 fail.

query(MaxTerm, Query) :-
 format('~n** query(~w, ~q)~n~n', [MaxTerm, Query]),
 get_query_min_max(MaxTerm, Min, Max), 
 parse_dispatch_query(Min, Max, Query).

%%%%% builtin_query/1 :: VISIBLE
%
% CHECK add to these for policies etc.

builtin_query(states, 0, []).

builtin_query(trans, 1, []).

builtin_query(runs(N), N, []) :-
 integer(N),
 N >= 0.

builtin_query(greenstates, 0, [0:Status=Green]) :-
 iccvar(is_ncplus, 1), 
 icc_option(ncplus_symbols, [Status,_,Green,_]).

builtin_query(redstates, 0, [0:Status=Red]) :-
 iccvar(is_ncplus, 1),
 icc_option(ncplus_symbols, [Status,_,_,Red]).

builtin_query(greentrans, 1, [0:Trans=Green]) :-
 iccvar(is_ncplus, 1),
 icc_option(ncplus_symbols, [_,Trans,Green,_]).

builtin_query(redtrans, 1, [0:Trans=Red]) :-
 iccvar(is_ncplus, 1),
 icc_option(ncplus_symbols, [_,Trans,_,Red]).


%%%%% count/1 :: VISIBLE

count(X) :-
 (
  X = (M,Q) -> count(M,Q) ;
  X = query(M,Q) -> count(M,Q) ;
  X = query(Qx) -> Q = Qx
  ; Q = X
 ),
 set_iccvar(temp_solver, clasp_quiet),  % leave opt(solver,_) !!
 query(Q),
 !,
 remove_iccvar(temp_solver).
count(_) :-
 remove_iccvar(temp_solver),
 fail.

%%%%% count/2 :: VISIBLE

count(M,Q) :-
 set_iccvar(temp_solver, clasp_quiet),  % leave opt(solver,_) !!
 query(M,Q),
 !,
 remove_iccvar(temp_solver).
count(_,_) :-
 remove_iccvar(temp_solver),
 fail.



%%%%% get_query_min_max/3
%
% Where the query should be tried for a range of values of MaxStep,
% gets the <Min> and <Max> values.

get_query_min_max(Min..Max, Min, Max) :-
 integer(Min),
 Min >= 0,
 integer(Max),
 Max >= Min,
 !.

get_query_min_max(N, N, N) :-
 integer(N), N >= 0,
 !.
   
get_query_min_max(MinMax, _, _) :-
 format("~nERROR: Cannot make sense of query time spec ~q~n~n",[MinMax]),
 fail.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 23: parse and dispatch query
%
% PREDICATES DEFINED:
%  - parse_dispatch_query/3 
%  - check_query_time_range/5
%  - time_stamp_range/3
%  - time_step/2
%  - get_solver_mode_for_query/1
%  - solver_check/1
%  - find_solver_executable/2
%  - parse_query/5
%  - time_stamped_formula/3
%  - parse_query_item/6
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% parse_dispatch_query/3  

parse_dispatch_query(_Min, _Max, _Query) :-
 \+ iccvar(mainfile, _),
 !,
 loadf. 
  
parse_dispatch_query(Min, Max, Query) :-
 parse_query(Query, Max, QueryF, QueryFMax, Errors),
 (
  Errors = [_|_]
  -> print_parse_errors(Errors,0,0,_,_),
     fail
  ;  mvc_to_boolean(QueryF, QueryFBool),
     mvc_to_boolean(QueryFMax, QueryFMaxBool),
     nnf_to_cnf(QueryFBool, QueryCNF, 0, _, Min),               % no Aux 
     nnf_to_cnf(QueryFMaxBool, QueryMaxCNF, 0, _, Min)          % no Aux 
 ),
 check_query_time_range(Min,Max,QueryCNF,QueryMaxCNF, AdjMin),
 !,
 get_solver_mode_for_query(Solver),
 iterative_solve_query(AdjMin, AdjMin, Max, QueryCNF-Max-QueryMaxCNF, Solver).

%%%%% check_query_time_range/5
%
% What do we need to check?
% 1) That the minimum time stamp in each query component is >= 0,
%    else the query is ill-formed. For the fixed time component QueryCNF
%    it is easy. For the variable part QueryMaxCNF, time stamps in the
%    formula are calculated for query time T = Max. But the lowest value
%    will be for T = Min, after shifting. So we need to check that
%    TMinQvar - Max + Min >= 0.
%
% 2) The earliest possible solution time for the fixed time component
%    its maximum time stamp. The earliest possible solution time for
%    the variable part is its maximum time stamp, adjusted/shifted
%    down by Max-Min. The earliest possible solution time for the two
%    components must be =< Max. If it is > Min, then we can adjust
%    the iteration range for the iterative query: values less than
%    the earliest possible solution time cannot yield a solution.
   
check_query_time_range(Min,Max, QueryCNF, QueryMaxCNF, AdjMin) :-
 time_stamp_range(QueryCNF, TMinQ, TMaxQ),
 time_stamp_range(QueryMaxCNF, TMinQmax, TMaxQmax),
 !,
 (
  QueryMaxCNF = [] 
  -> MinStamp = TMinQ
  ;  MinStamp is min(TMinQ, TMinQmax + Min - Max)
 ),
 (
  MinStamp < 0
  -> format("~nERROR: Query is ill-formed (lam expressions)~n~n",[]),
     fail
  ;  true
 ),
 (
  QueryMaxCNF = [] 
  -> MinSolnTime = TMaxQ
   ; MinSolnTime is max(TMaxQ, TMaxQmax + Min - Max)
 ),
 (
  Max < MinSolnTime
  ->  format("~nNO SOLUTION: Earliest solution is at time ~w~n~n",[MinSolnTime]),
      fail
  ;   true
 ),
 (
  Min < MinSolnTime
  -> format("~nNOTE: Earliest possible solution is at time ~w", [MinSolnTime]),
     format("~n~nAdjusting query time range to ~w..~w~n~n", [MinSolnTime, Max]),
     AdjMin = MinSolnTime
  ;  AdjMin = Min
 ).

%%%%% time_stamp_range/3

time_stamp_range([], 0, 0) :-
 !.

time_stamp_range(CNF, Min, Max) :-
 findall(N, (member(C, CNF),
             member(Atom,C),
             time_step(Atom,N)), TimeSteps),
 (
  TimeSteps = []
  -> Min = 0,
     Max = 0
  ;  min_list(TimeSteps, Min),
     max_list(TimeSteps, Max)
 ).

%%%%% time_step/2

time_step((N:bool(J,_Index))=_, T) :-
 atom_integer(_, Sig, J, _),
 !,
 (
  Sig = state
  -> T = N
  ; T is N+1
 ).

%%%%% get_solver_mode_for_query/1
  
get_solver_mode_for_query(Solver) :-
 (iccvar(temp_solver, Solver) 
  -> true
  ;  icc_option(solver, Solver) ),
 solver_check(Solver),
 (
  environ(windir, _)
  -> atom_concat(Solver, '.exe', SolverFile)
  ;  SolverFile = Solver
 ),
 find_solver_executable(SolverFile, SolverExecutable),      % will fail if none
 !,
 set_iccvar(solver_executable, SolverExecutable).

get_solver_mode_for_query(write_cnf) :-
 set_iccvar(solver_executable, write_cnf).

%%%%% solver_check/1

solver_check(clpb) :-
 (iccvar(prolog_version, sicstus) ; iccvar(prolog_version, sicstus4)),
 !.

solver_check(clpb) :- !,
 write('**Warning: solver library(clpb) not supported in this version of Prolog'),
 nl,
 write('Transition and query CNF clauses will be written to file iccalc.clauses'),
 nl,
 fail.

solver_check(clpb2) :-
 (iccvar(prolog_version, sicstus) ; iccvar(prolog_version, sicstus4)),
 !.

solver_check(clpb2) :-
 !,
 write('**Warning: solver library(clpb) not supported in this version of Prolog'),
 nl,
 write('Transition and query CNF clauses will be written to file iccalc.clauses'),
 nl,
 fail.

%solver_check(clasp) :- 
% environ(windir,_),
% !,
% write('**Warning: solver \'clasp\' not supported in Windows OS'),
% nl,
% write('Transition and query CNF clauses will be written to file iccalc.in'),
% nl.

solver_check(clasp) :-
 !.

solver_check(clasp_quiet) :-
 !.


solver_check(Solver) :- 
 format('**Warning: solver ~w not supported', [Solver]),
 nl,
 write('Transition and query CNF clauses will be written to file iccalc.clauses'),
 nl,
 fail.

%%%%% find_solver_executable/2
%
% to find the solver executable, try in order
%  - option given by 'dir:solvers'
%  - look in iCCalc home dir just in case
%  - try in PATH

find_solver_executable(clpb,clpb) :-
 !,
 use_module(library(clpb)).

find_solver_executable(clpb2,clpb2) :-
 !,
 use_module(library(clpb)).

find_solver_executable(clasp_quiet,SolverExecutable) :-
 !,
 find_solver_executable(clasp,ClaspExecutable),
 atom_concat(ClaspExecutable, ' -q', SolverExecutable).
    
find_solver_executable(Solver,SolverExecutable) :-
 icc_option(dir:solvers, SolverDir), 
 absolute_file_name(Solver, SolverExecutable, 
      [access(exist), file_errors(fail), relative_to(SolverDir)]),
 !.

find_solver_executable(Solver,SolverExecutable) :-
 iccvar(iCCalc_dir, HomeDir),
 absolute_file_name(Solver, SolverExecutable, 
      [access(exist), file_errors(fail), relative_to(HomeDir)]),
 !.

find_solver_executable(Solver,Solver) :-
 format("Assuming solver ~w is in PATH.~n~n", [Solver]),
 !.

find_solver_executable(Solver,_) :-
 format("Cannot find executable for sat solver '~w'.",[Solver]),
 fail.
   
%%%%% parse_query/5
%
% A 'Query' is a truth-functional formula of time stamped formulas N:F
% where N is a non-negative integer or 'max' and F is a (non-time-stamped)
% truth-functional formula of mvc atoms: the same form as in bodies of
% causal laws. F can therefore include C1=C2 and C1 \= C2 conditions,
% and lam(.) expressions, though the latter only make sense (add value)
% when used in a time-stamped formula stamped with 'max'.

parse_query([], _Max, true, true, []) :-
 !.

parse_query([F|Rest], Max, ParsedQ, ParsedQMax, Errors) :-
 !,
 parse_query(F & Rest, Max, ParsedQ, ParsedQMax, Errors).
   
% nnf_to_cnf will sort out occurrences of true/false but
% do a basic check (most ParsedQMax will be 'true')   

parse_query(F & G, Max, ParsedQ, ParsedQMax, Errors) :-
 !,
 parse_query(F, Max, ParsedF, ParsedFMax, ErrorsF),
 (
  ParsedF = true
  -> ParsedQ = ParsedG 
  ;  ParsedQ = (ParsedF & ParsedG)
 ),
 (
  ParsedFMax = true
  -> ParsedQMax = ParsedGMax 
  ;  ParsedQMax = (ParsedFMax & ParsedGMax)
 ),
 append(ErrorsF, ErrorsG, Errors),
 !,
 parse_query(G, Max, ParsedG, ParsedGMax, ErrorsG).
   
parse_query(F ++ G, Max, ParsedQ, ParsedQMax, Errors) :- !,
 parse_query(F, Max, ParsedF, ParsedFMax, ErrorsF),
 (
  ParsedF = true
  -> ParsedQ = ParsedG 
  ;  ParsedQ = (ParsedF ++ ParsedG)
 ),
 (
  ParsedFMax = true
  -> ParsedQMax = ParsedGMax 
  ;  ParsedQMax = (ParsedFMax ++ ParsedGMax)
 ),
 append(ErrorsF, ErrorsG, Errors),
 !,
 parse_query(G, Max, ParsedG, ParsedGMax, ErrorsG).

parse_query(-(F), Max, ParsedNegF, ParsedNegFMax, Errors) :-
 equivnot(F, NegF),
 !, 
 parse_query(NegF, Max, ParsedNegF, ParsedNegFMax, Errors).

% the following deals with N:F and max:F, but also has to
% deal with -(N:F) and -(max:F)

parse_query(QTerm, Max, ParsedF, ParsedFMax, Errors) :-
 time_stamped_formula(QTerm, F, Stamp),         % deals with e.g. -2:p
 !,
 parse_query_item(F, Stamp, Max, ParsedF, ParsedFMax, Errors).

parse_query(Item, _, true, true, [ErrMsg]) :- 
 ErrMsg =
  error("Can't make sense of query item ~q~n~nTry adding brackets.",[Item]).

%%%%% time_stamped_formula/3
%
% allow max-N:F as shorhand for max:lam(N):F
%
% -(max:F) is dealt with already, but if we want to allow -max:F then we
% have to adjust: -max:F will be read as (-max):F. We won't support -3:F.
% Can write -(3:F) or 3:(-F). In any case -0:F will be read as 0:F so
% we don't want to encourage it.

time_stamped_formula(-(max-N:F), lam(N):(-(F)), max) :-
 integer(N),
 N > 0.

time_stamped_formula(-(max:F), -(F), max).

time_stamped_formula(max-N:F, lam(N):F, max) :-
 integer(N),
 N > 0.

time_stamped_formula(max:F, F, max).

% We need the next one, whether we have the shorthand or not

time_stamped_formula(-(N:F), -(F), N) :-
 integer(N), 
 N >= 0,
 !.
   
time_stamped_formula(N:F, F, N) :-
 integer(N), 
 N >= 0,
 !.

%%%%% parse_query_item/6

parse_query_item(F, max, Max, true, ParsedFMax, ErrorsItem) :-
 !,
 parse_stamp_fmla(F, Max, ParsedFMax, _Sig, _Sdfc, Tbinds, _LambdaMax, MaxAc, _DomEq, Errors),
 eval_timestamps(Tbinds),
 (
  MaxAc < Max
  -> ErrorsItem = Errors
  ;  ErrorsItem =
      [error("ERROR (No solution):  ~q can't be true at time ~q", [F, 'max'])
       |Errors]
 ).

parse_query_item(F, N, Max, ParsedF, true, ErrorsItem) :-
 !,
 parse_stamp_fmla(F, N, ParsedF, _Sig, _Sdfc, Tbinds, _LambdaMax, MaxAc, _DomEq, Errors),
 eval_timestamps(Tbinds),
 (
  MaxAc < Max
  -> ErrorsItem = Errors
  ;  ErrorsItem =
      [error("ERROR (No solution):  ~q can't be true at time ~w in a run of length ~w", [F,N,N])
       |Errors]
 ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 24: basic query loop iterating over times
%
% PREDICATES DEFINED:
%  - iterative_solve_query/5 
%  - solve_query/7  
%  - solve_query/6
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% iterative_solve_query/5  

iterative_solve_query(Over, _MinN, MaxN, _, _) :-
 Over > MaxN,
 !.

iterative_solve_query(T, Min, Max, Query, Solver) :-
 solve_query(Solver, T, Query, NModels, ClausesMs, SolMs, ReadModelsMs),
 (
  NModels > 0
  -> current_output(Fd),
     (
      Min = Max
      -> true
      ;  (
          NModels = 1
          -> format(Fd, 'Solution at time ~w', [T])
          ;  format(Fd, 'Solutions at time ~w', [T])
         )
     ),
     stats(_),
     display_models(NModels, T, Fd),
     stats(ShowModelsMs),
     solution_statistics(Fd, ClausesMs, SolMs, ReadModelsMs, ShowModelsMs),
     Tnext is Max + 1
  ;  current_output(Fd),
     format(Fd, 'No solution at time ~w', [T]),
     solution_statistics(Fd, ClausesMs, SolMs, ReadModelsMs),
     Tnext is T + 1
 ),
 !,
 iterative_solve_query(Tnext, Min, Max, Query, Solver).

%%%%%%% solve_query/7

solve_query(clpb,T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs) :-
 !,
 retractall( sat_model(_) ),
 set_iccvar(n_models,0),
 set_iccvar(query_time, T),
 solve_query_clpb(T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs).

solve_query(clpb2,T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs) :-
 !,
 retractall( sat_model(_) ),
 set_iccvar(n_models,0),
 set_iccvar(query_time, T),
 solve_query_clpb2(T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs).
    
solve_query(Solver,T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs) :- 
 retractall( sat_model(_) ),
 set_iccvar(n_models,0),
 set_iccvar(query_time, T),
 !,
 stats(_),
 set_iccvar(n_clauses, 0),
 make_solver_input(Solver,T,Query,ClausesMs),
 !,
 common_walltime(_),
 call_solver(Solver),
 !,
 common_walltime(SolutionMs),
 stats(_),
 process_solver_output(Solver, NModels, T),
 !,
 stats(ReadModelsMs).

%%%%% solve_query/6
%
% Used in  record_transition_subsystem/3. It is like
% parse_dispatch_query(T, T, Query) except the models are not displayed

solve_query(T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs) :-  
 get_solver_mode_for_query(Solver),
 !,
% solver_check(Solver),
% find_solver_executable(Solver, SolverExecutable),      % will fail if none
% !,
% set_iccvar(solver_executable, SolverExecutable),
 retractall( sat_model(_) ),
 set_iccvar(n_models,0),
 set_iccvar(query_time, T),
 solve_query(Solver,T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs).

solve_query(T, Query, NModels, ClausesMs, SolMs, ReadModelsMs) :-  
 retractall( sat_model(_) ),
 set_iccvar(n_models,0),
 set_iccvar(query_time, T),
 set_iccvar(solver_executable, write_cnf),
 solve_query(write_cnf,T, Query, NModels, ClausesMs, SolMs, ReadModelsMs).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 25: input for sat-solvers, calling, and call for solution processing
%
% PREDICATES DEFINED:
%  - make_solver_input/4
%  - make_clasp_input/3
%  - concat_files/3
%  - cat_files/2
%  - do_cat_files/2
%  - write_comp_query_cnf/6
%  - write_comp_cnf/5
%  - write_cnf_clauses/5
%  - write_clause/5
%  - write_clause_dimacs/4
%  - atom_to_integer/4
%  - write_cnf_to_file/3
%  - pretty_print_bool_list/2
%  - call_solver/1
%  - process_solver_output/3
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% make_solver_input/4
%
% dimacs format:
%
%  c Comment line
%  p cnf Natoms Nclauses
%  <each clause +/-ve integers terminated 0>

make_solver_input(clasp,T,Query,ClausesMs) :-
 make_clasp_input(T,Query,ClausesMs).

make_solver_input('clasp.exe',T,Query,ClausesMs) :-
 make_clasp_input(T,Query,ClausesMs).

make_solver_input(clasp_quiet,T,Query,ClausesMs) :-
 make_clasp_input(T,Query,ClausesMs).

make_solver_input(write_cnf,T,Query,ClausesMs) :-
 write_cnf_to_file(T,Query,ClausesMs).

%%%%% make_clasp_input/3

make_clasp_input(T,Query,ClausesMs) :-
 icc_option(dir:tmp, TMP),
 atom_concat(TMP, 'iccalc.dimacs', DIMACSFILE),
 open(DIMACSFILE, write, ClausesFd),
 write_comp_query_cnf(T, Query, NLits, NClauses, dimacs, ClausesFd), 
 close(ClausesFd),
 stats(ClausesMs),
 atom_concat(TMP, 'iccalc.info', INFOFILE),
 open(INFOFILE, write, InputFd),
 format(InputFd, 'p cnf ~w ~w~n', [NLits,NClauses]),
 close(InputFd),
 atom_concat(TMP, 'iccalc.in', INPUTFILE),
 concat_files(DIMACSFILE, INFOFILE, INPUTFILE).
  
%%%%% concat_files/3

concat_files(DIMACSFILE, INFOFILE, INPUTFILE) :-
 atoms_concat(['cat ',INFOFILE,' ',DIMACSFILE,' > ',INPUTFILE],CATCALL),
 shell(CATCALL),
 !.

concat_files(DIMACSFILE, INFOFILE, INPUTFILE) :-
 cat_files([INFOFILE,DIMACSFILE], INPUTFILE).

%%%%% cat_files/2

cat_files(InFiles, ResultFile) :-
 open(ResultFile, write, ResultFd),
 do_cat_files(InFiles, ResultFd).

%%%%% do_cat_files/2

do_cat_files([], ResultFd) :-
 close(ResultFd).

do_cat_files([File|Rest], ResultFd) :-
 open(File, read, Fd),
 repeat,
  get_code(Fd, Code),
  (
   Code == -1
   ;    
   put_code(ResultFd, Code),
   fail
  ),
 close(Fd),
 !,
 do_cat_files(Rest, ResultFd).

%%%%% write_comp_query_cnf/6

write_comp_query_cnf(T, Query, NLits, NClauses, Format, Fd) :-  
  
  % the number of integers (literals) in the theory 
 iccvar(n_state_vars, NstateVs),
 iccvar(n_trans_vars, NtransVs),
 NBasicVars is NstateVs + NtransVs,  
 NTheoryVars is T*NBasicVars + NstateVs,
  
 retractall(aux_var_integer(_,_)),
 set_iccvar(n_aux_vars, 0),
  % n_aux_vars will be incremented as clauses are 
  % translated to integers
  
 make_query_clauses(T, Query, QueryClauses),
  
 set_iccvar(n_clauses, 0),
 (
  QueryClauses = []
  ->  true
  ;   (
        Format = dimacs 
        ->  format(Fd, "c CNF of the query~n", [])
        ;   format(Fd, "%% CNF of the query~n", [])
      )
 ),
 write_cnf_clauses(QueryClauses, NBasicVars, NTheoryVars, Format, Fd),
 (
  Format = dimacs 
  -> format(Fd, "c CNF of the completion (runs ~w)~n", [T])
  ;  format(Fd, "%% CNF of the completion (runs ~w)~n", [T])

 ),
 write_comp_cnf(T, NBasicVars, NTheoryVars, Format, Fd),
  
  % the number of integers (literals) in the cnf 
 iccvar(n_aux_vars, NAux),
 NLits is NTheoryVars + NAux,
 iccvar(n_clauses, NClauses).

%%%%% write_comp_cnf/5

write_comp_cnf(T, NBasicVars, NTheoryVars, Format, Fd) :-
 completion_clause(T, C),
 incr_iccvar(n_clauses, _),
 write_clause(C, NBasicVars, NTheoryVars, Format, Fd),
 fail.

write_comp_cnf(_, _, _, _, _).

%%%%% write_cnf_clauses/5

write_cnf_clauses(Clauses, NBasicVars, NTheoryVars, Format, Fd) :-
 member(C, Clauses),
 incr_iccvar(n_clauses, _),
 write_clause(C, NBasicVars, NTheoryVars, Format, Fd),
 fail.

write_cnf_clauses(_, _, _, _, _).

%%%%% write_clause/5

write_clause(C, NBasicVars, NTheoryVars, dimacs, Fd) :-
 !,
 write_clause_dimacs(C, NBasicVars, NTheoryVars, Fd).

write_clause(C, NBasicVars, NTheoryVars, _, _Fd) :- 
 member(Atom=_Val, C),
 atom_to_integer(Atom, NBasicVars, NTheoryVars, _N),
 fail.

write_clause(C, _NBasicVars, _NTheoryVars, _, Fd) :- 
 pretty_print_bool_list(C, Fd).

%%%%% write_clause_dimacs/4

write_clause_dimacs([], _, _,Fd) :-
 !,
 format(Fd, '0~n', []).

write_clause_dimacs([Atom=Val|Rest], NBasicVars, NTheoryVars, Fd) :-
 atom_to_integer(Atom, NBasicVars, NTheoryVars, N),
 (
  Val = 1
  -> NN = N
  ;  NN is -N
 ),
 format(Fd, '~w ', [NN]), !,
 write_clause_dimacs(Rest, NBasicVars, NTheoryVars, Fd).

%%%%% atom_to_integer/4

atom_to_integer(T:bool(J,Index), NBasicVars, _NTheoryVars, N) :-
 !,
 N is NBasicVars*T + J + Index - 1.

% the only other case is Atom = T:xaux(J)
% but let's make this catchall just in case

atom_to_integer(Atom, _NBasicVars, NTheoryVars, N) :-
 (
  aux_var_integer(Atom, N)
  -> true
  ;  incr_iccvar(n_aux_vars, J),
     N is NTheoryVars + J,
     assert( aux_var_integer(Atom, N))
 ).
    
%%%%% write_cnf_to_file/3   

write_cnf_to_file(T,Query,ClausesMs) :-
 icc_option(dir:working, DIR),
 atom_concat(DIR, 'iccalc.clauses', OUTFILE),
 open(OUTFILE, write, Fd),
 write_comp_query_cnf(T, Query, NLits, NClauses, pretty_bool, Fd), 
 format(Fd,"~n%% Stats: Literals ~w; Clauses ~w ~n", [NLits,NClauses]),
 close(Fd),
 stats(ClausesMs).

%%%%% pretty_print_bool_list/2

pretty_print_bool_list([], Fd) :-
 !,
 nl(Fd).
   
pretty_print_bool_list([Atom|Rest], Fd)  :-
 pretty_print_bool_atom(Atom, Fd),
 !,
 pretty_print_bool_list(Rest, Fd).

pretty_print_bool_atom((N:xaux(J))=Val, Fd) :-
 !,
 (
  Val = 0
  -> format(Fd, '-', [])
  ;  true
 ),
 format(Fd, "~w:aux(~w) ", [N,J]).

pretty_print_bool_atom((N:bool(J,Index))=Val, Fd) :- 
 atom_integer(C, _, J, Nbits), !,
 (
  Val = 0
  -> format(Fd, '-', [])
  ;  true
 ),
 format(Fd, "~w:~q", [N,C]),
 (
  Nbits = 1,
  boolean_domain(C)
  -> true 
  ;  format(Fd, "[~w/~w]", [Index, Nbits])
 ),
 format(Fd, ' ', []).

pretty_print_bool_atom(Unknown, Fd) :- 
 format(Fd, "~q ", [Unknown]).

%%%%% call_solver/1

call_solver(clasp_quiet) :-
 !,
 call_solver(clasp). % rest is identical

call_solver(clasp) :-
 iccvar(solver_executable, ClaspExecutable),
 !,
 icc_option(num_models, NumModelsFlag),
 (
  NumModelsFlag = all
  -> NumModels = 0
  ;  NumModels = NumModelsFlag
 ),
 number_chars(NumModels, NumModelsChars),
 atom_chars(NumModelsAtom, NumModelsChars),
 icc_option(dir:tmp, TMP),
 atoms_concat([ClaspExecutable,' -n ',NumModelsAtom,' ',
               TMP,'iccalc.in',' > ',TMP,'iccalc.out'],Call),
 shell(Call, _).         % needed as exit codes are meaningful for clasp

call_solver(write_cnf) :- 
 iccvar(n_state_vars, NFvars),
 iccvar(n_trans_vars, NAvars),
 iccvar(n_aux_vars, NAux),
 iccvar(query_time, T),
 NInts is NFvars + T*(NFvars + NAvars) + NAux,
 iccvar(n_clauses, NClauses),
 format("No solver executable.~n", []),
 format("~n~nLiterals: ~w     Clauses:~w~n~n", [NInts,NClauses]).

%%%%% process_solver_output/3

process_solver_output(clasp, NModels, _) :-
 icc_option(dir:tmp, TMP),
 atom_concat(TMP, 'iccalc.out', FILE),
 open(FILE, read, SolverOutput),
 process_clasp_output(SolverOutput, all, NModels),
 close(SolverOutput).

process_solver_output(clasp_quiet, NModels, _) :-
 process_clasp_quiet_output(NModels).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 26: processing clasp output
%
% PREDICATES DEFINED:
%  - process_clasp_output/3
%  - clasp_output_read_loop/3
%  - extract_store_clasp_model/2
%  - extract_clasp_model/2
%  - extract_clasp_template_model/3
%  - store_sat_models/2
%  - instantiate_vars_to_bits/2
%  - get_numbers/2
%  - remove_spaces/2
%  - get_number/3
%  - get_until/4
%
%  - process_clasp_quiet_output/1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% process_clasp_output/3

% The argument Template is used by mcLUCA.
% In iCCalc it is always 'all'

process_clasp_output(Fd, Template, NModels) :-
 read_line(Fd, Line),
 (
  Line = end_of_file
  -> iccvar(n_models, NModels)
  ;  (
      append("c Answer", _, Line)
      -> clasp_output_read_loop(Fd, [], Lits),
         extract_store_clasp_model(Template, Lits)
      ;
      append("c Models", _, Line)
      -> (
          append(_, [43|_], Line)  % [43] = "+"
          -> set_iccvar(more_models, 1)
          ;  set_iccvar(more_models, 0)
         )
      ;  true
     ),
     process_clasp_output(Fd, Template, NModels)
 ).

%%%%% clasp_output_read_loop/3
%
% read and process all lines until one ends in '0'

clasp_output_read_loop(Fd, InLits, Lits) :-
 read_line(Fd, Line),
 append("v ", Numbers, Line),
 get_numbers(Numbers, AllLits),
 (
  append(NewLits, [0], AllLits)
  -> append(InLits, NewLits, Lits)
  ;  NewLits = AllLits,
     append(InLits, NewLits, OutLits),
     clasp_output_read_loop(Fd, OutLits, Lits)
 ).

%%%%% extract_store_clasp_model/2

extract_store_clasp_model(Template, Lits) :-
 (
  Template = all   % iCCalc 
  -> extract_clasp_model(Lits, Model)
  ;  extract_clasp_template_model(Template, Lits, Model)
 ),
 store_sat_models(Template,Model).


%%%%% extract_clasp_model/2

extract_clasp_model([], []).

extract_clasp_model([Lit|RestLits], [Bit|RestBool]) :-
 (
  Lit < 0
  -> Bit = 0
  ;  Bit = 1
 ),
 !,
 extract_clasp_model(RestLits, RestBool).


%%%%% extract_clasp_template_model/3

extract_clasp_template_model([], _Lits, []).

extract_clasp_template_model([Item|Rest], Lits, [Bit|RestBool]) :-
 (
  var(Item) -> Bit = Item ;
  Item = 0  -> Bit = 0 ;
  Item = 1  -> Bit = 1 ;
  Item = lit(N), member(N, Lits)
  -> Bit = 1
  ;  Bit = 0
 ),
 !,
 extract_clasp_template_model(Rest, Lits, RestBool).


%%%%% store_sat_models/2

store_sat_models(Template, Model) :-
 ground(Template), % Template = all for iCCalc
 !,
 (
  sat_model(Model)
  -> true   % we already have it
  ;  assert(sat_model(Model)),
     incr_iccvar(n_models,_)
 ).
store_sat_models(Template, Model) :-
 instantiate_vars_to_bits(Template), 
 (
  sat_model(Model)
  -> true   % we already have it
  ;  assert(sat_model(Model)),
     incr_iccvar(n_models,_)
 ),
 fail.
store_sat_models(_, _).

%%%%% instantiate_vars_to_bits/2

instantiate_vars_to_bits([]).
instantiate_vars_to_bits([Item|Rest]) :-
  (ground(Item) -> true ; Item = 0 ; Item = 1),
  instantiate_vars_to_bits(Rest).


%%%%% get_numbers/2

get_numbers(String,Nums) :-
 remove_spaces(String,NewS),
 (
  NewS = [] 
  -> Nums = [] 
  ;  get_number(NewS,Num,Rest), 
     Nums = [Num|Nums1],
     get_numbers(Rest,Nums1)
 ).

%%%%% remove_spaces/2

remove_spaces([], []) :-
 !.

remove_spaces([9|Rest], Removed) :-
 !,
 remove_spaces(Rest, Removed).

remove_spaces([32|Rest], Removed) :-
 !,
 remove_spaces(Rest, Removed).

remove_spaces(X, X).

%%%%% get_number/3

get_number(String,Num,Rest) :-
 get_until(String,[32,10],Chars,Rest), 
 common_number_chars(Num,Chars).

%%%%% get_until/4

get_until([],_,[],[]).

get_until([Char|Cs],Delimiters,[],Cs) :-
 member(Char,Delimiters),
 !.

get_until([C|Cs],Delimiters,[C|Chars],Rest) :-
 get_until(Cs,Delimiters,Chars,Rest).



%%%%% process_clasp_quiet_output/1

process_clasp_quiet_output(NModels) :-
 icc_option(dir:tmp, TMP),
 atoms_concat([TMP,'iccalc.tmp'],TMPFILE),
 atoms_concat(['grep "c Models" ',TMP,'iccalc.out',' > ',TMPFILE],
              CALL),
 shell(CALL,_),
 open(TMPFILE, read, Fd),
 read_line(Fd, Line),
 close(Fd),
 append("c Models    : ", LineX, Line),
 get_number(LineX, NModels, _), !,
 set_iccvar(n_models,NModels).

process_clasp_quiet_output(0) :-
  set_iccvar(n_models,0).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 27: clp(b) solver
%
% PREDICATES DEFINED:
%  - solve_query_clpb/6
%  - solve_query_clpb2/6
%  - make_query_clauses/3
%  - find_assert_clpb_models/2
%  - sat_list/1
%  - atom_var_bindings/3
%  - bool_var_list/2
%  - bool_var_list_aux/5
%  - make_bindings/6
%  - extend_bindings/8
%  - hollow_out_clpb_clause_list/4
%  - hollow_out_clpb_clause/5
%  - hollow_out_atom/6
%  - hollow_out_clpb_clause_list2list/4
%  - hollow_out_clpb_formula_list/4
%  - hollow_out_clpb_formula/5
% 
% The basic idea ...
%

% We take a clause (or any boolean expression) made up of atoms/integers.
% Then we make a copy of it, with variables replacing every atom/integer,
% together with a list Vars of the variables in the 'hollow' copy and a list
% of bindings of the form P=Pvar  where P is the atom/var and Pvar is the
% variable that replaces it in the hollow copy.
% Then we call sat(HollowExpn). Then labeling(Vars) binds all the variables,
% and bindings P=Pvar record the solution.
%      call_solver_clpb :-
%        retractall(sat_model(_)),
%        findall(Clause, clpb_clause(Clause), Clauses),
%        hollow_out_clpb_list(Clauses, Expn, [],[],Binds,Vars), !,
%        find_assert_clpb_models(Expn,Binds,Vars).
% 
%      find_assert_clpb_models(Expn,Binds,Vars) :-
%        sat(Expn),
%        labeling(Vars),
%        assert(sat_model(Binds)), 
%          % OR  assert(sat_model(Vars))  % depending how models represented
%        fail.
%      find_assert_clpb_models(_Expn,_Binds,_Vars).
%
% That works, but there is a better way.
%
% We know what the atoms (boolean) in comp(MaxTval) are. 
% So to avoid missing anything, let's construct the bindings list first,
% and then use that to 'hollow out' the cnf that we need to solve. 
% 
% Now when we call sat(HollowExpn) we only ask labeling for those vars
% which were bound to atoms in comp(MaxTval), not vars that were bound to
% extra auxiliary atoms (if any) that might have been introduced
% when computing the completion and its cnf. 
% Conveniently, clpb does not return duplicate models, so
% that also saves some work: we only need labeling for vars that correspond
% to non-auxiliary atoms. We still have to maintain a bindings list for
% the auxiliary atoms but we don't need their vars for labeling.
%
% Now: models obtained from the sat solvers are represented as a list of bits,
% in a standard order as determined by the atom_integer_map. In order to
% interpret those bit lists correctly, it is essential to ensure that the
% vars list for labeling preserves this ordering. So, when we construct
% the initial bindings/vars list we will sort it according to the indices
% given by atom_integer_map (rather than simply relying on findall). The
% sorting is probably redundant but safer to do it.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% solve_query_clpb/6

solve_query_clpb(T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs) :-
 stats(_),
 make_query_clauses(T, Query, QueryClauses),
 atom_var_bindings(T, Bindings, Vars),
 findall(Clause, completion_clause(T, Clause), AllClauses, QueryClauses),
 hollow_out_clpb_clause_list(AllClauses, Bindings, Expn, []),
 !,
 stats(ClausesMs),
 find_assert_clpb_models(Expn,Vars),
 stats(SolutionMs),
 iccvar(n_models, NModels),
 !,
 stats(ReadModelsMs).

%%%% solve_query_clpb2/6

solve_query_clpb2(T, Query, NModels, ClausesMs, SolutionMs, ReadModelsMs) :-
 stats(_),
 make_query_clauses(T, Query, QueryClauses),
 atom_var_bindings(T, Bindings, Vars),
 findall(Clause, completion_clause(T, Clause), AllClauses, QueryClauses),
 hollow_out_clpb_clause_list2list(AllClauses, Bindings, ExpnList, []),
 !,
 stats(ClausesMs),
 find_assert_clpb_models(ExpnList,Vars),
 stats(SolutionMs),
 iccvar(n_models, NModels),
 !,
 stats(ReadModelsMs).

%%%%% make_query_clauses/3

make_query_clauses(T, Query-Max-QueryMax, QueryClauses) :-
 !,
 Shift is T - Max,
 shift_cnf(QueryMax, Shift, QueryPart2),
 append(Query, QueryPart2, QueryClauses).

make_query_clauses(_T, QueryClauses, QueryClauses).  

%%%%% find_assert_clpb_models/2

find_assert_clpb_models(Expn,Vars) :-
 (
  is_list(Expn)
  -> sat_list(Expn)
  ;  sat(Expn)
 ),
 labeling(Vars),
 assert(sat_model(Vars)), 
 incr_iccvar(n_models,_),
 fail.

find_assert_clpb_models(_Expn,_Vars).

%%%%% sat_list/1

sat_list([]) :-
 !.

sat_list([Expn|Rest]) :-
 sat(Expn),
 !,

 sat_list(Rest).

%%%%% atom_var_bindings/3
%
% we must make sure that boolean atoms are processed in the correct order

atom_var_bindings(T, Bindings, Vars) :-
 iccvar(state_integers, StateNs),
 iccvar(trans_integers, TransNs),
 bool_var_list(StateNs, State),
 bool_var_list(TransNs, Trans),
 make_bindings(State, 0, Bindings, Vars, BindingsX, VarsX),
 !,
 extend_bindings(1, T, State, Trans, BindingsX, VarsX, [], []).

%%%%% bool_var_list/2
%
% boolean vars are represented internally  bool(Index,BitN)

bool_var_list([], []) :-
 !.

bool_var_list([Index|Rest], List) :-
 atom_integer(_,_,Index,Nbits),
 bool_var_list_aux(1, Nbits, Index, List, Tail),
 !,
 bool_var_list(Rest, Tail).

%%%%% bool_var_list_aux/5

bool_var_list_aux(N, Nbits, _, Tail, Tail) :-
 N > Nbits,
 !.

bool_var_list_aux(N, Nbits, Index, [bool(Index,N)|List], Tail ) :-
 NextN is N + 1,
 bool_var_list_aux(NextN, Nbits, Index, List, Tail).

%%%%% make_bindings/6

make_bindings([], _N, TailB, TailV, TailB, TailV) :-
 !.

make_bindings([Atom|Rest], N, [(N:Atom)=Var|Bindings], [Var|Vars], TailB, TailV) :-
 make_bindings(Rest, N, Bindings, Vars, TailB, TailV).

%%%%% extend_bindings/8
  
extend_bindings(N, Nmax, _State, _Trans, TailB, TailV, TailB, TailV) :-
 N > Nmax,
 !.

extend_bindings(N, Nmax, State, Trans, Bindings, Vars, TailB, TailV) :-
 NextN is N + 1,
 PrevN is N - 1,
 make_bindings(Trans, PrevN, Bindings, Vars, BindingsX, VarsX),
 make_bindings(State, N, BindingsX, VarsX, BindingsY, VarsY),
 !,
 extend_bindings(NextN, Nmax, State, Trans, BindingsY, VarsY, TailB, TailV).
  
%%%%% hollow_out_clpb_clause_list/4
%
% note SICStus clpb solver syntax:
%
% ~ P True if P is false.
% P * Q True if P and Q are both true.
% P + Q True if at least one of P and Q is true.
% P # Q True if exactly one of P and Q is true.
% X ^ P True if there exists an X such that P is true. Same as P[X/0] + P[X/1].
% P =:= Q Same as ~P # Q.
% P =\= Q Same as P # Q.
% P =< Q Same as ~P + Q. (This is P -> Q)
% P >= Q Same as P + ~Q.
% P < Q Same as ~P * Q.
% P > Q Same as P * ~Q.
% card(Is, Es) True if the number of true expressions in Es is a
%              member of the set denoted by Is.

%%%%% hollow_out_clpb_clause_list/4

hollow_out_clpb_clause_list([], _Bindings, 1, _AuxBinds) :-
 !.

hollow_out_clpb_clause_list([Clause], Bindings, Hollow, AuxBinds) :-
 !,
 hollow_out_clpb_clause(Clause, Bindings, Hollow, AuxBinds, _AuxBindsX).

hollow_out_clpb_clause_list([Clause,Next|Rest], Bindings, RestExpn * Hollow, AuxBinds) :-
 hollow_out_clpb_clause(Clause, Bindings, Hollow, AuxBinds, AuxBindsX),
 !,
 hollow_out_clpb_clause_list([Next|Rest], Bindings, RestExpn, AuxBindsX).

%%%%% hollow_out_clpb_clause/5

hollow_out_clpb_clause([], _Bindings, 0, AuxBinds, AuxBinds) :-
 !.

hollow_out_clpb_clause([Atom], Bindings, HollowAtom, AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_atom(Atom, Bindings, HollowAtom, AuxBinds, AuxBindsOut, clpb).

hollow_out_clpb_clause([Atom,Next|Rest], Bindings, HollowRest+HollowAtom, AuxBinds, AuxBindsOut) :-
 hollow_out_atom(Atom, Bindings, HollowAtom, AuxBinds, AuxBindsX, clpb),
 !,
 hollow_out_clpb_clause([Next|Rest], Bindings, HollowRest, AuxBindsX, AuxBindsOut).
  
  
%%%%% hollow_out_clpb_clause_list2list/4

%% (This is for clpb2  (sat_list))

hollow_out_clpb_clause_list2list([], _Bindings, [], _AuxBinds) :-
 !.

hollow_out_clpb_clause_list2list([Clause|Rest], Bindings, [Hollow|RestHollow], AuxBinds) :-
 hollow_out_clpb_clause(Clause, Bindings, Hollow, AuxBinds, AuxBindsX),
 !,
 hollow_out_clpb_clause_list2list(Rest, Bindings, RestHollow, AuxBindsX).

%%%%% hollow_out_clpb_formula_list/4

hollow_out_clpb_formula_list([], _Bindings, 1, _AuxBinds) :-
 !.

hollow_out_clpb_formula_list([F], Bindings, Hollow, AuxBinds) :-
 !,
 hollow_out_clpb_formula(F, Bindings, Hollow, AuxBinds, _AuxBindsX).

hollow_out_clpb_formula_list([F,Next|Rest], Bindings, RestExpn * Hollow, AuxBinds) :-
 hollow_out_clpb_formula(F, Bindings, Hollow, AuxBinds, AuxBindsX),
 !,
 hollow_out_clpb_formula_list([Next|Rest], Bindings, RestExpn, AuxBindsX).

%%%%% hollow_out_clpb_formula/5

hollow_out_clpb_formula(-(F), Bindings, ~(Hollow), AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_clpb_formula(F, Bindings, Hollow, AuxBinds, AuxBindsOut). 

hollow_out_clpb_formula(~(F), Bindings, ~(Hollow), AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_clpb_formula(F, Bindings, Hollow, AuxBinds, AuxBindsOut). 

hollow_out_clpb_formula((F =:= G), Bindings, (HollowF =:= HollowG), AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_clpb_formula(F, Bindings, HollowF, AuxBinds, AuxBindsX),
 hollow_out_clpb_formula(G, Bindings, HollowG, AuxBindsX, AuxBindsOut). 

hollow_out_clpb_formula((F + G), Bindings, (HollowF + HollowG), AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_clpb_formula(F, Bindings, HollowF, AuxBinds, AuxBindsX),
 hollow_out_clpb_formula(G, Bindings, HollowG, AuxBindsX, AuxBindsOut). 

hollow_out_clpb_formula((F ++ G), Bindings, (HollowG + HollowF), AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_clpb_formula(F, Bindings, HollowF, AuxBinds, AuxBindsX),
 hollow_out_clpb_formula(G, Bindings, HollowG, AuxBindsX, AuxBindsOut). 

hollow_out_clpb_formula((F * G), Bindings, (HollowF * HollowG), AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_clpb_formula(F, Bindings, HollowF, AuxBinds, AuxBindsX),
 hollow_out_clpb_formula(G, Bindings, HollowG, AuxBindsX, AuxBindsOut). 

hollow_out_clpb_formula((F & G), Bindings, (HollowG * HollowF), AuxBinds, AuxBindsOut) :-
 !,
 hollow_out_clpb_formula(F, Bindings, HollowF, AuxBinds, AuxBindsX),
 hollow_out_clpb_formula(G, Bindings, HollowG, AuxBindsX, AuxBindsOut). 

hollow_out_clpb_formula(0, _Bindings, 0, AuxBinds, AuxBinds) :-
 !.
hollow_out_clpb_formula(1, _Bindings, 1, AuxBinds, AuxBinds) :-
 !.

hollow_out_clpb_formula(Atom, Bindings, HollowAtom, AuxBinds, AuxBindsOut) :- 
 hollow_out_atom(Atom, Bindings, HollowAtom, AuxBinds, AuxBindsOut, clpb).


%%%%% hollow_out_clause_list/4
%%%%% hollow_out_clause/5

% not clpb!
% Used in mcLUCA

hollow_out_clause_list([], _Bindings, [], _AuxBinds) :-
 !.
hollow_out_clause_list([Clause|Rest], Bindings, [Hollow|RestHollow], AuxBinds) :-
 hollow_out_clause(Clause, Bindings, Hollow, AuxBinds, AuxBindsX),
 !,
 hollow_out_clause_list(Rest, Bindings, RestHollow, AuxBindsX).

hollow_out_clause([], _Bindings, [], AuxBinds, AuxBinds) :-
 !.
hollow_out_clause([Atom|Rest], Bindings, [HollowAtom|HollowRest], AuxBinds, AuxBindsOut) :-
 hollow_out_atom(Atom, Bindings, HollowAtom, AuxBinds, AuxBindsX, not_clpb),
 !,
 hollow_out_clause(Rest, Bindings, HollowRest, AuxBindsX, AuxBindsOut).


%%%%% hollow_out_atom/6

hollow_out_atom((N:AuxAtom)=V, _Bindings, HollowAtom, AuxBinds, AuxBindsX, Syntax) :- 
 (
  AuxAtom = xaux(_)
  ;
  AuxAtom = mvc(_,_,_,_,_,_)
 ),
 !,
 (
  member((N:AuxAtom)=XVar, AuxBinds)
  -> AuxBindsX = AuxBinds,
     Var = XVar
  ;  AuxBindsX = [(N:AuxAtom)=Var|AuxBinds]
 ),
 (
  V = 1
  -> HollowAtom = Var
  ;  (Syntax = clpb
      -> HollowAtom = ~(Var)
      ;  HollowAtom = -(Var)
     )
 ).

hollow_out_atom(Atom=V, Bindings, HollowAtom, AuxBinds, AuxBinds, Syntax) :- 
 member(Atom=Var, Bindings),
 !,
 (
  V = 1
  -> HollowAtom = Var
  ;  (Syntax = clpb
      -> HollowAtom = ~(Var)
      ;  HollowAtom = -(Var)
     )
 ).

hollow_out_atom(AtomV, _,_,_,_, _Syntax) :- 
 format("~n!!!STRANGE Atom: ~q~n", [AtomV]),
 fail.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 28: display of models
%
% PREDICATES DEFINED:
%  - display_models/0
%  - display_models/3
%  - display_models/6
%  - show_model/7
%  - show_ncplus_col/5
%  - print_tabbed/3
%  - get_mvc_atoms/4
%  - bit_list_to_mvc/4
%  - bit_list_to_index/4
%  - bit_list_to_index/6
%  - index_to_bit_list/4   
%  - show_mvc_atoms/3
%  - pretty_print_mvc_atom/3
%  - pretty_print_mvc_atom/6

%  - hidden_atom/3
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% display_models/0 :: VISIBLE
%

% display models already stored

display_models :-
 set_iccvar(show_models, 1),
 iccvar(n_models, NModels),
 NModels > 0,
 iccvar(query_time, T),
 !,
 current_output(Fd),
 display_models(NModels, T, Fd),
 prolog_specific_space.

display_models.

%%%%% display_models/3

display_models( NModels, _T, Fd) :-
 iccvar(show_models, 0),
 !,
 format(Fd, "~nModels: ~w~n", [NModels]).

display_models(NModels, T, Fd) :-
 iccvar(state_integers, StateNs),
 iccvar(trans_integers, TransNs),
 set_iccvar(sol_counter, 0),
 icc_option(model_item_sep, ItemSep),
 !,
 display_models(NModels, T, StateNs, TransNs, ItemSep, Fd).

%%%%% display_models/6

display_models(_NModels, T, StateNs, TransNs, ItemSep, Fd) :-
 sat_model(Model),
 incr_iccvar(sol_counter, N),
 (ItemSep = '\n' -> NL = '' ; NL = '\n'),
 format(Fd, '~w%%%%%% SOLUTION ~w:~n', [NL,N]),
 show_model(0, Model, T, StateNs, TransNs, ItemSep, Fd),
 format(Fd, '~n', []),
 fail.

display_models(NModels, _T, _StateNs, _TransNs, _ItemSep, Fd) :-
 !,
 format(Fd, "~nNumber of models shown: ~w.~n", NModels),
 (
  iccvar(more_models, 1)
 -> format(Fd, "(There were more solutions.)~n", [])
 ;  true
 ),
 remove_iccvar(sol_counter).

%%%%% show_model/7

show_model(Over, _, T, _StateNs, _TransNs, _ItemSep, _Fd) :-
 Over > T,
 !.

show_model(N, Model, T, StateNs, TransNs, ItemSep, Fd) :-
 (
  N > 0
  -> format(Fd, '~nA', []),
     get_mvc_atoms(TransNs, Model, Action, MidModel),
     (
      iccvar(is_ncplus, 1)
      -> show_ncplus_col(Action, trans, RestAction, ItemSep, Fd)
      ;  format(Fd, ':  ~w', [ItemSep]), % '\n' or ''
         RestAction = Action
     ),
     show_mvc_atoms(RestAction, ItemSep, Fd)
  ;  MidModel = Model
 ),
 format(Fd, '~n~w', [N]),
 get_mvc_atoms(StateNs, MidModel, State, RestModel),
 (
  iccvar(is_ncplus, 1)
  -> show_ncplus_col(State, state, RestState, ItemSep, Fd)
  ;  format(Fd, ':  ~w', [ItemSep]),
     RestState = State
 ),
 show_mvc_atoms(RestState, ItemSep, Fd),
 N1 is N + 1,
 show_model(N1, RestModel, T, StateNs, TransNs, ItemSep, Fd).

%%%%% show_ncplus_col/5

show_ncplus_col(Atoms, Sig, RestAtoms, ItemSep, Fd)  :-
 (
  select(mvc(_V, Nth, Sig, ncplus, 2, 1), Atoms, RestAtoms)
  -> icc_option(ncplus_symbols, [_,_,Green,Red]),
     (
      Nth = 1
      -> print_tabbed(Green, Red, Fd)
      ;  print_tabbed(Red, Green, Fd)
     ),
     format(Fd, '~w', [ItemSep])  % could be '\n' or ''
  ;  % something went wrong
     format(Fd,':  ', []),
     RestAtoms = Atoms
 ).

%%%%% print_tabbed/3

print_tabbed(Col1, Col2, Fd) :-
 atom_length(Col1, N1),
 atom_length(Col2, N2),
 (
  N1 >= N2
  -> N = 0
  ;  N is N2 - N1
 ),
 format(Fd, ' [~w]: ',[Col1]), 
 tab(Fd, N).

%%%%% get_mvc_atoms/4

get_mvc_atoms([], BitList, [], BitList) :-
 !.

get_mvc_atoms([J|RestNs], BitList, [Atom|RestAtoms], Remainder) :-
 bit_list_to_mvc(J, BitList, Atom, RestBitList),
 !,
 get_mvc_atoms(RestNs, RestBitList, RestAtoms, Remainder).
  
%%%%% bit_list_to_mvc/4

bit_list_to_mvc(J, BitList, Atom, Remainder) :-
 atom_integer(C, Sig, J, Nbits),                % we only need this to get
 icc_dom(C, Sig, Type, _Dom, NDom, Nbits),      % Type and NDom: can drop it?
 bit_list_to_index(Nbits, BitList, Nth, Remainder),
 !,
 Atom = mvc(J, Nth, Sig, Type, NDom, Nbits). 
  
%%%%% bit_list_to_index/4

bit_list_to_index(Nbits, List, Nth, Remainder) :-
 bit_list_to_index(Nbits, List,0,0,Index, Remainder),
 !,
 (
  Index = 0
  -> Nth is 2 << (Nbits - 1)            % Nth = 2^Nbits
  ;  Nth is Index
 ).

%%%%% bit_list_to_index/6

bit_list_to_index(0,List,_,Cum,Cum,List) :-
 !.

bit_list_to_index(Nbits, [N|Rest],Exp,Cum,Index, Remainder) :-
 NbitsX is Nbits - 1,
 ExpN is Exp + 1,
 NextCum is Cum + (N << Exp),
 !,
 bit_list_to_index(NbitsX, Rest,ExpN,NextCum,Index,Remainder).


%%%%% index_to_bit_list/4   

% This is used in mcLUCA. 

% Essentially the same as nth_to_bool_formula/9 (which is
% more complicated, because it makes a formula)


% this deals correctly with the case where Nth is 2^Nbits
% e.g.   index_to_bit_list(8, 3, List, Tail)
% gives List = [0,0,0|Tail]

index_to_bit_list(Nth, Nbits, List, Tail) :-
  (Nbits = 0 -> List = Tail;
    List = [Bit|Rest],
    Bit is Nth rem 2,
    NNbits is Nbits - 1,
    NNth is Nth >> 1,
    index_to_bit_list(NNth, NNbits, Rest, Tail)
  ).


%%%% show_mvc_atoms/3

show_mvc_atoms([], _ItemSep, _Fd).

show_mvc_atoms([Atom|Rest], ItemSep, Fd) :-
 pretty_print_mvc_atom(Atom, ItemSep, Fd),
 !,
 show_mvc_atoms(Rest, ItemSep, Fd).

%%%%% pretty_print_mvc_atom/3

pretty_print_mvc_atom(mvc(J, Nth, Sig, Type, NDom, Nbits), ItemSep, Fd) :- 
 atom_integer(C, Sig, J, Nbits), 
 icc_dom(C, Sig, Type, Dom, NDom, Nbits),
 !,
 nth(Nth, Dom, V),
 pretty_print_mvc_atom(C, V, Nth, Sig, ItemSep, Fd).

%%%%% pretty_print_mvc_atom/6

pretty_print_mvc_atom(C, V, _Nth, Sig, _ItemSep, _Fd) :- 
 hidden_atom(C,V,Sig),
 !.

pretty_print_mvc_atom(C, V, Nth, _Sig, ItemSep, Fd) :- 
 (
  boolean_domain(C), icc_option(show_boolean,0)
  -> (
      Nth = 1
      -> format(Fd, ' ~q~w', [C,ItemSep])  % ItemSep '\n' or ''
      ;  (
          icc_option(show_neg,1) 
          -> format(Fd, ' -~q~w', [C,ItemSep])
          ;  true
         )
     )
  ;  
     format(Fd, ' ~q=~q~w', [C,V,ItemSep])
  ).

%%%%% hidden_atom/3

hidden_atom(C,V,_Sig) :- 
 icc_option(hidden_atom(C=V), 1),
 !.

hidden_atom(_C,Fval,trans) :- 
 icc_option(hidden_atom(ac=ff), 1),
 !,
 icc_option(boolean_symbols, [_,Fval]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 29: writing transition system to files (graph/prolog)
%
% PREDICATES DEFINED:
%  - trans2dot/0
%  - trans2prolog/0
%  - output_trans/3
%  - invoke_dot2ps/2
%  - invoke_viewer/1
%  - record_transition_subsystem/3
%  - stamp_fmla_list/3
%  - record_states/1
%  - record_transitions/6
%  - write_graph_file/2
%  - write_graph_file_preamble/3
%  - transcribe_comments/1
%  - write_graph_file_close_off/3
%  - write_state/4
%  - label_items/2
%  - write_trans/6
%  - write_dot_label/2
%  - signature_to_prolog/1
%  - show_record_statistics/5
%  - 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% trans2dot/0 :: VISIBLE

trans2dot :-
 (
  icc_option(disp_states_in_trans_only,1)
  -> OldT = 1
  ;  OldT = 0
 ),
 set_opt(disp_states_in_trans_only,0),
 output_trans(dot, [], []),
 set_opt(disp_states_in_trans_only,OldT).
  
%%%%% trans2prolog/0 :: VISIBLE

trans2prolog :-
 (
  icc_option(show_neg,1)
  -> Old = 1
  ; Old = 0
 ),
 set_opt(show_neg,0),
 (
  icc_option(disp_states_in_trans_only,1)
  -> OldT = 1
  ;  OldT = 0
 ),
 set_opt(disp_states_in_trans_only,0),
 output_trans(prolog, [], []),
 set_opt(show_neg,Old),
 set_opt(disp_states_in_trans_only,OldT).

%%%%% output_trans/3

output_trans(Fmt, StateConstraints, TransConstraints) :-
 stats(_),
 record_transition_subsystem(StateConstraints, TransConstraints, RecTotalMS),
 write_graph_file(Fmt, GraphFile),
 retractall(state(_,_)),
 retractall(trans(_,_,_,_)),
 retractall(trans_event_label(_,_)),
 stats(WriteMS),
 WriteS is WriteMS / 1000,
 (
  Fmt = dot
  -> Tag = '.dot'
  ;  Tag = 'Prolog'
 ),
 format('~nTime for writing ~w file:~35|~2f seconds (~w ms)',[Tag, WriteS,WriteMS]),
 RecWriteMS is RecTotalMS + WriteMS,
 (
  Fmt = dot
  -> invoke_dot2ps(GraphFile, RecWriteMS)
  ;  true
 ).

%%%%% invoke_dot2ps/2

invoke_dot2ps(DotFile, RecWriteMS) :-
 icc_option(dot2ps, 1),
 (
  environ(windir, _)
  -> format('~n~nNow run dot yourself.~n', []),
     fail
  ;  true
 ),
 iccvar(mainfile, File),
 atoms_concat([File,'.ps'],PSFile),
 atoms_concat(['dot -Tps ',DotFile,' > ',PSFile],Dot),
 flush_output,

 common_walltime(_),
 shell(Dot, _),    % cut here in case shell(Dot) fails
 !,
 common_walltime(DotMS),
 DotS is DotMS / 1000,
 format('~nTime for calling dot:~35|~2f seconds (~w ms)', [DotS,DotMS]),
 invoke_viewer(PSFile),
 TotalMS is RecWriteMS + DotMS,
 TotalS is TotalMS / 1000,
 format('~nTotal time:~35|~2f seconds (~w ms)', [TotalS,TotalMS]),
 prolog_specific_space.

invoke_dot2ps(_,_).  

%%%%% invoke_viewer/1

invoke_viewer(PSFile) :-
 icc_option(view_ps, 1),
 !,
 icc_option(viewer, Viewer),
 atoms_concat([Viewer,' ',PSFile,' &'], ViewCommand),
 shell(ViewCommand).

invoke_viewer(_).

%%%%% record_transition_subsystem/3

record_transition_subsystem(StateConstraints, TransConstraints, TotalMS) :-
 set_iccvar(n_states, 0),
 set_iccvar(n_trans, 0),
 set_iccvar(n_actions, 0),
 retractall(state(_,_)),
 retractall(trans(_,_,_,_)),
 retractall(trans_event_label(_,_)),
 stamp_fmla_list(StateConstraints, 0, StampSC0),
 solve_query(0, StampSC0, _, SClauseMS, SSolnMS, SReadMS),
 show_record_statistics('state', SClauseMS, SSolnMS, SReadMS, STotalMS),
 record_states,
 stamp_fmla_list(StateConstraints, 1, StampSC1),
 append(StampSC0, StampSC1, StampSC),
 append(StampSC, TransConstraints, TC),
 solve_query(1, TC, _, TClauseMS, TSolnMS, TReadMS),
 show_record_statistics('transition', TClauseMS, TSolnMS, TReadMS, TTotalMS),
 record_transitions,
 TotalMS is STotalMS + TTotalMS.

%%%%% stamp_fmla_list/3

stamp_fmla_list([], _, []).

stamp_fmla_list([F|Rest], N, [StampF|StampRest]) :-
 stamp_fmla(F, N, StampF),
 stamp_fmla_list(Rest, N, StampRest).

%%%%% record_states/1

record_states :-
 iccvar(state_integers, StateNs),
 (
  sat_model(Model),
  incr_iccvar(n_states, N),
  get_mvc_atoms(StateNs, Model, MVCs, _),
  assert(state(N, MVCs)),
  fail
  ;
  true
 ).

%%%%% record_transitions/0

record_transitions :-
 iccvar(state_integers, StateNs),
 iccvar(trans_integers, TransNs),
 (
  sat_model(Model),
  incr_iccvar(n_trans, NT),
  get_mvc_atoms(StateNs, Model, State0,  Model1),

  get_mvc_atoms(TransNs, Model1, Action, Model2),
  get_mvc_atoms(StateNs, Model2, State1, _),
  state(NS0, State0),
  state(NS1, State1),
  (
   trans_event_label(NA, Action)
   -> true
   ;  incr_iccvar(n_actions, NA),
      assert(trans_event_label(NA, Action))

  ),
  assert(trans(NS0, NT, NA, NS1)),
  fail
  ;
  true
 ).

%%%%% write_graph_file/2

write_graph_file(Fmt, FileName) :-
 (
  Fmt = dot
  -> icc_option(dir:tmp, TMP),
     atom_concat(TMP, 'iccalc.dot', FileName)
  ;  Ext = '.Prolog.pl',
     iccvar(mainfile, File),
     atom_concat(File, Ext, FileName)
 ),
 open(FileName, write, OutFd),
 write_graph_file_preamble(Fmt, OutFd, File),
 (
  state(N, StateVars),
  (
   icc_option(disp_states_in_trans_only, 1)
   -> (
       (trans(N, _, _, _) ; trans(_, _, _, N))
       -> true
      )  
   ;  true
  ),
  write_state(Fmt, N, StateVars, OutFd),
  fail
  ;
  format(OutFd, '~n', []),
  trans(S0, TN, EN, S1),        % TN is #trans#, EN is #event-label
  write_trans(Fmt, S0, TN, EN, S1, OutFd),
  fail
  ;
  write_graph_file_close_off(Fmt, OutFd, File)
 ),
 close(OutFd).

%%%%% write_graph_file_preamble/3

write_graph_file_preamble(dot, OutFd, _) :-
 iccvar(mainfile_basename, FileBase),
 format(OutFd, '~ndigraph ~w {~n', [FileBase]),
 icc_option(dot_options, DotOptEnd),
 iccvar(iCCalc_dir, ICCALC),
 atoms_concat([ICCALC,'iccalc.',DotOptEnd],DotOptFile),
 open(DotOptFile, read, OptFd),
 repeat,
  get_char(OptFd, Char),
  (
   Char == end_of_file
   ;
   put_char(OutFd, Char),
   fail
  ),
 !,
 close(OptFd).

write_graph_file_preamble(prolog, OutFd, File) :-
 action_desc_type(Ctype),
 iccvar(mainfile_basename, BaseName),
 format(OutFd, '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%~n', []),
 format(OutFd, '%%~n', []), 
 format(OutFd, '%% ACTION LANGUAGE: ~w~n', [Ctype]),
 format(OutFd, '%% DOMAIN FILE    : ~w~n', [BaseName]),
 format(OutFd, '%% ~w~n', [File]),
 format(OutFd, '%%~n%% Prolog representation generated by iCCalc~n', []),
 format(OutFd, '%%~n', []), 
 format(OutFd, '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%~n', []),
 format(OutFd, '~n', []),  
 transcribe_comments(OutFd),
 format(OutFd, '~n~ndomain_file(~q).', [File]),
 format(OutFd, '~n~n', []),    
 format(OutFd, '/*    ------ ~w ------------~n~n', [File]),
 show_causal_laws(OutFd),
 format(OutFd, ' ------------------------------- */~n~n', []),
 signature_to_prolog(OutFd).


%%%%% transcribe_comments/1

transcribe_comments(_) :-
  \+ loadf_comments(_), !.
transcribe_comments(OutFd) :-
  format(OutFd, "~n/*", []),
  loadf_comments(String),
  format(OutFd, String, []),
  fail.
transcribe_comments(OutFd) :- 
  format(OutFd,"~n*/~n", []).

%%%%% write_graph_file_close_off/3


write_graph_file_close_off(dot, OutFd, _) :-
 format(OutFd, '~n}~n', []).  % closing bracket


write_graph_file_close_off(prolog, OutFd, _) :-
 format(OutFd, '~n', []).

%%%%% write_state/4

write_state(Fmt, N, StateVars, OutFd) :-
 label_items(StateVars, Items),
 (
  Fmt = dot
  -> format(OutFd, ' ~w [label="', [N]),
     write_dot_label(Items, OutFd),
     format(OutFd, '];~n', [])
  ;  format(OutFd, 'icc_state(s~w, ~q).~n' , [N,Items])
 ).

%%%%% label_items/2
 
label_items([], []).

label_items([mvc(J, Nth, Sig, Type, NDom, Nbits)|RestMVCs], [C=V|RestItems]) :-
 atom_integer(C, Sig, J, Nbits), 
 icc_dom(C, Sig, Type, Dom, NDom, Nbits), !,
 nth(Nth, Dom, V),
 label_items(RestMVCs, RestItems).

%%%%% write_trans/6
%
% here TN is #trans and EN is #event-labels

write_trans(Fmt, S0, TN, EN, S1, OutFd) :-
 trans_event_label(EN, ACatoms),
 label_items(ACatoms, Items),
 (
  Fmt = dot
  -> format(OutFd, ' ~w -> ~w [label="', [S0, S1]),
     write_dot_label(Items, OutFd),
     format(OutFd, '];~n', [])
  ;  format(OutFd, 'icc_trans(t~w, s~w, e~w, ~q, s~w).~n',[TN, S0, EN, Items, S1])
 ).

%%%%% write_dot_label/2

write_dot_label(Items, OutFd) :-
 member(Item, Items),
 Item \= (status=V),
 Item \= (trans=V),
 (
  Item = (C=V)
  -> (
      Item = (C=ff)
      -> true
      ;
      Item = (C=tt)
      -> format(OutFd, '~w\\n', [C])
      ;  format(OutFd, '~w=~w\\n', [C,V])
     )
  ;  format(OutFd, '~w\\n', [Item])
 ),
 fail.

write_dot_label(Items, OutFd) :-
 member(C=V, Items),
 (C = status ; C = trans),
 icc_option(colour(C,V), ColV),
 format(OutFd, '",color="~w",style="filled', [ColV]),
 fail.

write_dot_label(_, OutFd) :-
 format(OutFd, '"', []).
   
%%%%% signature_to_prolog/1

signature_to_prolog(Fd) :-
 iccvar(is_ag_stranded,1),
 format(Fd, '~n%%  agents~n~n', []),
 agentlist(Agents),
 member(Ag, Agents),
 format(Fd, 'agent(~q).~n', [Ag]),
 fail.
 
signature_to_prolog(Fd) :-
 format(Fd, '~n%%  simple fluent constants~n~n', []),
 fc(C),
 format(Fd, 'fc(~q).~n', [C]),
 fail.

signature_to_prolog(Fd) :-
 \+ (\+ sdfc(_)),
 format(Fd, '~n~n%%  statically determined fluent constants~n~n', []),
 sdfc(C),
 format(Fd, 'sdfc(~q).~n', [C]),
 fail.

signature_to_prolog(Fd) :-
 iccvar(is_ncplus,1),
 action_desc_type(Ctype),
 icc_option(ncplus_symbols,[Status,_,_,_]),
 format(Fd, '~n~n%%  ~w specific fluent constants~n~n', [Ctype]),
 format(Fd, 'ncplus_fc(~w).~n', [Status]),
 fail.

signature_to_prolog(Fd) :-
 \+ (\+ ac(_)),
 format(Fd, '~n~n%%  action constants~n~n', []),
 ac(C),
 format(Fd, 'ac(~q).~n', [C]),
 fail.
  
signature_to_prolog(Fd) :-
 iccvar(is_ncplus,1),
 action_desc_type(Ctype),
 icc_option(ncplus_symbols,[_,Trans,_,_]),
 format(Fd, '~n~n%%  ~w specific action constants~n~n', [Ctype]),
 format(Fd, 'ncplus_ac(~w).~n', [Trans]),
 fail.

signature_to_prolog(Fd) :-
 format(Fd, '~n~n%% domains~n~n', []),
 (fc(C) ; sdfc(C) ; ac(C)),
 format(Fd, 'dom(~q, ', [C]),
 (
  boolean_domain(C)
  -> format(Fd, 'boolean', [])
  ;  findall(V, domain(C, V), Domain),
     remove_duplicates(Domain, Pruned),
     format(Fd, '~q', [Pruned])
 ),
 format(Fd, ').~n', []),
 fail.

% MIGHT NOT NEED THIS IF domain(_,_) asserted already for ncplus constants

signature_to_prolog(Fd) :-
 iccvar(is_ncplus,1),
 format(Fd, 'dom(status, [green,red]).~n', []),
 format(Fd, 'dom(trans, [green,red]).~n', []),
 fail.

signature_to_prolog(Fd) :-
 prolog_specific_space(Fd).   

%%%%% show_record_statistics/5

show_record_statistics(Theory, ClauseMS, SolnMS, ReadMS, TotalMS) :-
 msecs_to_secs([ClauseMS,SolnMS,ReadMS],[ClauseS,SolnS,ReadS]),
 format('~nClause writing for ~ws:~35|~2f seconds (~w ms)', [Theory,ClauseS,ClauseMS]),
 format('~nSAT-solver for ~ws:~35|~2f seconds (~w ms)', [Theory,SolnS,SolnMS]),
 format('~nModel processing for ~ws:~35|~2f seconds (~w ms)', [Theory,ReadS,ReadMS]),
 TotalMS is ClauseMS + SolnMS + ReadMS.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 30: queries to dot
%
% PREDICATES DEFINED:
%  - q2dot/1
%  - q2dot/2
%  - record_dot_states/1
%  - record_dot_transitions/1
%  - ensure_state/2
%
% Visualization of fragments of a transition system
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% q2dot/1 :: VISIBLE

q2dot(Label) :-
 builtin_query(Label, MaxTerm, Query),
 !,
 q2dot(MaxTerm, Query).

q2dot(Label) :-
 query(Label, MaxTerm, Query),
 q2dot(MaxTerm, Query).

%%%%% q2dot/2 :: VISIBLE

q2dot(MaxTerm, Query) :-
 (
  iccvar(show_models, CurrentShowFlag)
  -> true
  ;  CurrentShowFlag=none
 ),
 set_iccvar(show_models, 0),
 stats(_),
 query(MaxTerm, Query),
 (
  MaxTerm = 0
  -> record_dot_states(RecTotalMS),
     (
      icc_option(disp_states_in_trans_only,1)
      -> OldT = 1
      ;  OldT = 0
     ),
     set_opt(disp_states_in_trans_only,0)
  ;
  MaxTerm = 1
  -> record_dot_transitions(RecTotalMS)
 ),
 write_graph_file(dot, GraphFile),
 (
  MaxTerm = 0
  -> set_opt(disp_states_in_trans_only,OldT)
  ;  true
 ),
 retractall(state(_,_)),
 retractall(trans(_,_,_,_)),
 retractall(trans_event_label(_,_)),
 stats(WriteMS),
 WriteS is WriteMS / 1000,
 (
  Fmt = dot
  -> Tag = '.dot'
  ;  Tag = 'Prolog'
 ),
 format('~nTime for writing ~w file:~35|~2f seconds (~w ms)',[Tag, WriteS,WriteMS]),
 RecWriteMS is RecTotalMS + WriteMS,
 (
  Fmt = dot
  -> invoke_dot2ps(GraphFile, RecWriteMS)
  ;  true
 ),
 (
  CurrentShowFlag = none
  -> remove_iccvar(show_models)
  ;  set_iccvar(show_models, CurrentShowFlag)
 ).

%%%%% record_dot_states/1

record_dot_states(RecTotalMs) :-
 iccvar(state_integers, StateNs),
 set_iccvar(n_states, 0),
 set_iccvar(n_trans, 0),
 set_iccvar(n_actions, 0),
 (
  sat_model(Model),
  get_mvc_atoms(StateNs, Model, State,  _),
  ensure_state(_, State),
  fail
  ;
  stats(RecTotalMs)
 ).

%%%%% record_dot_transitions/1

record_dot_transitions(RecTotalMs) :-
 iccvar(state_integers, StateNs),
 iccvar(trans_integers, TransNs),
 set_iccvar(n_states, 0),
 set_iccvar(n_trans, 0),
 set_iccvar(n_actions, 0),
 (
  sat_model(Model),
  incr_iccvar(n_trans, NT),
  get_mvc_atoms(StateNs, Model, State0,  Model1),
  get_mvc_atoms(TransNs, Model1, Action, Model2),
  get_mvc_atoms(StateNs, Model2, State1, _),
  ensure_state(NS0, State0),
  ensure_state(NS1, State1),
  (
   trans_event_label(NA, Action)
   -> true
   ;  incr_iccvar(n_actions, NA),
      assert(trans_event_label(NA, Action))
  ),
  assert(trans(NS0, NT, NA, NS1)),
  fail
  ;
  stats(RecTotalMs)
 ).

%%%%% ensure_state/2

ensure_state(NS, State) :-
 (
  state(NS, State)
  -> true
  ;  incr_iccvar(n_states, NS),
     assert(state(NS, State))
 ).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% SECTION 31: causal_network
%
% Reinstate this bit
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% SECTION 32: mcLUCA interface, etc.
%
% PREDICATES DEFINED:
%  - mcluca_compilations/0
%  - compile_mcluca_state/0
%  - compile_mcluca_trans/0
%
% Produces:
%  - hollow_state(Vars, Expn)
%  - hollow_trans(t(S0,E,S), Expn, Vars)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:-
 dynamic
  hollow_state/2,
  hollow_trans/3.



%%%%% mcluca_compilations/0

mcluca_compilations :-  
 compile_mcluca_state,
 compile_mcluca_trans,
 (
  iccvar(is_ag_stranded,1)
  -> agentlist(AgList),
     compile_ag_strands(AgList)    % IN mcLUCA
  ;  true
 ),
 retract_mcluca_lemmas.    % IN mcLUCA 

%%%%% compile_mcluca_state/0

compile_mcluca_state :-
 retractall( hollow_state(_,_) ),
 atom_var_bindings(0, Bindings, Vars),
 findall(Clause, completion_clause(0, Clause), AllClauses),
 hollow_out_clause_list(AllClauses, Bindings, HollowClauses, []),
 !,
 assert(hollow_state(Vars, HollowClauses)).

%%%%% compile_mcluca_trans/0

compile_mcluca_trans :-
 retractall(hollow_trans(_,_,_)),
 iccvar(n_state_vars ,NFVars),
 iccvar(n_trans_vars,NTransVars),
 length(S0,NFVars),
 length(S1,NFVars),
 length(E,NTransVars),
 append(S0,RestVars,Vars),
 append(E,S1,RestVars),
 atom_var_bindings(1, Bindings, Vars),
 findall(Clause, completion_clause(1, Clause), AllClauses),
 hollow_out_clause_list(AllClauses, Bindings, HollowClauses, []),
 !,
 assert( hollow_trans(t(S0,E,S1), HollowClauses, Vars) ).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% SECTION 33: errors
%
% PREDICATES DEFINED:
%  - fatal_error/2
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% fatal_error/2

fatal_error(FormatString,Args) :-
 nl,
 format("Error: ",[]),
 format(FormatString,Args),
 nl,
 format("Execution aborted~n~n",[]),
 set_iccvar(fatal_error,true).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% SECTION 34: final initialisations
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set the iCCalc home directory

:-
 common_prolog_load_dir(D),
 name(D,D2),
 last(D2,C),
 (
  C == 47   % check if path ends in slash
  -> DirString = D2
  ;  append(D2, "/", DirString)
 ),
 atom_codes(Dir, DirString),
 set_iccvar(iCCalc_dir,Dir),
 set_directories.

% print iCCalc information and version

iccalc :-
 iccvar(prolog_version, Dialect),
 iccvar(iccalc_version, Version),
 format("~n%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%~n",[]),
 format("%~n", []),
 format("% iCCalc Version ~w, for Prolog dialect: ~w~n", [Version,Dialect]),
 format("%~n", []),
 format("% Type 'help.' for online help.~n",[]),
 format("%~n", []),
 format("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%~n~n",[]).

:-
 nl,
 iccalc.

